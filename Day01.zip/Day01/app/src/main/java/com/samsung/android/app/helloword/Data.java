package com.samsung.android.app.helloword;

import android.os.Parcel;
import android.os.Parcelable;

public class Data implements Parcelable {

    private int old;
    private String fullName;
    private String address;

    public Data(int old, String fullName, String address) {
        this.old = old;
        this.fullName = fullName;
        this.address = address;
    }

    private final static Creator<Data> CREATOR = new Creator<Data>() {
        @Override
        public Data createFromParcel(Parcel in) {
            return new Data(in);
        }

        @Override
        public Data[] newArray(int size) {
            return new Data[size];
        }
    };

    public Data(Parcel in) {
        old = in.readInt();
        fullName = in.readString();
        address = in.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeInt(old);
        parcel.writeString(fullName);
        parcel.writeString(address);
    }
}
