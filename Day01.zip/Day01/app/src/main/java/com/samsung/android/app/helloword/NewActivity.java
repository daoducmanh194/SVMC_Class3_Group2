package com.samsung.android.app.helloword;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class NewActivity extends AppCompatActivity  {
    private static final String TAG = "NewActivityTag";
    TextView txt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_activity_main);
        // Log.d(TAG, "onCreate");
        txt = findViewById(R.id.txt);
        txt.setText(getIntent().getStringExtra("msg"));
    }
}
