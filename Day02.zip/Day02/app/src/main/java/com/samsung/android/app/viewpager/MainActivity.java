package com.samsung.android.app.viewpager;

import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {

    private ViewPagerAdapter viewPagerAdapter;
    private ViewPager mViewPager;
    private String[] mTittles = {"Note List", "Marked List", "Complete List"};
    private TabLayout mTabLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if(getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
        viewPagerAdapter = new ViewPagerAdapter(getSupportFragmentManager());
        mViewPager = findViewById(R.id.view_pager);
        mViewPager.setAdapter(viewPagerAdapter);
        setTitle(mTittles[0]);
        mTabLayout = findViewById(R.id.tab_layout);
        mTabLayout.setupWithViewPager(mViewPager);
        createTabIcons();
    }

    void createTabIcons() {
        TextView tabOne = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, null);
        //tabOne.addText(mTittles[0]);
        tabOne.setCompoundDrawablesRelativeWithIntrinsicBounds(0, R.drawable.ic_baseline_notes, 0, 0);
        mTabLayout.getTabAt(0).setCustomView(tabOne);

        TextView tabTwo = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, null);
        // tabTwo.addText(mTittles[1]);
        tabTwo.setCompoundDrawablesRelativeWithIntrinsicBounds(0, R.drawable.ic_baseline_import_contacts_24, 0, 0);
        mTabLayout.getTabAt(1).setCustomView(tabTwo);

        TextView tabThree = (TextView) LayoutInflater.from(this).inflate(R.layout.custom_tab, null);
        // tabThree.addText(mTittles[2]);
        tabThree.setCompoundDrawablesRelativeWithIntrinsicBounds(0, R.drawable.ic_baseline_done_24, 0, 0);
        mTabLayout.getTabAt(2).setCustomView(tabThree);
    }
}