package com.samsung.android.app.fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class FirstFragment extends Fragment {
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedIntancesState) {
        View view = inflater.inflate(R.layout.first_fragment, container, false);
        Button button = view.findViewById(R.id.start_second_fragment);
        button.setOnClickListener(view1 -> ((MainActivity) getActivity()).openSecondFragment());
        return view;
    }
}
