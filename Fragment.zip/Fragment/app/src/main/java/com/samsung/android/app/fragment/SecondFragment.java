package com.samsung.android.app.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class SecondFragment extends Fragment {

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedIntancesState) {
        View view = inflater.inflate(R.layout.second_fragment, container, false);
        Button backToPrevious = view.findViewById(R.id.button);
        backToPrevious.setOnClickListener(view1 -> ((MainActivity) getActivity()).backToPrevious());
        Button startViewPageBin = view.findViewById(R.id.start_new_activity);
//        startViewPageBin.setOnClickListener(view2 -> {
//            Intent intent = new Intent(this.getActivity(), ViewPageActivity.class);
//            startActivity(intent);
//        });
        return view;
    }

}
