package ducmanhdao.ddm.com.application.myapplication.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import ducmanhdao.ddm.com.application.myapplication.entity.CongViec;
import ducmanhdao.ddm.com.application.myapplication.entity.NhanVien;

public class NhanVienDAO {
    public  static ArrayList<NhanVien>getAllNhanVien(Context context){
        ArrayList<NhanVien>ds=new ArrayList<>();
        DataHelper helper= new DataHelper(context);
        SQLiteDatabase db=helper.getReadableDatabase();
        Cursor cs=db.rawQuery("Select *from NhanVien",null);
        cs.moveToFirst();
        while (!cs.isAfterLast()){
            int manv= cs.getInt(0);
            String tennv=  cs.getString(1);
            String diaChi=  cs.getString(2);
            String sdt=  cs.getString(3);
            String email=  cs.getString(4);
            String chucVu = cs.getString(5);
            String phongBan=  cs.getString(6);
            String kinhNghiem=  cs.getString(7);
            String taiKhoan=  cs.getString(8);
            String matKhau = cs.getString(9);
            NhanVien nv=new NhanVien(manv,tennv,diaChi,sdt,email,chucVu,phongBan,kinhNghiem,taiKhoan,matKhau);
            ds.add(nv);
            cs.moveToNext();
        }
        cs.close();
        db.close();
        return ds;
    }

    public static ArrayList<NhanVien>getNhanVienTheoTen(Context context, String ten){
        ArrayList<NhanVien>ds=new ArrayList<>();
        DataHelper helper= new DataHelper(context);
        SQLiteDatabase db=helper.getReadableDatabase();
        String[] tmp= {ten};
        Cursor cs=db.rawQuery("Select *from NhanVien Where tenNV= ? ",tmp);
        cs.moveToFirst();
        while (!cs.isAfterLast()){
            int manv= cs.getInt(0);
            String tennv=  cs.getString(1);
            String diaChi=  cs.getString(2);
            String sdt=  cs.getString(3);
            String email=  cs.getString(4);
            String chucVu = cs.getString(5);
            String phongBan=  cs.getString(6);
            String kinhNghiem=  cs.getString(7);
            String taiKhoan=  cs.getString(8);
            String matKhau = cs.getString(9);
            NhanVien nv=new NhanVien(manv,tennv,diaChi,sdt,email,chucVu,phongBan,kinhNghiem,taiKhoan,matKhau);
            ds.add(nv);
            cs.moveToNext();
        }
        cs.close();
        db.close();
        return ds;
    }

    public static ArrayList<String>getTenNV(Context context){
        ArrayList<String>ds=new ArrayList<>();
        DataHelper helper= new DataHelper(context);
        SQLiteDatabase db=helper.getReadableDatabase();
        Cursor cs=db.rawQuery("Select tenNV from NhanVien ",null);
        cs.moveToFirst();
        while (!cs.isAfterLast()){
            String tennv=  cs.getString(1);
            ds.add(tennv);
            cs.moveToNext();
        }
        cs.close();
        db.close();
        return ds;
    }

    public static NhanVien getNhanVienTheoMa(Context context, int maNV) {
        DataHelper dataHelper = new DataHelper(context);
        SQLiteDatabase db = dataHelper.getReadableDatabase();
        NhanVien nhanVien = new NhanVien();
        String[] tmp = {String.valueOf(maNV)};
        Cursor cs=db.rawQuery("Select * from NhanVien WHERE maNV = ?", tmp);
        cs.moveToFirst();
        while (!cs.isAfterLast()){
            nhanVien.setMaNV(cs.getInt(0));
            nhanVien.setTenNV(cs.getString(1));
            nhanVien.setDiaChi(cs.getString(2));
            nhanVien.setSdt(cs.getString(3));
            nhanVien.setEmail(cs.getString(4));
            nhanVien.setChucVu(cs.getString(5));
            nhanVien.setPhongBan(cs.getString(6));
            nhanVien.setKinhNghiem(cs.getString(7));
            nhanVien.setTaiKhoan(cs.getString(8));
            nhanVien.setMatKhau(cs.getString(9));
            cs.moveToNext();
        }
        cs.close();
        db.close();
        return nhanVien;
    }

    public static ArrayList<NhanVien>getNhanVienTheoID(Context context, int id){
        ArrayList<NhanVien>ds=new ArrayList<>();
        DataHelper helper= new DataHelper(context);
        SQLiteDatabase db=helper.getReadableDatabase();
        String[] tmp= {String.valueOf(id)};
        Cursor cs=db.rawQuery("Select *from NhanVien Where maNV= ? ",tmp);
        cs.moveToFirst();
        while (!cs.isAfterLast()){
            int manv= cs.getInt(0);
            String tennv=  cs.getString(1);
            String diaChi=  cs.getString(2);
            String sdt=  cs.getString(3);
            String email=  cs.getString(4);
            String chucVu = cs.getString(5);
            String phongBan=  cs.getString(6);
            String kinhNghiem=  cs.getString(7);
            String taiKhoan=  cs.getString(8);
            String matKhau = cs.getString(9);
            NhanVien nv=new NhanVien(manv,tennv,diaChi,sdt,email,chucVu,phongBan,kinhNghiem,taiKhoan,matKhau);
            ds.add(nv);
            cs.moveToNext();
        }
        cs.close();
        db.close();
        return ds;
    }

    public static ArrayList<NhanVien>getNhanVienTheoPhongBan(Context context, String phongBan1){
        ArrayList<NhanVien>ds=new ArrayList<>();
        DataHelper helper= new DataHelper(context);
        SQLiteDatabase db=helper.getReadableDatabase();
        String[] tmp= {phongBan1};
        Cursor cs=db.rawQuery("Select *from NhanVien Where phongBan= ? ",tmp);
        cs.moveToFirst();
        while (!cs.isAfterLast()){
            int manv= cs.getInt(0);
            String tennv=  cs.getString(1);
            String diaChi=  cs.getString(2);
            String sdt=  cs.getString(3);
            String email=  cs.getString(4);
            String chucVu = cs.getString(5);
            String phongBan=  cs.getString(6);
            String kinhNghiem=  cs.getString(7);
            String taiKhoan=  cs.getString(8);
            String matKhau = cs.getString(9);
            NhanVien nv=new NhanVien(manv,tennv,diaChi,sdt,email,chucVu,phongBan,kinhNghiem,taiKhoan,matKhau);
            ds.add(nv);
            cs.moveToNext();
        }
        cs.close();
        db.close();
        return ds;
    }

    public static boolean insert (Context context,String tennv, String namsinh,String diaChi,String email){
        DataHelper helper= new DataHelper(context);
        SQLiteDatabase db=helper.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("tenNV",tennv);
        values.put("namSinh",namsinh);
        values.put("diaChi",diaChi);
        values.put("email",email);

        long row=db.insert("NhanVien",null,values);
        return (row>0);
    }

    public static boolean insert (Context context,String tennv, String diachi,
                                  String sdt,String email,String chucvu,String phongban,String kingnghiem
            ,String taikhoan,String matkhau){
        DataHelper helper= new DataHelper(context);
        SQLiteDatabase db=helper.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("tenNV",tennv);
        values.put("diaChi",diachi);
        values.put("sdt",sdt);
        values.put("email",email);
        values.put("chucVu",chucvu);
        values.put("phongBan",phongban);
        values.put("kinhNghiem",kingnghiem);
        values.put("taiKhoan",taikhoan);
        values.put("matKhau",matkhau);


        long row=db.insert("NhanVien",null,values);
        return (row>0);
    }

    public static boolean deleteNhanVien(Context context,int vitri){
        ArrayList<NhanVien>ds=new ArrayList<>();
        DataHelper helper= new DataHelper(context);
        SQLiteDatabase db=helper.getReadableDatabase();
        String[] tmp= {String.valueOf(vitri)};
        Cursor cs=db.rawQuery("delete from NhanVien Where maNV= ? ",tmp);
        cs.moveToFirst();
        while (!cs.isAfterLast()){
            int manv= cs.getInt(0);
            String tennv=  cs.getString(1);
            String diaChi=  cs.getString(2);
            String sdt=  cs.getString(3);
            String email=  cs.getString(4);
            String chucVu = cs.getString(5);
            String phongBan=  cs.getString(6);
            String kinhNghiem=  cs.getString(7);
            String taiKhoan=  cs.getString(8);
            String matKhau = cs.getString(9);
            NhanVien nv=new NhanVien(manv,tennv,diaChi,sdt,email,chucVu,phongBan,kinhNghiem,taiKhoan,matKhau);
            ds.remove(nv);
            cs.moveToNext();
        }
        cs.close();
        db.close();

        return true;
    }

    public static int checkAccout (Context context,String name, String pass, String mail) {
        int countAcount = 0;
        ArrayList<String>ds=new ArrayList<>();
        DataHelper helper= new DataHelper(context);
        SQLiteDatabase db=helper.getReadableDatabase();
        String tmp[] = {name};
        Cursor cs=db.rawQuery("Select tenNV from NhanVien Where taiKhoan = ?;", tmp);
        cs.moveToFirst();

        while (!cs.isAfterLast()){
            String tennv=  cs.getString(1);
            countAcount++;
            ds.add(tennv);
            cs.moveToNext();
        }
        cs.close();
        db.close();
        return countAcount;
    }

}
