package ducmanhdao.ddm.com.application.myapplication.db;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import ducmanhdao.ddm.com.application.myapplication.entity.NhanVien;

public class NhanVienDAO {
    public  static ArrayList<NhanVien>getAllNhanVien(Context context){
        ArrayList<NhanVien>ds=new ArrayList<>();
        DataHelper helper= new DataHelper(context);
        SQLiteDatabase db=helper.getReadableDatabase();
        Cursor cs=db.rawQuery("Select *from NhanVien",null);
        cs.moveToFirst();
        while (!cs.isAfterLast()){
            int manv= cs.getInt(0);
            String tennv=  cs.getString(1);
            String diaChi=  cs.getString(2);
            String sdt=  cs.getString(3);
            String email=  cs.getString(4);
            String chucVu = cs.getString(5);
            String phongBan=  cs.getString(6);
            String kinhNghiem=  cs.getString(7);
            String taiKhoan=  cs.getString(8);
            String matKhau = cs.getString(9);
            NhanVien nv=new NhanVien(manv,tennv,diaChi,sdt,email,chucVu,phongBan,kinhNghiem,taiKhoan,matKhau);
            ds.add(nv);
            cs.moveToNext();
        }
        cs.close();
        db.close();
        return ds;
    }

    public static boolean insert (Context context,String tennv, String namsinh,String diaChi,String email){
        DataHelper helper= new DataHelper(context);
        SQLiteDatabase db=helper.getWritableDatabase();
        ContentValues values=new ContentValues();
        values.put("tenNV",tennv);
        values.put("namSinh",namsinh);
        values.put("diaChi",diaChi);
        values.put("email",email);

        long row=db.insert("NhanVien",null,values);
        return (row>0);
    }

    public static ArrayList<NhanVien>getNhanVienTheoTen(Context context, String ten){
        ArrayList<NhanVien>ds=new ArrayList<>();
        DataHelper helper= new DataHelper(context);
        SQLiteDatabase db=helper.getReadableDatabase();
        String[] tmp= {ten};
        Cursor cs=db.rawQuery("Select *from NhanVien Where tenNV= ? ",tmp);
        cs.moveToFirst();
        while (!cs.isAfterLast()){
            int manv= cs.getInt(0);
            String tennv=  cs.getString(1);
            String diaChi=  cs.getString(2);
            String sdt=  cs.getString(3);
            String email=  cs.getString(4);
            String chucVu = cs.getString(5);
            String phongBan=  cs.getString(6);
            String kinhNghiem=  cs.getString(7);
            String taiKhoan=  cs.getString(8);
            String matKhau = cs.getString(9);
            NhanVien nv=new NhanVien(manv,tennv,diaChi,sdt,email,chucVu,phongBan,kinhNghiem,taiKhoan,matKhau);
            ds.add(nv);
            cs.moveToNext();
        }
        cs.close();
        db.close();
        return ds;
    }

    public static boolean checkAccout (Context context,String taiKhoan, String matKhau, String mail){
        ArrayList<String>ds=new ArrayList<>();
        DataHelper helper= new DataHelper(context);
        SQLiteDatabase db=helper.getReadableDatabase();
        Cursor cs=db.rawQuery("Select tenNV from NhanVien Where taiKhoan = 'admin'",null);
        cs.moveToFirst();

        while (!cs.isAfterLast()){
            String tennv=  cs.getString(1);
            ds.add(tennv);
            cs.moveToNext();
        }
        cs.close();
        db.close();
        if(ds.size() != 0 ) return true;
        return false;
    }

    public static ArrayList<String>getTenNV(Context context){
        ArrayList<String>ds=new ArrayList<>();
        DataHelper helper= new DataHelper(context);
        SQLiteDatabase db=helper.getReadableDatabase();
        Cursor cs=db.rawQuery("Select tenNV from NhanVien ",null);
        cs.moveToFirst();
        while (!cs.isAfterLast()){
            String tennv=  cs.getString(1);
            ds.add(tennv);
            cs.moveToNext();
        }
        cs.close();
        db.close();
        return ds;
    }

}
