package ducmanhdao.ddm.com.application.myapplication.views.employee;

import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import ducmanhdao.ddm.com.application.myapplication.R;
import ducmanhdao.ddm.com.application.myapplication.db.NhanVienDAO;
import ducmanhdao.ddm.com.application.myapplication.entity.NhanVien;

public class NhanVienChiTietActivity extends AppCompatActivity {

    private static final String TAG = "NhanVienChiTiet";
    EditText textMaNV, textTenNV, textDiachi, textEmail, textKN, textSdt, textChucvu, textPhongBan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nhanvien_chitiet);

        textMaNV = findViewById(R.id.txtIdTTCT);
        textTenNV = findViewById(R.id.txtTenNvTTCT);
        textDiachi = findViewById(R.id.txtDiaChiTTCT);
        textEmail = findViewById(R.id.txtEmailTTCT);
        textKN = findViewById(R.id.txtKinhnghiemTTCT);
        textSdt = findViewById(R.id.txtSdtTTCT);
        textChucvu = findViewById(R.id.txtChucVuTTCT);
        textPhongBan = findViewById(R.id.txtPhongbanTTCT);


        String tennv = getIntent().getStringExtra("msgID");
        Log.d(TAG, "" + tennv);
        ArrayList<NhanVien> listNhanVien = NhanVienDAO.getNhanVienTheoTen(NhanVienChiTietActivity.this, tennv);
        NhanVien nhanVien = listNhanVien.get(0);
        textMaNV.setText(String.valueOf(nhanVien.getMaNV()));
        textTenNV.setText(tennv);
        textDiachi.setText(nhanVien.getDiaChi());
        textEmail.setText(nhanVien.getEmail());
        textKN.setText(nhanVien.getKinhNghiem());
        textSdt.setText(nhanVien.getSdt());
        textChucvu.setText(nhanVien.getChucVu());
        textPhongBan.setText(nhanVien.getPhongBan());
    }
}
