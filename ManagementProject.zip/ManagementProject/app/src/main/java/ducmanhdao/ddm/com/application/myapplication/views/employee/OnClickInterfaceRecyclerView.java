package ducmanhdao.ddm.com.application.myapplication.views.employee;

public interface OnClickInterfaceRecyclerView {
    void onClick(int a);
}
