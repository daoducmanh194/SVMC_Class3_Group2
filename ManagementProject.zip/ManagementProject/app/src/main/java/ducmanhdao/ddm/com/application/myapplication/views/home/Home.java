package ducmanhdao.ddm.com.application.myapplication.views.home;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import ducmanhdao.ddm.com.application.myapplication.MainActivity;
import ducmanhdao.ddm.com.application.myapplication.R;
import ducmanhdao.ddm.com.application.myapplication.views.employee.EmployeeTable;
import ducmanhdao.ddm.com.application.myapplication.views.employee.NhanVienActivity;
import ducmanhdao.ddm.com.application.myapplication.views.work.WorkTable;

public class Home extends AppCompatActivity {

    private static final String TAG = "Home Activity";
    private ImageView imgNhanVien, imgCongViec;
    private Button btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        Log.d(TAG, "onCreate in Home");

        imgNhanVien = findViewById(R.id.imageNhanVien);
        imgCongViec = findViewById(R.id.imageCongViec);
        btnLogout = findViewById(R.id.buttonLogout);

        imgNhanVien.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Home.this, NhanVienActivity.class);
                startActivity(intent);
                Log.d(TAG, "Create Nhan Su Activity");
            }
        });
        imgCongViec.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Home.this, WorkTable.class);
                startActivity(intent);
                Log.d(TAG, "Create Cong Viec Activity");
            }
        });
        btnLogout.setVisibility(View.INVISIBLE);
        btnLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "Move to login page!");
                Intent intent = new Intent(Home.this, MainActivity.class);
                startActivity(intent);
            }
        });
    }
}
