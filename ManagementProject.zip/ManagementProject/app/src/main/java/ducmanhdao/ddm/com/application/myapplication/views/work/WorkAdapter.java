package ducmanhdao.ddm.com.application.myapplication.views.work;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import ducmanhdao.ddm.com.application.myapplication.R;
import ducmanhdao.ddm.com.application.myapplication.db.CongViecDAO;
import ducmanhdao.ddm.com.application.myapplication.entity.CongViec;

public class WorkAdapter extends RecyclerView.Adapter<WorkHolder> {
    private static final String TAG = "WorkAdapter";
    private ArrayList<CongViec> dataWorkArrayList = new ArrayList<>();

//    public WorkAdapter() {
//        dataWorkArrayList.add(new CongViec(Integer.parseInt("1"), "abcxyz", "xem", "done"));
//        dataWorkArrayList.add(new CongViec(Integer.parseInt("2"), "dsafg", "xem", "done"));
//        dataWorkArrayList.add(new CongViec(Integer.parseInt("3"), "fhngfbcvb", "xem", "done"));
//        dataWorkArrayList.add(new CongViec(Integer.parseInt("4"), "dfg", "xem", "done"));
//        dataWorkArrayList.add(new CongViec(Integer.parseInt("5"), "ryhfgh", "xem", "done"));
//        dataWorkArrayList.add(new CongViec(Integer.parseInt("6"), "fjh", "xem", "done"));
//        dataWorkArrayList.add(new CongViec(Integer.parseInt("7"), "hmnb", "xem", "done"));
//        dataWorkArrayList.add(new CongViec(Integer.parseInt("8"), "gfhrt", "xem", "done"));
//        dataWorkArrayList.add(new CongViec(Integer.parseInt("9"), "ykgm", "xem", "done"));
//    }

    public WorkAdapter(Context context, String tenCV, String trangThai) {
        if(tenCV == null && trangThai != null) {
            dataWorkArrayList = CongViecDAO.getCongViecByTrangThai(context, trangThai);
        } else if (tenCV != null && trangThai == null) {
            dataWorkArrayList = CongViecDAO.getCongViecByName(context, tenCV);
        } else {
            dataWorkArrayList = CongViecDAO.getAllCongViec(context);
        }
    }

    @NonNull
    @Override
    public WorkHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item, parent, false);
        return new WorkHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WorkHolder holder, int position) {
//        holder.itemView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//            }
//        });
        holder.bindView(dataWorkArrayList.get(position));
    }

    @Override
    public int getItemCount() {
        return dataWorkArrayList.size();
    }

    public CongViec getDataAt(int position) {
        return dataWorkArrayList.get(position);
    }

    public void add(int position, CongViec dataWork) {
        dataWorkArrayList.add(position, dataWork);
        notifyItemInserted(position);
    }

    public void removeItem(int position) {
        Log.d(TAG,"removeItem" + position);
        notifyItemRemoved(position);
        dataWorkArrayList.remove(position);
    }
}

