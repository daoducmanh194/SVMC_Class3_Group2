package ducmanhdao.ddm.com.application.myapplication.views.work;

import static java.lang.Integer.parseInt;

import android.app.Dialog;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import ducmanhdao.ddm.com.application.myapplication.R;
import ducmanhdao.ddm.com.application.myapplication.db.CongViecDAO;
import ducmanhdao.ddm.com.application.myapplication.db.DataHelper;
import ducmanhdao.ddm.com.application.myapplication.db.NhanVienDAO;
import ducmanhdao.ddm.com.application.myapplication.entity.CongViec;
import ducmanhdao.ddm.com.application.myapplication.entity.NhanVien;
import ducmanhdao.ddm.com.application.myapplication.utils.Popup;

public class WorkAdd extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private static final String TAG = "AddWorkDetails";
    private EditText mTextMaCV, mTextTenCV, mTextThucHien, mTextChiTiet;
    private TextView header;
    private ImageButton btnBack;
    private Button btnHuy, btn;
    private Spinner spinnerTrangThai, spinnerThucHien;
    private String state[] = {"", "Done","Processing","Cancelled"};
    private ArrayList<String> nvThucHien =new ArrayList<>();
    private String tenCV, chitiet, trangthai, thuchien_new;
    private TextView mTextTrangThai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work);
        Log.d(TAG, "onCreate Watch Work Activity");
        ArrayList<NhanVien> nv = new ArrayList<>();
        nv = NhanVienDAO.getAllNhanVien(WorkAdd.this);
        //Toast.makeText(WorkAdd.this, "" + nv.size(), Toast.LENGTH_LONG).show();
        for(int i=0; i<nv.size() ; i++) {
            nvThucHien.add(nv.get(i).getTenNV());
            //Toast.makeText(WorkAdd.this, "Vi tri "+nv.get(i).getTenNV(), Toast.LENGTH_LONG).show();
        }

        header = findViewById(R.id.textViewWorkHeader);
        mTextMaCV = findViewById(R.id.text_ma_cong_viec);
        mTextTenCV = findViewById(R.id.text_ten_cong_viec);
        mTextThucHien = findViewById(R.id.text_thuc_hien);
        mTextChiTiet = findViewById(R.id.text_chi_tiet_cong_viec);
        mTextTrangThai = findViewById(R.id.text_trang_thai);
        spinnerThucHien = findViewById(R.id.spinner_thuc_hien);
        spinnerThucHien.setOnItemSelectedListener(this);
        mTextThucHien.setVisibility(View.INVISIBLE);
        spinnerTrangThai = findViewById(R.id.spinner_trang_thai);
        spinnerTrangThai.setOnItemSelectedListener(this);
        btnBack = findViewById(R.id.imageButtonBack);
        btnHuy = findViewById(R.id.button_huy);
        btn = findViewById(R.id.button_work_dao);

        header.setText("Them Cong Viec");
        // spinnerTrangThai.setVisibility(View.INVISIBLE);
        mTextTrangThai.setVisibility(View.INVISIBLE);
//        // hien cong viec chi tiet neu da chon click
//        int maCV = parseInt(mTextMaCV.getText().toString());
//        // mTextMaCV.setVisibility(View.INVISIBLE);
//        tenCV = mTextTenCV.getText().toString();
//        String thuchien = mTextThucHien.getText().toString();
////        ArrayList<NhanVien> nhanVien = NhanVienDAO.getNhanVienTheoTen(WorkAdd.this, thuchien);
////        int maNV = nhanVien.get(0).getMaNV();
//        chitiet = mTextChiTiet.getText().toString();


        ArrayAdapter<String> ad = new ArrayAdapter(WorkAdd.this, android.R.layout.simple_list_item_1, state);
        ad.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spinnerTrangThai.setAdapter(ad);

        ArrayAdapter<String> ad1 = new ArrayAdapter(WorkAdd.this, android.R.layout.simple_list_item_1, nvThucHien);
        ad1.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spinnerThucHien.setAdapter(ad1);

        // button work
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "Return to table work page");
                Intent intent = new Intent(WorkAdd.this, WorkTable.class);
                startActivity(intent);
            }
        });
        btnHuy.setVisibility(View.INVISIBLE);
        btn.setText("Them");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // hien cong viec chi tiet neu da chon click
                int maCV = parseInt(mTextMaCV.getText().toString());
                // mTextMaCV.setVisibility(View.INVISIBLE);
                tenCV = mTextTenCV.getText().toString();
                String thuchien = mTextThucHien.getText().toString();
                chitiet = mTextChiTiet.getText().toString();
                Log.d(TAG, "To Popup");
                // showPopup();
                ArrayList<NhanVien> nhanVien = NhanVienDAO.getNhanVienTheoTen(WorkAdd.this, thuchien_new);
                int maNV = nhanVien.get(0).getMaNV();
                if(CongViecDAO.insert(WorkAdd.this, tenCV, chitiet, trangthai, maNV)) {
                    DataHelper helper= new DataHelper(WorkAdd.this);
                    SQLiteDatabase db = helper.getWritableDatabase();
                    String sql = "INSERT INTO CongViec VALUES (" + maCV + "," + tenCV + "," + chitiet + "," + trangthai + "," + maNV + ")";
                    db.execSQL(sql);
                    Intent intent = new Intent(WorkAdd.this, WorkTable.class);
                    startActivity(intent);
            }

//            private void showPopup() {
//                AlertDialog.Builder builder = new AlertDialog.Builder(WorkAdd.this);
//                LayoutInflater inflater = getLayoutInflater();
//                setContentView(R.layout.activity_popup);
//                View view = inflater.inflate(R.layout.activity_popup, null);
//                builder.setView(view);
//                Dialog dialog = builder.create();
//                dialog.show();
//
//                TextView showMessage;
//                Button btnDelete, btnConfirm;
//                showMessage = findViewById(R.id.text_message);
//                btnDelete = findViewById(R.id.button_delete);
//                btnConfirm = findViewById(R.id.button_confirm);
//
//                // showMessage.setText("Ban Co Chac Chan Them Cong Viec Nay ?");
//                btnConfirm.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        Log.d(TAG, "Them cong viec thanh cong");
////                        ArrayList<NhanVien> nhanVien = NhanVienDAO.getNhanVienTheoTen(WorkAdd.this, thuchien);
////                        int maNV = nhanVien.get(0).getMaNV();
//                        int maNV = 6;
//                        if(CongViecDAO.insert(WorkAdd.this, tenCV, chitiet, trangthai, maNV)) {
//                            Toast.makeText(WorkAdd.this, "Success ...", Toast.LENGTH_LONG);
//                            Intent intent = new Intent(WorkAdd.this, WorkTable.class);
//                            startActivity(intent);
//                            // dialog.dismiss();
//                        } else {
//                            Toast.makeText(WorkAdd.this, "Refuse ...", Toast.LENGTH_LONG);
//                        }
//
//                    }
//                });
//                btnDelete.setOnClickListener(new View.OnClickListener() {
//                    @Override
//                    public void onClick(View view) {
//                        Log.d(TAG, "Khong them cong viec!");
//                        Intent intent = new Intent(WorkAdd.this, WorkTable.class);
//                        startActivity(intent);
//                        // dialog.dismiss();
//                    }
//                });
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
        Toast.makeText(getApplicationContext(), state[position], Toast.LENGTH_LONG).show();
        trangthai = state[position];
        thuchien_new = nvThucHien.get(position);
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
        //
    }

}
