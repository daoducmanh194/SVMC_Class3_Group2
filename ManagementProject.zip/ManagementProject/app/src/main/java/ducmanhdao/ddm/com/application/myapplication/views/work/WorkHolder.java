package ducmanhdao.ddm.com.application.myapplication.views.work;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import ducmanhdao.ddm.com.application.myapplication.R;
import ducmanhdao.ddm.com.application.myapplication.entity.CongViec;

public class WorkHolder extends RecyclerView.ViewHolder {

    private TextView idWork;
    private TextView nameWork;
    private TextView statusWork;
    private TextView descriptionWork;

    public WorkHolder(@NonNull View itemView) {
        super(itemView);
        idWork = itemView.findViewById(R.id.id_text_view);
        nameWork = itemView.findViewById(R.id.nameWork_text);
        statusWork = itemView.findViewById(R.id.statusWork_text);
        descriptionWork = itemView.findViewById(R.id.descriptionWork_text);
    }

    @SuppressWarnings("UseCompatLoadingForDrawbles")
    public void bindView(CongViec dataWork) {
        idWork.setText(String.valueOf(dataWork.getMaCV()));
        nameWork.setText(dataWork.getTenCV());
        statusWork.setText(dataWork.getTrangThai());
        descriptionWork.setText(dataWork.getMoTa());
    }
}
