package ducmanhdao.ddm.com.application.myapplication.views.work;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

import ducmanhdao.ddm.com.application.myapplication.R;
import ducmanhdao.ddm.com.application.myapplication.db.CongViecDAO;
import ducmanhdao.ddm.com.application.myapplication.entity.CongViec;
import ducmanhdao.ddm.com.application.myapplication.views.home.Home;

public class WorkTable extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private static final String TAG = "WorkTableActivity";
    private Spinner spinnerStatus;
    private String status[] = {"", "Done","Processing","Cancelled"};
    Button btnSrearch, btnAddWork;
    ImageButton imgButtonBack;
    EditText findWork;
    ConstraintLayout mConLayRI;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_table);

        findWork = findViewById(R.id.text_input_find_name);
        btnSrearch = findViewById(R.id.btn_search);
        imgButtonBack = findViewById(R.id.btn_back);
        btnAddWork = findViewById(R.id.btn_addWork);
        mConLayRI = findViewById(R.id.row_item);


        spinnerStatus = findViewById(R.id.btn_dropdown_loc_cv);
        spinnerStatus.setOnItemSelectedListener(this);

        ArrayAdapter ad = new ArrayAdapter(this, android.R.layout.simple_spinner_item, status);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerStatus.setAdapter(ad);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(WorkTable.this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);

        WorkAdapter workAdapter = new WorkAdapter(WorkTable.this, null, null);
        recyclerView.setAdapter(workAdapter);

        ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                if (direction == ItemTouchHelper.RIGHT) {
                    int position = viewHolder.getAdapterPosition();
                    CongViec dataWork = workAdapter.getDataAt(position);
                    workAdapter.removeItem(position);
                    Snackbar.make(recyclerView, "Deleted" + dataWork.getMaCV(), Snackbar.LENGTH_LONG).setAction("Undo", view -> workAdapter.add(position, dataWork)).show();
                }
            }
        };

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);

        findWork.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                Log.d(TAG, "" + charSequence.toString());
                if(charSequence.toString() == "") {
                    WorkAdapter workAdapter = new WorkAdapter(WorkTable.this, null, null);
                    recyclerView.setAdapter(workAdapter);
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {


            }
        });

        // button
        btnSrearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String tenCV = findWork.getText().toString();
                if(tenCV.isEmpty()) {
                    Log.d(TAG, "Vui long nhap ten!");
                    findWork.setError("Vui long nhap ten!");
                } else {
                    // update show adapter
//                    LinearLayoutManager linearLayoutManager = new LinearLayoutManager(WorkTable.this);
//                    linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
//                    recyclerView.setLayoutManager(linearLayoutManager);
                    // grid view
                    WorkAdapter workAdapter1 = new WorkAdapter(WorkTable.this, tenCV, null);
                    recyclerView.setAdapter(workAdapter1);
                }
            }
        });
        imgButtonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "Back to Home page");
                Intent intent = new Intent(WorkTable.this, Home.class);
                startActivity(intent);
            }
        });
        btnAddWork.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "Move to Add Work page");
                Intent intent = new Intent(WorkTable.this, WorkAdd.class);
                startActivity(intent);
            }
        });

        // constraint layout -> chi tiet

    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
        Toast.makeText(getApplicationContext(), status[position], Toast.LENGTH_LONG).show();
        if(position != 0) {
            String trangThai = status[position];
            RecyclerView recyclerView = findViewById(R.id.recyclerView);
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(WorkTable.this);
            linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
            recyclerView.setLayoutManager(linearLayoutManager);

            WorkAdapter workAdapter = new WorkAdapter(WorkTable.this, null, trangThai);
            recyclerView.setAdapter(workAdapter);
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
