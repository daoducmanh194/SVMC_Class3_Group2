package ducmanhdao.ddm.com.application.myapplication.db;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import ducmanhdao.ddm.com.application.myapplication.entity.CongViec;
import ducmanhdao.ddm.com.application.myapplication.entity.NhanVien;

public class CongViecDAO {

    public static CongViec getCongViecByMa(Context context, int maCV) {
        DataHelper dataHelper = new DataHelper(context);
        SQLiteDatabase db = dataHelper.getReadableDatabase();
        CongViec congViec = new CongViec();
        String mMaCv = Integer.toString(maCV);
        String[] tmp = {mMaCv};
        Cursor cs=db.rawQuery("Select * from CongViec WHERE maCV = ?", tmp);
        cs.moveToFirst();
        while (!cs.isAfterLast()){
            congViec.setMaCV(cs.getInt(0));
            congViec.setTenCV(cs.getString(1));
            congViec.setMoTa(cs.getString(2));
            congViec.setTrangThai(cs.getString(3));
            congViec.setMaNV(cs.getInt(4));
        }
        cs.close();
        db.close();
        return congViec;
    };

}
