package ducmanhdao.ddm.com.application.myapplication.db;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DataHelper extends SQLiteOpenHelper {

    public DataHelper(Context context) {
        super(context, "ManagementProject", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        // Data NhanVien(maNV, tenNV, diaChi, sdt, email, chucVu, phongBan, kinhNghiem, taiKhoan, matKhau)
        String sql = "Create table NhanVien (maNV integer primary key autoincrement," +
                "tenNV text,diaChi text,sdt text, email text,chucVu text, phongBan text, kinhNghiem text,taiKhoan text, matKhau text)";
        sqLiteDatabase.execSQL(sql);
        sql = "Insert Into NhanVien values (null,'Thang','Hà Nội','123456789','1@gmail.com','Trưởng phong','Sale','Không có','admin','admin')";
        sqLiteDatabase.execSQL(sql);
        sql = "Insert Into NhanVien values (null,'Son','Hà Nội','123456789','1@gmail.com','Trưởng phong','Sale','Không có','admin','admin')";
        sqLiteDatabase.execSQL(sql);
        sql = "Insert Into NhanVien values (null,'Bao','Hà Nội','123456789','1@gmail.com','Trưởng phong','Sale','Không có','admin','admin')";
        sqLiteDatabase.execSQL(sql);
        sql = "Insert Into NhanVien values (null,'Manh','Hà Nội','123456789','1@gmail.com','Trưởng phong','Sale','Không có','admin','admin')";
        sqLiteDatabase.execSQL(sql);

        // Data CongViec(maCV, tenCV, moTa, trangThai, maNV)
        String sql1 = "Create table CongViec (maCV integer primary key autoincrement, tenCV text, moTa text, trangThai text, maNV integer)";
        sql1 = "INSERT INTO CongViec VALUES (null, 'Developer', 'Khao sat va code du an', 1)";
        sqLiteDatabase.execSQL(sql1);
        sql1 = "INSERT INTO CongViec VALUES (null, 'Presenter', 'Bao ve du an', 2)";
        sqLiteDatabase.execSQL(sql1);
        sql1 = "INSERT INTO CongViec VALUES (null, 'Desinger', 'Thiet ke va chinh sua UI cho du an', 2)";
        sqLiteDatabase.execSQL(sql1);
        sql1 = "INSERT INTO CongViec VALUES (null, 'Developer', 'Khao sat va code du an', 3)";
        sqLiteDatabase.execSQL(sql1);
        sql1 = "INSERT INTO CongViec VALUES (null, 'Developer', 'Khao sat va code du an', 4)";
        sqLiteDatabase.execSQL(sql1);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("Drop table if exists CongViec");
        sqLiteDatabase.execSQL("Drop table if exists NhanVien");
        onCreate(sqLiteDatabase);
    }
}
