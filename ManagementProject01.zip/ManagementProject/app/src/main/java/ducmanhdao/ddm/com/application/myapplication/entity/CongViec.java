package ducmanhdao.ddm.com.application.myapplication.entity;

public class CongViec {

    private int maCV;
    private String tenCV;
    private String moTa;
    private String trangThai;
    private int maNV;

    public CongViec() {

    }

    public CongViec(int maCV, String tenCV, String moTa, String trangThai, int maNV) {
        this.maCV = maCV;
        this.tenCV = tenCV;
        this.moTa = moTa;
        this.trangThai = trangThai;
        this.maNV = maNV;
    }

    public int getMaCV() {
        return maCV;
    }

    public void setMaCV(int maCV) {
        this.maCV = maCV;
    }

    public String getTenCV() {
        return tenCV;
    }

    public void setTenCV(String tenCV) {
        this.tenCV = tenCV;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    public int getMaNV() {
        return maNV;
    }

    public void setMaNV(int maNV) {
        this.maNV = maNV;
    }

    @Override
    public String toString() {
        return "CongViec{" +
                "maCV=" + maCV +
                ", tenCV='" + tenCV + '\'' +
                ", moTa='" + moTa + '\'' +
                ", trangThai='" + trangThai + '\'' +
                ", maNV=" + maNV +
                '}';
    }
}
