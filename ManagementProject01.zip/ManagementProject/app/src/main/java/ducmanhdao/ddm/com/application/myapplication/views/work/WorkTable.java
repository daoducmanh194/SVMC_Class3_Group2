package ducmanhdao.ddm.com.application.myapplication.views.work;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

import ducmanhdao.ddm.com.application.myapplication.R;

public class WorkTable extends AppCompatActivity {

    private static final String TAG = "WokWatchActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_table);
        Log.d(TAG, "onCreate Work Table");
    }
}
