package com.example.miniproject;

import java.util.ArrayList;

public class ApiOrder {
    String id;
    String tableName;
    Number createdTime;
    boolean status;
    ArrayList<Item> itemsList;

    public ApiOrder() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    public Number getCreatedTime() {
        return createdTime;
    }

    public void setCreatedTime(Number createdTime) {
        this.createdTime = createdTime;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public ArrayList<Item> getItemsList() {
        return itemsList;
    }

    public void setItemsList(ArrayList<Item> itemsList) {
        this.itemsList = itemsList;
    }
}
