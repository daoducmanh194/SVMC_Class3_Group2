package com.example.miniproject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.util.Base64;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miniproject.databinding.FragmentInformationBinding;
import com.example.miniproject.ui.ConvertImage;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {

    public static List<Item> itemList;

    public ItemAdapter(List<Item> itemList) {
        this.itemList = itemList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater =  LayoutInflater.from(context);
        View itemView = inflater.inflate(R.layout.item_item_rcv, parent, false);
        ViewHolder holder = new ViewHolder(itemView);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        int iSelect = position;
        Item item = itemList.get(position);
        EditText itemName = holder.itemNameTxt;
        itemName.setText(item.name);
        EditText price = holder.priceTxt;
        price.setText(item.getPrice()+"đ");
        Switch available = holder.availableSw;
        available.setChecked(item.available);
        ImageButton itemImg = holder.itemImg;
        itemImg.setBackgroundResource(R.drawable.ic_baseline_format_list_bulleted_24);
        itemImg.setImageBitmap(ConvertImage.base64ToImage(item.image));
        itemImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent();
                i.setType("image/*");
                i.setAction(Intent.ACTION_GET_CONTENT);
                Context context = itemImg.getContext();
                ((Activity) context).startActivityForResult(Intent.createChooser(i, "Select Picture"), iSelect);
            }
        });
        Button delBtn = holder.delBtn;
        delBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                itemList.remove(iSelect);
                notifyItemRemoved(iSelect);
                Log.d("msg", iSelect+"");
            }
        });
        itemName.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if(!b){
                    item.setName(itemName.getText().toString());
                    itemName.clearFocus();
                }
            }
        });
        itemName.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if((keyEvent.getAction() == KeyEvent.ACTION_DOWN) &&
                        (i == KeyEvent.KEYCODE_ENTER)){
                    item.setName(itemName.getText().toString());
                    itemName.clearFocus();
                    return true;
                }
                return false;
            }
        });
        price.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if(!b){
                    try{
                        if(price.getText().toString().endsWith("đ")){
                            item.setPrice(Integer.parseInt(price.getText().toString().replace("đ", "")));
                            price.setText(price.getText());
                        }
                        else {
                            item.setPrice(Integer.parseInt(price.getText().toString()));
                            price.setText(price.getText()+"đ");
                        }
                    }
                    catch (Exception e){
                        price.setText("0đ");
                        item.setPrice(0);
                    }
                    price.clearFocus();
                }
            }
        });
        price.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if((keyEvent.getAction() == KeyEvent.ACTION_DOWN) &&
                        (i == KeyEvent.KEYCODE_ENTER)){
                    try{
                        if(price.getText().toString().endsWith("đ")){
                            item.setPrice(Integer.parseInt(price.getText().toString().replace("đ", "")));
                            price.setText(price.getText());
                        }
                        else {
                            item.setPrice(Integer.parseInt(price.getText().toString()));
                            price.setText(price.getText()+"đ");
                        }
                    }
                    catch (Exception e){
                        price.setText("0đ");
                        item.setPrice(0);
                    }
                    price.clearFocus();
                    return true;
                }
                return false;
            }
        });
        available.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                item.setAvailable(available.getShowText());
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }



    public class ViewHolder extends RecyclerView.ViewHolder{
        public EditText itemNameTxt;
        public EditText priceTxt;
        public Switch availableSw;
        public Button delBtn;
        public ImageButton itemImg;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemNameTxt = (EditText)itemView.findViewById(R.id.itemNameTxt);
            priceTxt = (EditText) itemView.findViewById(R.id.priceTxt);
            availableSw = (Switch)itemView.findViewById(R.id.availableSw);
            delBtn = (Button)itemView.findViewById(R.id.delItemBtn);
            itemImg = (ImageButton)itemView.findViewById(R.id.itemImg);
        }
    }
}
