package com.example.miniproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.io.Serializable;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = new Intent(MainActivity.this, InfoActivity.class);
        intent.putExtra("regFlag", 0);
        startActivity(intent);
//        EditText username = findViewById(R.id.userNameEdt);
//        EditText pass = findViewById(R.id.passEdt);
//        Button logBtn = findViewById(R.id.logBtn);
//        Button regBtn = findViewById(R.id.regBtn);
//        TextView errorTxt = findViewById(R.id.errorTxt);
//        logBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if(username.getText().toString().equals("") || pass.getText().toString().equals("")){
//                    errorTxt.setText("Fill all information please!");
//                }
//                else{
//                    API.login(username.getText().toString(), pass.getText().toString());
//                    Intent intent = new Intent(MainActivity.this, InfoActivity.class);
//                    startActivity(intent);
//                }
//
//            }
//        });
//        regBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if(username.getText().toString().equals("") || pass.getText().toString().equals("")){
//                    errorTxt.setText("Fill all information please!");
//                }
//                else{
//                    Intent intent = new Intent(MainActivity.this, InfoActivity.class);
//                    intent.putExtra("regFlag", 1);
//                    startActivity(intent);
//                }
//            }
//        });
    }
}