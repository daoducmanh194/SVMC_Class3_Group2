package com.example.miniproject;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.constraintlayout.widget.ConstraintSet;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class OrderTableAdapter extends RecyclerView.Adapter<OrderTableAdapter.ViewHolder> {
    public static ArrayList<ApiOrder> orderList;

    public OrderTableAdapter(ArrayList<ApiOrder> orderList) {
        this.orderList = orderList;
    }

    @NonNull
    @Override
    public OrderTableAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater =  LayoutInflater.from(context);
        View itemView = inflater.inflate(R.layout.order_table, parent, false);
        OrderTableAdapter.ViewHolder holder = new OrderTableAdapter.ViewHolder(itemView);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull OrderTableAdapter.ViewHolder holder, int position) {
        ApiOrder order = orderList.get(position);
        TextView tableName = holder.tableName;
        tableName.setText(order.tableName);
        TextView time = holder.time;
        time.setText(order.createdTime+"");
        TextView total = holder.total;
        int sum = 0;
        for(Item item : order.itemsList){
            sum += item.price.doubleValue()*item.quantity.doubleValue();
        }
        total.setText(sum+"");
        RecyclerView rcv = holder.rcv;
        OrderedItemAdapter orderedItemAdapter = new OrderedItemAdapter(order.itemsList);
        rcv.setAdapter(orderedItemAdapter);
        rcv.setLayoutManager(new LinearLayoutManager(rcv.getContext()));
        ConstraintLayout constraintLayout = holder.titleCsl;
        constraintLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!rcv.isShown()){
                    rcv.setAdapter(new OrderedItemAdapter(order.itemsList));
                    rcv.setVisibility(View.VISIBLE);
                }
                else{
                    rcv.setAdapter(new OrderedItemAdapter(new ArrayList<>()));
                    rcv.setVisibility(View.INVISIBLE);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView tableName;
        TextView time;
        TextView total;
        RecyclerView rcv;
        ConstraintLayout titleCsl;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tableName = (TextView) itemView.findViewById(R.id.Table);
            time = (TextView) itemView.findViewById(R.id.Time);
            total = (TextView) itemView.findViewById(R.id.Total);
            rcv = (RecyclerView) itemView.findViewById(R.id.orderedItemsRcv);
            titleCsl = (ConstraintLayout) itemView.findViewById(R.id.info_order);
        }
    }
}
