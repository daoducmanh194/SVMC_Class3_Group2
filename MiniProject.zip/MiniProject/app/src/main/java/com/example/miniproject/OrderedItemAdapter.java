package com.example.miniproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class OrderedItemAdapter extends RecyclerView.Adapter<OrderedItemAdapter.ViewHolder> {

    public static ArrayList<Item> items = new ArrayList<>();

    public OrderedItemAdapter(ArrayList<Item> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public OrderedItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater =  LayoutInflater.from(context);
        View itemView = inflater.inflate(R.layout.ordered_item, parent, false);
        OrderedItemAdapter.ViewHolder holder = new OrderedItemAdapter.ViewHolder(itemView);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull OrderedItemAdapter.ViewHolder holder, int position) {
        Item item = items.get(position);
        TextView itemName = holder.itemName;
        itemName.setText(item.name);
        TextView number = holder.number;
        number.setText(item.quantity+"");
        TextView price = holder.price;
        price.setText(item.price+"");
        TextView note = holder.note;
        note.setText("Note");
        CheckBox status = holder.status;
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemName;
        TextView number;
        TextView note;
        TextView price;
        CheckBox status;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = (TextView) itemView.findViewById(R.id.itemName2);
            number = (TextView) itemView.findViewById(R.id.number);
            note = (TextView) itemView.findViewById(R.id.note);
            price = (TextView) itemView.findViewById(R.id.price);
            status = (CheckBox) itemView.findViewById(R.id.status);
        }
    }
}
