package com.example.miniproject;

import android.content.Context;
import android.graphics.Bitmap;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.zxing.WriterException;

import java.util.ArrayList;
import java.util.List;

public class TableAdapter extends RecyclerView.Adapter<TableAdapter.ViewHolder> {
    public static List<Table> tableList;

    public TableAdapter(List<Table> tables) {
        this.tableList = tables;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater =  LayoutInflater.from(context);
        View itemView = inflater.inflate(R.layout.table_item_rcv, parent, false);
        TableAdapter.ViewHolder holder = new TableAdapter.ViewHolder(itemView);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        int iSelect = position;
        Table table = tableList.get(position);
        EditText nameEdt = holder.nameEdt;
        nameEdt.setText(table.name);
        Button delBtn = holder.delBtn;
        delBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                tableList.remove(iSelect);
                notifyItemRemoved(iSelect);
            }
        });
        ImageButton qrImg = holder.qrImg;
        try {
            qrImg.setImageBitmap(table.getQRImage());
        } catch (Exception e) {
            Log.e("ERROR!", e.getMessage());
        }
        nameEdt.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if(!b){
                    table.setName(nameEdt.getText().toString());
                    nameEdt.clearFocus();
                }
            }
        });
        nameEdt.setOnKeyListener(new View.OnKeyListener() {
            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if((keyEvent.getAction() == KeyEvent.ACTION_DOWN) &&
                        (i == KeyEvent.KEYCODE_ENTER)){
                    table.setName(nameEdt.getText().toString());
                    nameEdt.clearFocus();
                    return true;
                }
                return false;
            }
        });
    }

    @Override
    public int getItemCount() {
        return tableList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public EditText nameEdt;
        public ImageButton qrImg;
        public Button delBtn;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nameEdt = (EditText) itemView.findViewById(R.id.tableNameEdt);
            delBtn = (Button) itemView.findViewById(R.id.delTableBtn);
            qrImg = (ImageButton) itemView.findViewById(R.id.qrImg);
        }
    }
}
