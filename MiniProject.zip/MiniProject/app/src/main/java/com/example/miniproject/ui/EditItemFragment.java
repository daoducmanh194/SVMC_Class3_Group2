package com.example.miniproject.ui;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.WINDOW_SERVICE;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miniproject.ApiStore;
import com.example.miniproject.InfoActivity;
import com.example.miniproject.Item;
import com.example.miniproject.ItemAdapter;
import com.example.miniproject.R;
import com.example.miniproject.databinding.FragmentEditItemBinding;
import com.example.miniproject.databinding.FragmentInformationBinding;

import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.ArrayList;

public class EditItemFragment extends Fragment {
    FragmentEditItemBinding binding;
    ArrayList<Item> items;
    RecyclerView rcv;
    Button addBtn;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentEditItemBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        rcv = binding.itemRcv;
        items = InformationFragment.items;
        ItemAdapter itemAdapter = new ItemAdapter(items);
        rcv.setAdapter(itemAdapter);
        rcv.setLayoutManager(new LinearLayoutManager(getContext()));
        addBtn = getActivity().findViewById(R.id.addBtn);
        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                items.add(new Item("i6", "", "", 0, 0, false, ""));
                rcv.getAdapter().notifyItemInserted(items.size()-1);
            }
        });
        return root;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        Log.d("index", InfoActivity.REQUEST_CODE+"");
        Log.d("64: ", InfoActivity.BASE_64);
        items.get(InfoActivity.REQUEST_CODE).setImage(InfoActivity.BASE_64);
        rcv.getAdapter().notifyItemChanged(InfoActivity.REQUEST_CODE);
    }

    @Override
    public void onResume() {
        super.onResume();
        addBtn = getActivity().findViewById(R.id.addBtn);
        addBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                items.add(new Item("i6", "", "", 0, 0, false, ""));
                rcv.getAdapter().notifyItemInserted(items.size()-1);
            }
        });
    }

}
