package com.example.miniproject.ui;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.widget.ViewPager2;

import com.example.miniproject.API;
import com.example.miniproject.ApiStore;
import com.example.miniproject.InfoActivity;
import com.example.miniproject.Item;
import com.example.miniproject.ItemAdapter;
import com.example.miniproject.R;
import com.example.miniproject.Store;
import com.example.miniproject.Table;
import com.example.miniproject.ViewPageAdapter;
import com.example.miniproject.databinding.FragmentEditItemBinding;
import com.example.miniproject.databinding.FragmentInformationBinding;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;
import java.util.Objects;

public class InformationFragment extends Fragment {
    private FragmentInformationBinding binding;
    private ViewPageAdapter viewPageAdapter;
    private ViewPager2 viewPager;
    private String[] tabTitles = {"Món ăn", "Bàn"};
    private TabLayout tabLayout;
    static ApiStore api = API.getStoreInfo();
    public static ArrayList<Table> tables = api.getTables();
    public static ArrayList<Item> items = api.getItems();
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentInformationBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        viewPageAdapter = new ViewPageAdapter(getActivity());
        viewPager = binding.viewPager2;
        viewPager.setAdapter(viewPageAdapter);
        tabLayout = binding.tabLayout;
        EditText storeName = binding.nameEdt;
        EditText address = binding.addressEdt;
        Button saveBtn = binding.saveBtn;
        storeName.setText(api.getName());
        address.setText(api.getAddress());
        int regFlag = getActivity().getIntent().getIntExtra("regFlag", 0);
        new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> tab.setText(tabTitles[position])).attach();
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(regFlag == 0){
                    Store store = new Store();
                    store.setName(storeName.getText().toString());
                    store.setAddress(address.getText().toString());
                    store.setItems(items);
                    store.setTable(tables);
                    API.editStoreInfo(store);
                    api = API.getStoreInfo();
                    items = api.getItems();
                    tables = api.getTables();
                    Intent refresh = new Intent(getActivity(), InfoActivity.class);
                    startActivity(refresh);
                }
                else {
                    Store store = new Store();
                    store.setName(storeName.getText().toString());
                    store.setAddress(address.getText().toString());
                    store.setItems(items);
                    store.setTable(tables);
                    API.createStoreInfo(store);
                }
            }
        });
        return root;
    }
}
