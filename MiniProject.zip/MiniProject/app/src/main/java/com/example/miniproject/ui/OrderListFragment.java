package com.example.miniproject.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miniproject.API;
import com.example.miniproject.ApiOrder;
import com.example.miniproject.OrderTableAdapter;
import com.example.miniproject.databinding.FragmentOrderListBinding;

import java.util.ArrayList;

public class OrderListFragment extends Fragment {
    private FragmentOrderListBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentOrderListBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        RecyclerView tableRcv = binding.orderTableRcv;
        ArrayList<ApiOrder> orderList = new ArrayList<>();
        orderList.add(API.getOrderList());
        orderList.add(API.getOrderList());
        OrderTableAdapter orderTableAdapter = new OrderTableAdapter(orderList);
        tableRcv.setAdapter(orderTableAdapter);
        tableRcv.setLayoutManager(new LinearLayoutManager(getContext()));
        return root;
    }
}
