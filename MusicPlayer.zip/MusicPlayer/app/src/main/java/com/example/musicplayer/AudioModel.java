package com.example.musicplayer;

import java.io.Serializable;

public class AudioModel implements Serializable {
    private String artist;
    private String title;
    private String duration;
    private String path;
    private int instance_id;
    private String favStatus = "0";

    public AudioModel(String artist, String title, String duration, String path) {
        this.artist = artist;
        this.title = title;
        this.duration = duration;
        this.path = path;
    }

    public AudioModel(String artist, String title, String duration, String path, int instance_id, String favStatus) {
        this.artist = artist;
        this.title = title;
        this.duration = duration;
        this.path = path;
        this.instance_id = instance_id;
        this.favStatus = favStatus;
    }

    public int getInstance_id() {
        return instance_id;
    }

    public void setInstance_id(int instance_id) {
        this.instance_id = instance_id;
    }

    public String getFavStatus() {
        return favStatus;
    }

    public void setFavStatus(String favStatus) {
        this.favStatus = favStatus;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getArtist() {
        return artist;
    }

    public void setArtist(String artist) {
        this.artist = artist;
    }
}

