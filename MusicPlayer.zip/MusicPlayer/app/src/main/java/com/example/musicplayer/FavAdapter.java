package com.example.musicplayer;


import static android.content.ContentValues.TAG;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class FavAdapter extends RecyclerView.Adapter<FavAdapter.ViewHolder> {

    private Context context;
    private List<AudioModel> favItemList;
    private FavDB favDB;
    MediaMetadataRetriever mmr = new MediaMetadataRetriever();
    private String TAG = "FavAdapter";

    public FavAdapter(Context context, List<AudioModel> favItemList) {
        this.context = context;
        this.favItemList = favItemList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_item,
                parent, false);
        favDB = new FavDB(context);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.favTitleView.setText(favItemList.get(position).getTitle());
        holder.favArtist.setText(favItemList.get(position).getArtist());
        holder.favBtn.setImageResource(R.drawable.ic_favorite);

        try {
            mmr.setDataSource(favItemList.get(position).getPath());
            byte[] artBytes = mmr.getEmbeddedPicture();
            if (artBytes != null) {
                Bitmap bm = BitmapFactory.decodeByteArray(artBytes, 0, artBytes.length);
                holder.iconImageView.setImageBitmap(bm);
            }
        } catch (Exception e) {
            Log.d(TAG, e.toString());
        }
    }

    @Override
    public int getItemCount() {
        return favItemList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        TextView favTitleView, favArtist;
        ImageView favBtn, iconImageView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            favTitleView = itemView.findViewById(R.id.music_title_text);
            favArtist = itemView.findViewById(R.id.music_artist_text);
            favBtn = itemView.findViewById(R.id.favourite_icon);
            iconImageView = itemView.findViewById(R.id.icon_view);

            //remove from fav after click
            favBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    final AudioModel favItem = favItemList.get(position);
                    favDB.remove_fav(favItem.getPath());
                    removeItem(position);
                    favBtn.setImageResource(R.drawable.ic_favorite_border);
                }
            });
        }
    }

    private void removeItem(int position) {
        favItemList.remove(position);
    }
}
