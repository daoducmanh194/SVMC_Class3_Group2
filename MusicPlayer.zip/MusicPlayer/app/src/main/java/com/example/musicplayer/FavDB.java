package com.example.musicplayer;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class FavDB extends SQLiteOpenHelper {

    private static int DB_VERSION = 1;
    private static String DATABASE_NAME="Song";
    private static String TABLE_NAME = "favouriteTable";
    public static String ITEM_TITLE = "title";
    public static String ITEM_ARTIST = "artist";
    public static String DURATION = "duration";
    public static String INSTANCE_ID ="id";
    public static String ITEM_PATH = "path";
    public static String FAVOURITES_STATUS = "fStatus";
    private static String CREATE_TABLE= "CREATE TABLE " + TABLE_NAME + "("
            + INSTANCE_ID + " INTEGER  PRIMARY KEY AUTOINCREMENT ,"
            + ITEM_TITLE +" TEXT, "
            + ITEM_ARTIST +" TEXT, "
            + DURATION +" TEXT, "
            + ITEM_PATH +" TEXT, "
            + FAVOURITES_STATUS + " TEXT)";
    private String TAG = "FavDB";

    public FavDB(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void insertEmty(){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        for ( int x = 1; x<11;x++ ){
            cv.put(INSTANCE_ID, x);
            cv.put(FAVOURITES_STATUS,"0");
            db.insert(TABLE_NAME, null, cv);
        }
    }

    public void insertIntoTheDatabase(String item_artist, String item_title, String duration,String path, int instance_id, String fav_status){
        SQLiteDatabase db;
        db= this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(ITEM_ARTIST, item_artist);
        cv.put(DURATION, duration);
        cv.put(ITEM_TITLE, item_title);
        cv.put(ITEM_PATH, path);
        cv.put(FAVOURITES_STATUS, fav_status);
        db.insert(TABLE_NAME, null, cv );
        Log.d(TAG,"insert: "+ item_title + ", favstatus : " + fav_status + " - ." + cv);
    }

    public Cursor read_all_data(String path){
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + TABLE_NAME + " where " + INSTANCE_ID+" = ' " + path +" '" ;
        return db.rawQuery(sql, null, null);
    }

    public void remove_fav(String path){
        SQLiteDatabase db =this.getWritableDatabase();
        String sql = "UPDATE " + TABLE_NAME + " SET " + FAVOURITES_STATUS + " = '0' WHERE " + ITEM_PATH + " LIKE ' " + path + " '";
        Log.d(TAG, "remove_fav: "+ path);
        db.execSQL(sql);
    }

    public Cursor select_all_favourite_list(){
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT * FROM " + TABLE_NAME + " where " +  FAVOURITES_STATUS + " = '1' ";
        return db.rawQuery(sql,null,null);
    }
}
