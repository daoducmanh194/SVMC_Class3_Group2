package com.example.musicplayer;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class FavouriteFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;
    private FavDB favDB;
    private ArrayList<AudioModel> favList = new ArrayList<>();
    private FavAdapter favAdapter;
    RecyclerView recyclerView;

    public FavouriteFragment() {
        // Required empty public constructor
    }

    public static FavouriteFragment newInstance(String param1, String param2) {
        FavouriteFragment fragment = new FavouriteFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_favourites,container,false);
        favDB = new FavDB(getActivity());
        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        loadData();
    }

    private void loadData() {
        if(favList != null) {
            favList.clear();
        }
        SQLiteDatabase db = favDB.getReadableDatabase();
        Cursor cursor = favDB.select_all_favourite_list();
        try {
            while (cursor.moveToNext()) {
                @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex(FavDB.ITEM_TITLE));
                @SuppressLint("Range") String artist = cursor.getString(cursor.getColumnIndex(FavDB.ITEM_ARTIST));
                @SuppressLint("Range") String duration = cursor.getString(cursor.getColumnIndex(FavDB.DURATION));
                @SuppressLint("Range") String path = cursor.getString(cursor.getColumnIndex(FavDB.ITEM_PATH));
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(FavDB.INSTANCE_ID));
                @SuppressLint("Range") String favStatus =cursor.getString(cursor.getColumnIndex(FavDB.FAVOURITES_STATUS));

                AudioModel audioModel = new AudioModel(artist, title, duration, path,id, favStatus);
                favList.add(audioModel);
            }
        } finally {
            if(cursor != null && cursor.isClosed()) {
                cursor.close();
            }
            db.close();
        }
        favAdapter = new FavAdapter(getActivity(), favList);
        recyclerView.setAdapter(favAdapter);
    }

    private ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
            return false;
        }

        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
            final int position = viewHolder.getAdapterPosition();
            final AudioModel audioModel = favList.get(position);
            if(direction == ItemTouchHelper.LEFT) {
                favAdapter.notifyItemRemoved(position);
                favList.remove(position);
                favDB.remove_fav(audioModel.getPath());
                Toast.makeText(getContext(), "Da xoa khoi yeu thich", Toast.LENGTH_SHORT).show();
            }
        }
    };
}