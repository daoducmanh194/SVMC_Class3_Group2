package com.example.musicplayer;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import androidx.recyclerview.widget.RecyclerView;

public class MusicListAdapter extends RecyclerView.Adapter<MusicListAdapter.ViewHolder> {

    ArrayList<AudioModel> songsList;
    private ArrayList<AudioModel> favList = new ArrayList<>();
    AudioModel audioModel;
    Context context;
    private FavDB favDB;
    private String TAG = "MusicListAdapter";
    MediaMetadataRetriever mmr = new MediaMetadataRetriever();

    public MusicListAdapter(ArrayList<AudioModel> songsList, Context context) {
        this.songsList = songsList;
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        favDB = new FavDB(context);
        SharedPreferences sharedPreferences = context.getSharedPreferences("pref", context.MODE_PRIVATE);
        boolean firstStart = sharedPreferences.getBoolean("firstStart", true);
        if(firstStart) {
            createTableOnFirstStart();
        }
        View view = LayoutInflater.from(context).inflate(R.layout.recycler_item, parent, false);
        return new MusicListAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(MusicListAdapter.ViewHolder holder, @SuppressLint("RecyclerView") int position) {
        AudioModel songData = songsList.get(position);
        readCursorData();

        holder.titleTextView.setText(songData.getTitle());
        holder.artisTextView.setText(songData.getArtist());

        Log.d(TAG, "path: " + songData.getPath());

        for (int i = 0; i < songsList.size(); i++) {
            for (int j = 0; j< favList.size(); j++) {
                if (songsList.get(i).getPath().equals(favList.get(j).getPath())) {
                    Log.d(TAG, "onBindViewHolder: ");
                    holder.btnFav.setImageResource(R.drawable.ic_favorite);
                }
                else {
                    holder.btnFav.setImageResource(R.drawable.ic_favorite_border);
                }
            }
        }

        try {
            mmr.setDataSource(songData.getPath());
            byte[] artBytes = mmr.getEmbeddedPicture();
            if (artBytes != null) {
                Bitmap bm = BitmapFactory.decodeByteArray(artBytes, 0, artBytes.length);
                holder.iconImageView.setImageBitmap(bm);
            }
        } catch (Exception e) {
            Log.d(TAG, e.toString());
        }

        if (MyMediaPlayer.currentIndex == position) {
            holder.titleTextView.setTextColor(Color.parseColor("#FF0000"));
        } else {
            holder.titleTextView.setTextColor(Color.parseColor("#ffffff"));
        }

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(holder.itemView.getContext(), MusicPlayerService.class);
                intent1.setAction(MusicPlayerService.ACTION_PLAY);
                intent1.putExtra("position", position);
                Log.d(TAG, songsList.get(position).getPath());
                holder.itemView.getContext().startService(intent1);

                MyMediaPlayer.getInstance().reset();
                MyMediaPlayer.currentIndex = position;
                Intent intent = new Intent(context, MusicPlayerActivity.class);
                intent.putExtra("key_list_song", songsList);
                intent.putExtra("pos", position);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        Log.d(TAG, "size: " + songsList.size());
        return songsList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView titleTextView;
        TextView artisTextView;
        ImageView iconImageView;
        ImageView btnFav;

        public ViewHolder(View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.music_title_text);
            artisTextView = itemView.findViewById(R.id.music_artist_text);
            iconImageView = itemView.findViewById(R.id.icon_view);
            btnFav = itemView.findViewById(R.id.favourite_icon);

            btnFav.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    int position = getAdapterPosition();
                    audioModel = songsList.get(position);

                    if (audioModel.getFavStatus().equals("0")){
                        audioModel.setFavStatus("1");
                        favDB.insertIntoTheDatabase(audioModel.getArtist(), audioModel.getTitle(), audioModel.getDuration(),
                                audioModel.getPath(), audioModel.getInstance_id(), audioModel.getFavStatus());
                        btnFav.setImageResource(R.drawable.ic_favorite);
                    } else {
                        audioModel.setFavStatus("0");
                        favDB.remove_fav(audioModel.getPath());
                        btnFav.setImageResource(R.drawable.ic_favorite_border);
                    }
                }
            });
        }
    }

    private void createTableOnFirstStart() {
        favDB.insertEmty();
        SharedPreferences sharedPreferences = context.getSharedPreferences("prefs", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("firstStart", false);

        editor.apply();
    }

    private void readCursorData() {
        SQLiteDatabase db = favDB.getReadableDatabase();
        Cursor cursor = favDB.select_all_favourite_list();
        try {
            while (cursor.moveToNext()) {
                @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex(FavDB.ITEM_TITLE));
                @SuppressLint("Range") String artist = cursor.getString(cursor.getColumnIndex(FavDB.ITEM_ARTIST));
                @SuppressLint("Range") String duration = cursor.getString(cursor.getColumnIndex(FavDB.DURATION));
                @SuppressLint("Range") String path = cursor.getString(cursor.getColumnIndex(FavDB.ITEM_PATH));
                @SuppressLint("Range") int id = cursor.getInt(cursor.getColumnIndex(FavDB.INSTANCE_ID));
                @SuppressLint("Range") String favStatus =cursor.getString(cursor.getColumnIndex(FavDB.FAVOURITES_STATUS));

                AudioModel audioModelFav = new AudioModel(artist, title, duration, path,id, favStatus);
                favList.add(audioModelFav);
            }
        } finally {
            if(cursor != null && cursor.isClosed()) {
                cursor.close();
            }
            db.close();
        }
    }
}
