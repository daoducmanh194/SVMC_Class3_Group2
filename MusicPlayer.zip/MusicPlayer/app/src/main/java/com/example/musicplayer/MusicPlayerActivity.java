package com.example.musicplayer;

import static com.example.musicplayer.MusicPlayerService.ACTION_NEXT;
import static com.example.musicplayer.MusicPlayerService.ACTION_PLAY;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class MusicPlayerActivity extends AppCompatActivity {

    TextView songname, currentTimeTv, totalTimeTv;
    SeekBar seekBar;
    ImageView imageView, playbtn, nextBtn, previousBtn, ffbtn, frbtn;
    ArrayList<AudioModel> songsList;
    MediaPlayer mediaPlayer = MyMediaPlayer.getInstance();
    int x = 0;

    static String TAG = "MusicPlayerActivity";
    MediaMetadataRetriever mmr = new MediaMetadataRetriever();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_music_player);

        getSupportActionBar().hide();
//        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
//        getSupportActionBar().setDisplayShowHomeEnabled(true);

        songname = findViewById(R.id.txtsn);
        currentTimeTv = findViewById(R.id.txtsstart);
        totalTimeTv = findViewById(R.id.txtsstop);
        seekBar = findViewById(R.id.seekbar);
        playbtn = findViewById(R.id.playbtn);
        nextBtn = findViewById(R.id.nextbtn);
        previousBtn = findViewById(R.id.prevbtn);
        ffbtn = findViewById(R.id.ffbtn);
        frbtn = findViewById(R.id.frbtn);

        imageView = findViewById(R.id.imageView);

        songname.setSelected(true);

        songsList = (ArrayList<AudioModel>) getIntent().getSerializableExtra("key_list_song");
        setResourcesWithMusic();
        initMediaPlayer();

        MusicPlayerActivity.this.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                if (mediaPlayer != null) {
                    seekBar.setProgress(mediaPlayer.getCurrentPosition());
                    currentTimeTv.setText(convertToMMSS(mediaPlayer.getCurrentPosition() + ""));

                    if (mediaPlayer.isPlaying()) {
                        playbtn.setImageResource(R.drawable.ic_pause);
                        imageView.setRotation(x++);
                    } else {
                        playbtn.setImageResource(R.drawable.ic_play);
                        //imageView.setRotation(0);
                    }
                }
                new Handler().postDelayed(this, 100);
            }
        });

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (mediaPlayer != null && fromUser) {
                    mediaPlayer.seekTo(progress);
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
        MyBroadCast myBroadCast = new MyBroadCast();
        IntentFilter intentFilter = new IntentFilter(ACTION_NEXT);
        registerReceiver(myBroadCast, intentFilter);
    }

    void initMediaPlayer() {
        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                try {
                    playNextSong();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        try {
            playMusic();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void setImageView(int position) {
        if (position == -1) {
            position = songsList.size() - 1;
        } else if (position == songsList.size()) {
            position = 0;
        }
        mmr.setDataSource(songsList.get(position).getPath());
        byte[] artBytes = mmr.getEmbeddedPicture();
        if (artBytes != null) {
            Bitmap bm = BitmapFactory.decodeByteArray(artBytes, 0, artBytes.length);
            imageView.setImageBitmap(bm);
        } else {
            imageView.setImageResource(R.drawable.music);
        }

        songname.setText(songsList.get(position).getTitle());
        totalTimeTv.setText(convertToMMSS(songsList.get(position).getDuration()));
    }

    void setResourcesWithMusic() {
        playbtn.setOnClickListener(v -> {
            if (mediaPlayer.isPlaying()) {
                pausePlay();
            } else startMusic();
        });
        nextBtn.setOnClickListener(v -> playNextSong());
        previousBtn.setOnClickListener(v -> playPreviousSong());
        ffbtn.setOnClickListener(v -> fastForward());
        frbtn.setOnClickListener(v -> fastRewind());

        setImageView(MyMediaPlayer.currentIndex);

        seekBar.setProgress(0);
        seekBar.setMax(mediaPlayer.getDuration());
    }

    private void playMusic() {
        Intent intent = new Intent(getBaseContext(), MusicPlayerService.class);
        intent.setAction(MusicPlayerService.ACTION_PLAY);
        startService(intent);

        seekBar.setProgress(0);
        seekBar.setMax(mediaPlayer.getDuration());
    }

    private void startMusic() {
        Intent intent = new Intent(getBaseContext(), MusicPlayerService.class);
        intent.setAction(MusicPlayerService.ACTION_START);
        startService(intent);
    }

    private void playNextSong() {
        Intent intent = new Intent(getBaseContext(), MusicPlayerService.class);
        intent.setAction(ACTION_NEXT);
        startService(intent);

        int position = MyMediaPlayer.currentIndex + 1;
        setImageView(position);
    }

    private void playPreviousSong() {
        Intent intent = new Intent(getBaseContext(), MusicPlayerService.class);
        intent.setAction(MusicPlayerService.ACTION_PREV);
        startService(intent);

        int position = MyMediaPlayer.currentIndex - 1;
        setImageView(position);
    }

    private void pausePlay() {
        Intent intent = new Intent(getBaseContext(), MusicPlayerService.class);
        intent.setAction(MusicPlayerService.ACTION_PAUSE);
        startService(intent);
    }

    private void fastForward() {
        Intent intent = new Intent(getBaseContext(), MusicPlayerService.class);
        intent.setAction(MusicPlayerService.ACTION_FF);
        startService(intent);
    }

    private void fastRewind() {
        Intent intent = new Intent(getBaseContext(), MusicPlayerService.class);
        intent.setAction(MusicPlayerService.ACTION_FR);
        startService(intent);
    }

    public static String convertToMMSS(String duration) {
        Long millis = Long.parseLong(duration);
        return String.format("%02d:%02d",
                TimeUnit.MILLISECONDS.toMinutes(millis) % TimeUnit.HOURS.toMinutes(1),
                TimeUnit.MILLISECONDS.toSeconds(millis) % TimeUnit.MINUTES.toSeconds(1));
    }

    public class MyBroadCast extends BroadcastReceiver {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(ACTION_NEXT)) {
                setImageView(MyMediaPlayer.currentIndex);
            }
        }
    }


}