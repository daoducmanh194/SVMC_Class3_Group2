package com.example.musicplayer;

import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.app.TaskStackBuilder;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.RemoteViews;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationCompat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

public class MusicPlayerService extends Service {
    private static final String CHANNEL_ID = "Music play service";
    private String TAG = "MusicPlayerService";
    NotificationCompat.Builder builder;
    MediaPlayer mediaPlayer = MyMediaPlayer.getInstance();
    ArrayList<AudioModel> songsList = new ArrayList<>();
    AudioModel currentSong;
    RemoteViews notificationLayout;
    Notification mNotification;
    NotificationManager notificationManager;

    public static final String ACTION_START = "START";
    public static final String ACTION_STOP = "STOP";
    public static final String ACTION_NEXT = "NEXT";
    public static final String ACTION_PREV = "PREV";
    public static final String ACTION_PAUSE = "PAUSE";
    public static final String ACTION_PLAY = "PLAY";
    public static final String ACTION_FF = "FF";
    public static final String ACTION_FR = "FR";
    private final int NOTIFICATION_ID = 151020;

    @Override
    public void onCreate() {
        String[] projection = {
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.INSTANCE_ID
        };
        Cursor cursor = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, null, null, null);
        int titleColumn = cursor.getColumnIndex
                (android.provider.MediaStore.Audio.Media.TITLE);
        int duration = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
        int path = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
        int artist = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);

        while (cursor.moveToNext()) {
            String thisTitle = cursor.getString(titleColumn);
            String thisDuration = cursor.getString(duration);
            String thisArtist = cursor.getString(artist);
            String thisPath = cursor.getString(path);

            AudioModel songData = new AudioModel(thisArtist, thisTitle, thisDuration, thisPath);
            songsList.add(songData);
        }
        currentSong = songsList.get(MyMediaPlayer.currentIndex);
        mediaPlayer.start();
        foregroundService(currentSong.getTitle(), currentSong.getArtist());
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d(TAG, "onStartCommand");
        if (intent != null) {
            String action = intent.getAction();
            Log.d(TAG, "action: " + action);
            currentSong = songsList.get(MyMediaPlayer.currentIndex);
            if (action != null && action.equals(ACTION_PLAY)) {
                mediaPlayer.reset();
                updateBtnPause();
                try {
                    mediaPlayer.setDataSource(currentSong.getPath());
                    mediaPlayer.prepare();
                    mediaPlayer.start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (action != null && action.equals(ACTION_START)) {
                updateBtnPause();
                mediaPlayer.start();
            } else if (action != null && action.equals(ACTION_PAUSE)) {
                updateBtnPlay();
                if (mediaPlayer.isPlaying())
                    mediaPlayer.pause();
                else
                    mediaPlayer.start();
            } else if (action != null && action.equals(ACTION_NEXT)) {
                if (MyMediaPlayer.currentIndex == songsList.size() - 1) {
                    MyMediaPlayer.currentIndex = 0;
                } else {
                    MyMediaPlayer.currentIndex += 1;
                }
                mediaPlayer.reset();
                currentSong = songsList.get(MyMediaPlayer.currentIndex);
                updateBtnPause();
                try {
                    mediaPlayer.setDataSource(currentSong.getPath());
                    mediaPlayer.prepare();
                    mediaPlayer.start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (action != null && action.equals(ACTION_PREV)) {
                if (MyMediaPlayer.currentIndex == 0) {
                    MyMediaPlayer.currentIndex = songsList.size() - 1;
                } else {
                    MyMediaPlayer.currentIndex -= 1;
                }
                mediaPlayer.reset();
                currentSong = songsList.get(MyMediaPlayer.currentIndex);
                updateBtnPause();
                try {
                    mediaPlayer.setDataSource(currentSong.getPath());
                    mediaPlayer.prepare();
                    mediaPlayer.start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            } else if (action != null && action.equals(ACTION_FF)) {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.seekTo(mediaPlayer.getCurrentPosition() + 10000);
                }
            } else if (action != null && action.equals(ACTION_FR)) {
                if (mediaPlayer.isPlaying()) {
                    mediaPlayer.seekTo(mediaPlayer.getCurrentPosition() - 10000);
                }
            }
        }
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        mediaPlayer.release();
        Log.d(TAG, "onDestroy");
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @SuppressLint("RemoteViewLayout")
    @RequiresApi(api = Build.VERSION_CODES.O)

    void updateBtnPlay() {
        Log.d(TAG, "updateBtnPlay");
        Intent intent = new Intent(getApplicationContext(), MusicPlayerService.class);
        intent.setAction(MusicPlayerService.ACTION_START);

        PendingIntent pendingIntent = PendingIntent.getForegroundService(getApplicationContext(), 0, intent, 0);
        notificationLayout.setOnClickPendingIntent(R.id.playbtn, pendingIntent);

        notificationLayout.setImageViewResource(R.id.playbtn, R.drawable.ic_play);
        notificationLayout.setTextViewText(R.id.title_text_view, currentSong.getTitle());
        notificationLayout.setTextViewText(R.id.artist_text_view, currentSong.getArtist());

        notificationManager.notify(NOTIFICATION_ID, mNotification);
    }

    void updateBtnPause() {
        Log.d(TAG, "updateBtnPause");
        Intent intent = new Intent(getApplicationContext(), MusicPlayerService.class);
        intent.setAction(MusicPlayerService.ACTION_PAUSE);

        PendingIntent pendingIntent = PendingIntent.getForegroundService(getApplicationContext(), 0, intent, 0);
        notificationLayout.setOnClickPendingIntent(R.id.playbtn, pendingIntent);

        notificationLayout.setImageViewResource(R.id.playbtn, R.drawable.ic_pause);
        notificationLayout.setTextViewText(R.id.title_text_view, currentSong.getTitle());
        notificationLayout.setTextViewText(R.id.artist_text_view, currentSong.getArtist());

        notificationManager.notify(NOTIFICATION_ID, mNotification);

        Intent intent22 = new Intent(ACTION_NEXT);
        sendBroadcast(intent22);
    }

    public void foregroundService(String title, String artist) {
        Log.d(TAG, "foregroundService");
        Intent intent = new Intent(getApplicationContext(), MusicPlayerService.class);
        intent.setAction(MusicPlayerService.ACTION_PAUSE);
        PendingIntent pendingIntent = PendingIntent.getForegroundService(getApplicationContext(), 0, intent, 0);

        Intent intentNext = new Intent(getApplicationContext(), MusicPlayerService.class);
        intentNext.setAction(MusicPlayerService.ACTION_NEXT);
        PendingIntent pendingIntentNext = PendingIntent.getForegroundService(getApplicationContext(), 0, intentNext, 0);

        Intent intentPre = new Intent(getApplicationContext(), MusicPlayerService.class);
        intentPre.setAction(MusicPlayerService.ACTION_PREV);
        PendingIntent pendingIntentPre = PendingIntent.getForegroundService(getApplicationContext(), 0, intentPre, 0);

        createNotificationChannel(CHANNEL_ID, "channelName");

        Intent resultIntent = new Intent(this, MusicPlayerActivity.class);
        resultIntent.putExtra("key_list_song", songsList);
        PendingIntent resultPendingIntent =
                PendingIntent.getActivity(this, 0, resultIntent, PendingIntent.FLAG_UPDATE_CURRENT|
                        PendingIntent.FLAG_IMMUTABLE);

        notificationLayout = new RemoteViews(getPackageName(), R.layout.notification_layout);
        notificationLayout.setOnClickPendingIntent(R.id.playbtn, pendingIntent);
        notificationLayout.setOnClickPendingIntent(R.id.nextbtn, pendingIntentNext);
        notificationLayout.setOnClickPendingIntent(R.id.prevbtn, pendingIntentPre);
        notificationLayout.setOnClickPendingIntent(R.id.info, resultPendingIntent);

        notificationLayout.setTextViewText(R.id.title_text_view, title);
        notificationLayout.setTextViewText(R.id.artist_text_view, artist);

        builder = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_music)
                .setContent(notificationLayout)
                .setAutoCancel(true);
        mNotification = builder.build();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, mNotification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIFICATION_ID, mNotification);
        }
    }

    private void createNotificationChannel(String channelId, String channelName) {
        NotificationChannel channel = new NotificationChannel(
                channelId,
                channelName, NotificationManager.IMPORTANCE_NONE
        );

        channel.setLightColor(Color.RED);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);

        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.createNotificationChannel(channel);
    }
}
