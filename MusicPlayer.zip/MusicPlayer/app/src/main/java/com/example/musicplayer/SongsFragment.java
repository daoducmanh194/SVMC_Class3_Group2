package com.example.musicplayer;

import android.database.Cursor;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SongsFragment extends Fragment {

    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    private String mParam1;
    private String mParam2;

    RecyclerView recyclerView;
    TextView noMusicTextView;
    ImageView favouriteEmpty;
    ArrayList<AudioModel> songsList = new ArrayList<>();
    private String TAG = "SongsFragment";

    public static SongsFragment newInstance(String param1, String param2) {
        SongsFragment fragment = new SongsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    public SongsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String[] projection = {
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.DATA,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.INSTANCE_ID
        };

        Cursor cursor = getContext().getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, null, null, null);
        int titleColumn = cursor.getColumnIndex
                (android.provider.MediaStore.Audio.Media.TITLE);
        int duration = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION);
        int path = cursor.getColumnIndex(MediaStore.Audio.Media.DATA);
        int artist = cursor.getColumnIndex(MediaStore.Audio.Media.ARTIST);

        while (cursor.moveToNext()) {
            String thisTitle = cursor.getString(titleColumn);
            String thisDuration = cursor.getString(duration);
            String thisArtist = cursor.getString(artist);
            String thisPath = cursor.getString(path);

            Log.d(TAG, "thisPath " + thisPath);
            AudioModel songData = new AudioModel(thisArtist, thisTitle, thisDuration, thisPath);
            songsList.add(songData);
        }

        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view= inflater.inflate(R.layout.fragment_songs,container,false);

        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        noMusicTextView = view.findViewById(R.id.no_songs_text);
        favouriteEmpty = view.findViewById(R.id.favourite_icon);

        recyclerView.setHasFixedSize(true);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        if (songsList.size() == 0) {
            noMusicTextView.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setLayoutManager(layoutManager);
            recyclerView.setAdapter(new MusicListAdapter(songsList, getActivity().getApplicationContext()));
        }
        return view;
    }
    @Override
    public void onResume() {
        super.onResume();
        if (recyclerView != null) {
            recyclerView.setAdapter(new MusicListAdapter(songsList, getActivity().getApplicationContext()));
        }
    }
}