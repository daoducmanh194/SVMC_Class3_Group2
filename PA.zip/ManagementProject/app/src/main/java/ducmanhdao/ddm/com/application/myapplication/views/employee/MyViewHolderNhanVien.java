package ducmanhdao.ddm.com.application.myapplication.views.employee;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import ducmanhdao.ddm.com.application.myapplication.R;
import ducmanhdao.ddm.com.application.myapplication.entity.NhanVien;

public class MyViewHolderNhanVien extends RecyclerView.ViewHolder implements View.OnClickListener {

    public TextView tennv1, manv1, chucvu1, phongban1;
    private OnClickInterfaceRecyclerView onClickInterfaceRecyclerView;

    public MyViewHolderNhanVien(@NonNull View itemView) {
        super(itemView);
        tennv1 = itemView.findViewById(R.id.txtTennvRecy);
        manv1 = itemView.findViewById(R.id.txtMaNvRecy);
        chucvu1 = itemView.findViewById(R.id.txtChucvuRecy);
        phongban1 = itemView.findViewById(R.id.txtPhongRecy);
    }

    @SuppressWarnings("UseCompatLoadingForDrawables")
    public void bindView(NhanVien nhanVien) {
        manv1.setText(String.valueOf(nhanVien.getMaNV()));
        tennv1.setText(nhanVien.getTenNV());
        chucvu1.setText(nhanVien.getChucVu());
        phongban1.setText(nhanVien.getPhongBan());

    }

    @Override
    public void onClick(View view) {
        onClickInterfaceRecyclerView.onClick(getPosition());
    }


//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_my_view_holder);
//    }
}
