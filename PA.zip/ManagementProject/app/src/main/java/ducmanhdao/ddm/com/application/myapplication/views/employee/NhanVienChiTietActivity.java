package ducmanhdao.ddm.com.application.myapplication.views.employee;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import ducmanhdao.ddm.com.application.myapplication.R;

public class NhanVienChiTietActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nhanvien_chitiet);
    }
}
