package ducmanhdao.ddm.com.application.myapplication.db;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

import ducmanhdao.ddm.com.application.myapplication.entity.CongViec;
import ducmanhdao.ddm.com.application.myapplication.entity.NhanVien;

public class CongViecDAO {
    // Data CongViec(maCV, tenCV, moTa, trangThai, maNV)
    public static ArrayList<CongViec> getAllCongViec(Context context) {
        DataHelper dataHelper = new DataHelper(context);
        SQLiteDatabase db = dataHelper.getWritableDatabase();
        ArrayList<CongViec> cv = new ArrayList<>();
        Cursor cs = db.rawQuery("SELECT * FROM CongViec", null);
        cs.moveToFirst();
        while(!cs.isAfterLast()) {
            int macv = cs.getInt(0);
            String tencv = cs.getString(1);
            String mota = cs.getString(2);
            String trangthai = cs.getString(3);
            int manv = cs.getInt(4);
            CongViec congViec = new CongViec(macv, tencv, mota, trangthai, manv);
            cv.add(congViec);
            cs.moveToNext();
        }
        cs.close();
        db.close();
        return cv;
    }

    public static ArrayList<CongViec> getCongViecByName(Context context, String nameCV) {
        DataHelper dataHelper = new DataHelper(context);
        SQLiteDatabase db = dataHelper.getReadableDatabase();
        ArrayList<CongViec> cv = new ArrayList<CongViec>();
        String[] tmp = {nameCV};
        Cursor cs = db.rawQuery("SELECT * FROM CongViec WHERE tenCV = ?", tmp);
        cs.moveToFirst();
        while(!cs.isAfterLast()) {
            int macv = cs.getInt(0);
            String tencv = cs.getString(1);
            String mota = cs.getString(2);
            String trangthai = cs.getString(3);
            int manv = cs.getInt(4);
            CongViec congViec = new CongViec(macv, tencv, mota, trangthai, manv);
            cv.add(congViec);
            cs.moveToNext();
        }
        cs.close();
        db.close();
        return cv;
    }

    public static ArrayList<CongViec> getCongViecByTrangThai(Context context, String status) {
        DataHelper dataHelper = new DataHelper(context);
        SQLiteDatabase db = dataHelper.getReadableDatabase();
        ArrayList<CongViec> cv = new ArrayList<CongViec>();
        String[] tmp = {status};
        Cursor cs = db.rawQuery("SELECT * FROM CongViec WHERE trangThai = ?", tmp);
        cs.moveToFirst();
        while(!cs.isAfterLast()) {
            int macv = cs.getInt(0);
            String tencv = cs.getString(1);
            String mota = cs.getString(2);
            String trangthai = cs.getString(3);
            int manv = cs.getInt(4);
            CongViec congViec = new CongViec(macv, tencv, mota, trangthai, manv);
            cv.add(congViec);
            cs.moveToNext();
        }
        cs.close();
        db.close();
        return cv;
    }

    public static CongViec getCongViecByMa(Context context, int maCV) {
        DataHelper dataHelper = new DataHelper(context);
        SQLiteDatabase db = dataHelper.getReadableDatabase();
        CongViec congViec = new CongViec();
        String mMaCv = Integer.toString(maCV);
        String[] tmp = {mMaCv};
        Cursor cs=db.rawQuery("Select * from CongViec WHERE maCV = ?", tmp);
        cs.moveToFirst();
        while (!cs.isAfterLast()){
            congViec.setMaCV(cs.getInt(0));
            congViec.setTenCV(cs.getString(1));
            congViec.setMoTa(cs.getString(2));
            congViec.setTrangThai(cs.getString(3));
            congViec.setMaNV(cs.getInt(4));
        }
        cs.close();
        db.close();
        return congViec;
    };

    public static boolean insert (Context context,String tencv, String mota, String trangthai, int manv){
        DataHelper helper = new DataHelper(context);
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("tenCV", tencv);
        values.put("moTa", mota);
        values.put("trangThai", trangthai);
        values.put("maNV", manv);

        long row=db.insert("CongViec",null, values);
        return (row>0);
    }

    public static boolean deleteCongViec(Context context, int vitri) {
        ArrayList<CongViec>ds=new ArrayList<>();
        DataHelper helper = new DataHelper(context);
        SQLiteDatabase db = helper.getReadableDatabase();
        String[] tmp= {String.valueOf(vitri)};
        Cursor cs=db.rawQuery("delete from CongViec Where maCV= ? ", tmp);
        cs.moveToFirst();
        while (!cs.isAfterLast()){
            int macv= cs.getInt(0);
            String tencv =  cs.getString(1);
            String mota = cs.getString(2);
            String trangthai = cs.getString(3);
            int manv = cs.getInt(4);
            CongViec congViec = new CongViec(macv, tencv, mota, trangthai, manv);
            ds.remove(congViec);
            cs.moveToNext();
        }
        cs.close();
        db.close();

        return true;
    }

    public static boolean updateCongViec(Context context, String macv, String tencv, String mota, String trangthai, String manv) {
        DataHelper helper = new DataHelper(context);
        SQLiteDatabase db = helper.getReadableDatabase();
        String[] tmp = {tencv, mota, trangthai, manv, macv};
        Cursor cs = db.rawQuery("Update CongViec SET tenCV = ? , moTa = ?, trangThai = ?, maNV = ? Where maCV= ?",tmp);
        cs.moveToFirst();
        int dem=0;
        while (!cs.isAfterLast()){
            dem++;
        }
        cs.close();
        db.close();
        return (dem>=0);
    }
}
