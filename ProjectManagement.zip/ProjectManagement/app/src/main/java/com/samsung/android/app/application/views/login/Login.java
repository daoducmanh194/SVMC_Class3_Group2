package com.samsung.android.app.application.views.login;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import com.samsung.android.app.application.R;

public class Login extends AppCompatActivity {

    private static final String TAG = "NewActivityTag";
    private ImageView mainImageView, mailImageView, passImageView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Log.d(TAG, "onCreate");
        mainImageView.findViewById(R.id.imageView);
        mainImageView.setImageResource(R.drawable.ic_launcher_pm);
        mailImageView.findViewById(R.id.imageViewMail);
        mailImageView.setImageResource(R.drawable.ic_launcher_gmail);
        passImageView.findViewById(R.id.imageViewPass);
        passImageView.setImageResource(R.drawable.ic_launcher_password);
    }

}
