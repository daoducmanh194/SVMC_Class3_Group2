package com.example.recyclerview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyViewHolder> {
    private static final String TAG = "MyAdapter";
    private ArrayList<DataItem> dataItemArrayList = new ArrayList<DataItem>();

    public MyAdapter(){
        dataItemArrayList.add(new DataItem("Title text", "Context",R.drawable.ic_launcher_background));
        dataItemArrayList.add(new DataItem("Nguyen Van A", "abc",R.drawable.ic_launcher_background));
        dataItemArrayList.add(new DataItem("Nguyen Thi B", "nbg",R.drawable.ic_launcher_background));
        dataItemArrayList.add(new DataItem("Title text", "Context",R.drawable.ic_launcher_background));
        dataItemArrayList.add(new DataItem("Title text", "Context",R.drawable.ic_launcher_background));
        dataItemArrayList.add(new DataItem("Title text", "Context",R.drawable.ic_launcher_background));
        dataItemArrayList.add(new DataItem("Title text", "Context",R.drawable.ic_launcher_background));
    }
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item,parent,false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position){
        holder.bindView(dataItemArrayList.get(position));
    }

    @Override
    public int getItemCount(){return dataItemArrayList.size();}

    public void removeItem(int position){
        Log.d(TAG,"removeItem" + position);
        notifyItemRemoved(position);
        dataItemArrayList.remove(position);
    }

    public  DataItem getDataAt(int position){return dataItemArrayList.get(position);}

    public void add(int position, DataItem dataItem){
        dataItemArrayList.add(position,dataItem);
        notifyItemInserted(position);
    }
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_my_adapter);
//    }
}