package com.example.recyclerview;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MyViewHolder extends RecyclerView.ViewHolder {

    private TextView titleText;
    private TextView contentText;
    private ImageView imageView;

    public MyViewHolder(@NonNull View itemView){
        super(itemView);
        titleText = itemView.findViewById(R.id.title_text_view);
        contentText = itemView.findViewById(R.id.content_text);
        imageView = itemView.findViewById(R.id.image_note);
    }

    @SuppressWarnings("UseCompatLoadingForDrawables")
    public void bindView(DataItem dataItem){
        titleText.setText(dataItem.getTitle());
        contentText.setText(dataItem.getContent());
        imageView.setImageResource(dataItem.getImage());
    }

//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_my_view_holder);
//    }
}