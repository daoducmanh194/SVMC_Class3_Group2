package com.example.svmc_2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DataHelper extends SQLiteOpenHelper {

    public DataHelper(Context context) {
        super(context, "SVMC", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String sql = "Create table NhanVien (maNV integer primary key autoincrement," +
                "tenNV text,diaChi text,sdt text, email text,chucVu text, phongBan text, kinhNghiem text,taiKhoan text, matKhau text)";
        sqLiteDatabase.execSQL(sql);
        sql = "Insert Into NhanVien values (null,'Thang','Hà Nội','123456789','1@gmail.com','Trưởng phong','Phòng kế toán','Không có','admin','admin')";
        sqLiteDatabase.execSQL(sql);
        sql = "Insert Into NhanVien values (null,'Son','Hà Nội','123456789','1@gmail.com','Trưởng phong','Phòng nhân sự','Không có','admin','admin')";
        sqLiteDatabase.execSQL(sql);
        sql = "Insert Into NhanVien values (null,'Bao','Hà Nội','123456789','1@gmail.com','Trưởng phong','Phòng kỹ thuật','Không có','admin','admin')";
        sqLiteDatabase.execSQL(sql);
        sql = "Insert Into NhanVien values (null,'Manh','Hà Nội','123456789','1@gmail.com','Trưởng phong','Phòng nhân sự','Không có','admin','admin')";
        sqLiteDatabase.execSQL(sql);
//        String sql1 = "Create table CongViec ("+"maCV integer primary key autoincrement," +
//                "tenCV text,"+"moTa text,"+" maNV integer "+" foreign key REFERENCES NhanVien(maNV) ON DELETE CASCADE  )";
//        sqLiteDatabase.execSQL(sql1);
//        sql1 = "Insert Into CongViec values (null,'Bảo Vệ','Không mô tả',0)";
//        sqLiteDatabase.execSQL(sql1);
    }



    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("Drop table if exists NhanVien");
        //sqLiteDatabase.execSQL("Drop table if exists CongViec");
        onCreate(sqLiteDatabase);
    }

}
