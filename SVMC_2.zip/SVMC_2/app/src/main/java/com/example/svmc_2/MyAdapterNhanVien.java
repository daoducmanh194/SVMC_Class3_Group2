package com.example.svmc_2;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import static android.widget.Toast.*;

public class MyAdapterNhanVien extends RecyclerView.Adapter<MyViewHolderNhanVien> {
    private static final String TAG = "MyAdapter";
    private ArrayList<NhanVien> danhSachNv = new ArrayList<NhanVien>();

    public MyAdapterNhanVien(Context context,String ten,String phongBan){
        if(ten == null && phongBan == null){
            danhSachNv=NhanVienDAO.getAllNhanVien(context);}
        else if (ten != null && phongBan == null){
            danhSachNv=NhanVienDAO.getNhanVienTheoTen(context,ten);
        }if (ten == null && phongBan != null){
            danhSachNv=NhanVienDAO.getNhanVienTheoPhongBan(context,phongBan);
        }
    }
    @Override
    public MyViewHolderNhanVien onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item_bao,parent,false);
        return new MyViewHolderNhanVien(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolderNhanVien holder, @SuppressLint("RecyclerView") int position){
        holder.bindView(danhSachNv.get(position));

    }



    @Override
    public int getItemCount(){return danhSachNv.size();}

    public void removeItem(int position){
        Log.d(TAG,"removeItem" + position);
        notifyItemRemoved(position);
        danhSachNv.remove(position);
    }

    public  NhanVien getDataAt(int position){return danhSachNv.get(position);}

    public void add(int position, NhanVien nhanVien){
        danhSachNv.add(position,nhanVien);
        notifyItemInserted(position);
    }
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_my_adapter);
//    }
}