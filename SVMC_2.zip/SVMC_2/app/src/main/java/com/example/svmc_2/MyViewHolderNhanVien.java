package com.example.svmc_2;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyViewHolderNhanVien extends RecyclerView.ViewHolder {

    public TextView tennv1,manv1;
    public Button btnxem;


    public MyViewHolderNhanVien(@NonNull View itemView){
        super(itemView);
        tennv1 = itemView.findViewById(R.id.txtTenNv1);
        manv1 = itemView.findViewById(R.id.txtManv1);
        btnxem = itemView.findViewById(R.id.btnXem);

    }

    @SuppressWarnings("UseCompatLoadingForDrawables")
    public void bindView(NhanVien nhanVien){
        manv1.setText(String.valueOf(nhanVien.getTenNV()));
        tennv1.setText(nhanVien.getPhongBan());

    }


//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_my_view_holder);
//    }
}