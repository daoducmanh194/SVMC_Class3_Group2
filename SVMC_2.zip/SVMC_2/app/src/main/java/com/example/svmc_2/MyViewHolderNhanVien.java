package com.example.svmc_2;

import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyViewHolderNhanVien extends RecyclerView.ViewHolder {

    public TextView tennv1, manv1, chucvu1, phongban1;


    public MyViewHolderNhanVien(@NonNull View itemView) {
        super(itemView);
        tennv1 = itemView.findViewById(R.id.txtTennvRecy);
        manv1 = itemView.findViewById(R.id.txtMaNvRecy);
        chucvu1 = itemView.findViewById(R.id.txtChucvuRecy);
        phongban1 = itemView.findViewById(R.id.txtPhongRecy);
    }

    @SuppressWarnings("UseCompatLoadingForDrawables")
    public void bindView(NhanVien nhanVien) {
        manv1.setText(String.valueOf(nhanVien.getMaNV()));
        tennv1.setText(nhanVien.getTenNV());
        chucvu1.setText(nhanVien.getChucVu());
        phongban1.setText(nhanVien.getPhongBan());

    }


//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_my_view_holder);
//    }
}