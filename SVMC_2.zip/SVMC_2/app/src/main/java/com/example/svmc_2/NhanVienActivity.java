package com.example.svmc_2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

public class NhanVienActivity extends AppCompatActivity {
    TextView txtDsNV;
    EditText editSearchTen;
    Button btnSearchTen;
    ListView lvNhanVien;
    Spinner spinner;
    ArrayList<NhanVien> dsNv=new ArrayList<>();
    ArrayAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nhan_vien);

        txtDsNV=findViewById(R.id.txtDsNV);
        //lvNhanVien=findViewById(R.id.lvNhanVien);
        editSearchTen=findViewById(R.id.editSearchTheoTen);
        btnSearchTen=findViewById(R.id.btnTimKiemTheoTen);
        spinner=findViewById(R.id.spinnerSearchTheoPhong);
        //Lấy toàn bộ nhân viên
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        txtDsNV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                dsNv=NhanVienDAO.getAllNhanVien(NhanVienActivity.this);
//                adapter= new ArrayAdapter(NhanVienActivity.this, android.R.layout.simple_list_item_1,dsNv);
//                lvNhanVien.setAdapter(adapter);

                //Sủ dụng RecyleView
                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(NhanVienActivity.this);
                linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                recyclerView.setLayoutManager(linearLayoutManager);

                //display like GridView

                MyAdapterNhanVien myAdapter = new MyAdapterNhanVien(NhanVienActivity.this,null,null);
                recyclerView.setAdapter(myAdapter);
                //xử lý xóa khi vuốt sang phải
                ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
                    @Override
                    public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                        return false;
                    }

                    @Override
                    public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                        if(direction == ItemTouchHelper.RIGHT){
                            int positon = viewHolder.getAdapterPosition();
                            NhanVien dataItem = myAdapter.getDataAt(positon);
                            myAdapter.removeItem(positon);
                            //Snackbar.make(recyclerView,"Deleted" + dataItem.getTenNV(),Snackbar.LENGTH_LONG).setAction("Undo", view -> myAdapter.add(positon,dataItem)).show();
                            // khởi tạo AlertDialog từ đối tượng Builder. tham số truyền vào ở đây là context.
                            AlertDialog.Builder builder = new AlertDialog.Builder(NhanVienActivity.this);

                            // set Message là phương thức thiết lập câu thông báo
                            builder.setMessage("Xác nhận xóa nhân viên !")
                                    // positiveButton là nút thuận : đặt là OK
                                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            NhanVienDAO.deleteNhanVien(NhanVienActivity.this,positon);
                                            //myAdapter.removeItem(positon);
                                        }
                                    })
                                    // ngược lại negative là nút nghịch : đặt là cancel
                                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            // User cancelled the dialog
                                            myAdapter.add(positon,dataItem);
                                            recyclerView.setAdapter(myAdapter);
                                        }
                                    });
                            // tạo dialog và hiển thị
                            builder.create().show();
                        }
                    }
                };
                ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
                itemTouchHelper.attachToRecyclerView(recyclerView);

            }
        });

        //Tìm kiếm nhân viên theo tên
        btnSearchTen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ten=editSearchTen.getText().toString();
                //sử dụng listview
//                dsNv=NhanVienDAO.getNhanVienTheoTen(NhanVienActivity.this,ten);
//                adapter= new ArrayAdapter(NhanVienActivity.this, android.R.layout.simple_list_item_1,dsNv);
//                lvNhanVien.setAdapter(adapter);
                //Sủ dụng RecyleView
                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(NhanVienActivity.this);
                linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                recyclerView.setLayoutManager(linearLayoutManager);

                //display like GridView

                MyAdapterNhanVien myAdapter = new MyAdapterNhanVien(NhanVienActivity.this,ten,null);
                recyclerView.setAdapter(myAdapter);
                editSearchTen.setText("");
            }
        });

        //Tìm kiếm nhân viên theo phòng ban
        //xử lý spinner
        String phongBan[]= {"--Chọn phòng ban--","Phòng kế toán","Phòng nhân sự","Phòng kỹ thuật"};

        ArrayAdapter<String >adapter1= new ArrayAdapter<>(NhanVienActivity.this, android.R.layout.simple_list_item_1,phongBan);
        adapter1.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spinner.setAdapter(adapter1);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                //Sủ dụng RecyleView
                String phongBan1= phongBan[i];
                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(NhanVienActivity.this);
                linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                recyclerView.setLayoutManager(linearLayoutManager);

                //display like GridView

                MyAdapterNhanVien myAdapter = new MyAdapterNhanVien(NhanVienActivity.this,null,phongBan1);
                recyclerView.setAdapter(myAdapter);
                editSearchTen.setText("");
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        //Xử lý khi ấn vào nút Xem chi tiết


    }
}