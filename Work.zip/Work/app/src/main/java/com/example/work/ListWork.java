package com.example.work;

public class ListWork {
    int STT;
    String nameWork;
    String statusWork;
    String viewWork;

    public ListWork(int STT, String nameWork, String statusWork, String viewWork) {
        this.STT = STT;
        this.nameWork = nameWork;
        this.statusWork = statusWork;
        this.viewWork = viewWork;
    }

    public String getSTT() {
        return STT;
    }

    public String getNameWork() {
        return nameWork;
    }

    public String getStatusWork() {
        return statusWork;
    }

    public String getViewWork() {
        return viewWork;
    }

}
