package com.example.work;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.text.BreakIterator;
import java.util.List;

public class ListWorkAdapter extends RecyclerView.Adapter<ListWorkAdapter.ViewHolder> {

    Context context;
    List<ListWork> work_list;

    public ListWorkAdapter(Context context, List<ListWork> work_list) {
        this.context = context;
        this.work_list = work_list;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_layout,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (work_list != null && work_list.size() > 0){
            ListWork model = work_list.get(position);
            holder.stt_tv.setText(model.getSTT());
            holder.tencv_tv.setText(model.getNameWork());
            holder.trangthai_tv.setText(model.getStatusWork());
            holder.mota_tv.setText(model.getViewWork());

        }else{
            return;
        }
    }

    @Override
    public int getItemCount() {
        return work_list.size();
    }

    public  class ViewHolder extends RecyclerView.ViewHolder{
        TextView stt_tv, tencv_tv,trangthai_tv,mota_tv,them_tv;
        public ViewHolder(@NonNull View itemView){
            super(itemView);

            stt_tv = itemView.findViewById(R.id.stt_tv);
            tencv_tv = itemView.findViewById(R.id.tencv_tv);
            trangthai_tv = itemView.findViewById(R.id.trangthai_tv);
            mota_tv = itemView.findViewById(R.id.mota_tv);
            them_tv = itemView.findViewById(R.id.them_tv);
        }
    }

}
