package com.example.work;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class WorkTable extends AppCompatActivity {
    RecyclerView recyclerview;
    ListWorkAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_table);

        recyclerview = findViewById(R.id.recyclerview);

        setRecyclerView();
    }

    private void setRecyclerView() {
        recyclerview.setHasFixedSize(true);
        recyclerview.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ListWorkAdapter(this,getList());
        recyclerview.setAdapter(adapter);
    }

    private List<ListWork> getList(){
        List<ListWork> workList = new ArrayList<>();
        workList.add(new ListWork(1,"abc","done","xem"));

        return workList;
    }
}