package com.example.myapplication;

import androidx.recyclerview.widget.RecyclerView;

public class CoffeeAdapter extends RecyclerView.Adapter<CoffeeAdapter.View>{
}
