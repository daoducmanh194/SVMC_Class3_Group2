package com.example.myapplication.API;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.Log;

import androidx.annotation.NonNull;

import com.example.myapplication.struct.Item;
import com.example.myapplication.struct.PartialItem;
import com.example.myapplication.struct.PartialOrder;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.function.Consumer;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class API {
    private
    static final OkHttpClient client = new OkHttpClient();
    static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    static final Handler mHandler = new Handler(Looper.getMainLooper());
    public static final String BASE_URL = "http://107.113.195.88/";

    private static void makeGetRequest(String endpoint, Consumer<String> consumer) {
        Log.d("GET", "/" + endpoint);
        Request request = new Request.Builder()
                .url(BASE_URL + endpoint)
                .get()
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) {
                try {
                    ResponseBody res = response.body();
                    if (res == null) {
                        Log.e("API/" + endpoint, " Response body is null");
                        return;
                    }
                    String data = res.string();
                    res.close();
                    mHandler.post(() -> consumer.accept(data));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private static void makePostRequest(String endpoint, JSONObject json, Consumer<String> consumer) {
        Log.d("POST/" + endpoint, json.toString());
        RequestBody body = RequestBody.create(json.toString(), JSON);
        Request request = new Request.Builder()
                .url(BASE_URL + endpoint)
                .post(body)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) {
                try {
                    ResponseBody res = response.body();
                    if (res == null) {
                        Log.e("API/" + endpoint, " Response body is null");
                        return;
                    }
                    String data = res.string();
                    res.close();
                    mHandler.post(() -> consumer.accept(data));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public static void GetStoreInfo(String tableId, Consumer<ApiStore> consumer) {
        makeGetRequest("table/" + tableId, response -> {
            ApiStore store = new Gson().fromJson(response, ApiStore.class);
            consumer.accept(store);
        });
    }

    public static void CheckTableExists(String tableId, Consumer<Boolean> consumer) {
        makeGetRequest("checkTable/" + tableId, response -> {
            ApiCheckTable checkTable = new Gson().fromJson(response, ApiCheckTable.class);
            consumer.accept(checkTable.available);
        });
    }

    public static void GetOrderInfo(String orderId, Consumer<ApiOrder> consumer) {
        makeGetRequest("order/" + orderId, response -> {
            ApiOrder order = new Gson().fromJson(response, ApiOrder.class);
            consumer.accept(order);
        });
    }

    public static void CreateOrder(PartialOrder order, Consumer<String> consumer) {
        JSONObject body = new JSONObject();
        ArrayList<PartialItem> items = new ArrayList<>();
        for (Item item : order.items) {
            if (item.quantity > 0) {
                items.add(new PartialItem(item.id, item.quantity));
            }
        }
        try {
            body.put("tableId", order.tableId);
            body.put("tableName", order.tableName);
            body.put("items", new JSONArray(new Gson().toJson(items)));
            makePostRequest("order", body, response -> {
                ApiCreateOrder apiCreateOrder = new Gson().fromJson(response, ApiCreateOrder.class);
                consumer.accept(apiCreateOrder.id);
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static void GetImage(String itemId, Consumer<Bitmap> consumer) {
        makeGetRequest("image/" + itemId, data -> {
            ApiImage apiImage = new Gson().fromJson(data, ApiImage.class);
            byte[] decodedString = Base64.decode(apiImage.image, Base64.DEFAULT);
            Bitmap image = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
            mHandler.post(() -> consumer.accept(image));
        });
    }
}
