package com.example.myapplication.API;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ApiCheckTable {
    @SerializedName("available")
    @Expose
    public boolean available;
}
