package com.example.myapplication.API;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ApiImage {
    @SerializedName("image")
    @Expose
    public String image;
}
