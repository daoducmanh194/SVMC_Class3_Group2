package com.example.myapplication.API;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ApiItem {
    @SerializedName("name")
    @Expose
    public String name;
    @SerializedName("description")
    @Expose
    public String description;
    @SerializedName("available")
    @Expose
    public boolean available;
    @SerializedName("price")
    @Expose
    public int price;
    @SerializedName("id")
    @Expose
    public String id;
    @SerializedName("status")
    @Expose
    public int status;
    @SerializedName("quantity")
    @Expose
    public int quantity;
}
