package com.example.myapplication.API;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ApiOrderItem {
    @SerializedName("id")
    @Expose
    public String id;
    @SerializedName("quantity")
    @Expose
    public int quantity;
}
