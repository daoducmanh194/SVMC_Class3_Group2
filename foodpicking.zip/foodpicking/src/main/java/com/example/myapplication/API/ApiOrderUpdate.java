package com.example.myapplication.API;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ApiOrderUpdate {
    @SerializedName("orderId")
    @Expose
    public String orderId;
    @SerializedName("itemId")
    @Expose
    public String itemId;
    @SerializedName("itemName")
    @Expose
    public String itemName;
    @SerializedName("status")
    @Expose
    public int status;
}
