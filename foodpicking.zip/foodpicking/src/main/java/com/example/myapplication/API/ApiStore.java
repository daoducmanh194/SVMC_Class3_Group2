package com.example.myapplication.API;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class ApiStore {
    @SerializedName("name")
    @Expose
    public String name;
    @SerializedName("address")
    @Expose
    public String address;
    @SerializedName("id")
    @Expose
    public String id;
    @SerializedName("tableId")
    @Expose
    public String tableId;
    @SerializedName("tableName")
    @Expose
    public String tableName;
    @SerializedName("items")
    @Expose
    public ArrayList<ApiItem> items = null;
}
