package com.example.myapplication.API;

public enum Status {
    Pending,
    Ready,
    Denied,
}
