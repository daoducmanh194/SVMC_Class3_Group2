package com.example.myapplication;

import android.app.Application;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.google.common.util.concurrent.ListenableFuture;

import java.util.concurrent.ExecutionException;

public class CameraXViewModel extends AndroidViewModel {
    private final String TAG = "CameraXViewModel";
    private final MutableLiveData<ProcessCameraProvider> cameraProviderLiveData = new MutableLiveData<>();

    public CameraXViewModel(@NonNull Application application) {
        super(application);
    }

    public LiveData<ProcessCameraProvider> getPCP() {
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture = ProcessCameraProvider.getInstance(getApplication());
        cameraProviderFuture.addListener(() -> {
            try {
                cameraProviderLiveData.setValue(cameraProviderFuture.get());
            } catch (ExecutionException | InterruptedException e) {
                Log.e(TAG, "Unhandled exception", e);
            }
        }, ContextCompat.getMainExecutor(getApplication()));
        return cameraProviderLiveData;
    }
}
