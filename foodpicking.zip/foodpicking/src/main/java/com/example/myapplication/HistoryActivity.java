package com.example.myapplication;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;

import com.example.myapplication.struct.HistoryOrder;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class HistoryActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        RecyclerView rcv = findViewById(R.id.historyList);
        SharedPreferences sp = getSharedPreferences("history", MODE_PRIVATE);
        int size = sp.getInt("size", 0);
        ArrayList<HistoryOrder> items = new ArrayList<>();
        for (int i = 0; i < size; i++) {
            HistoryOrder item = new HistoryOrder(sp.getString("id_" + i, ""), sp.getLong("time_" + i, 0));
            items.add(item);
            Log.d("Item", item.id + ", " + item.getFormattedTime());
        }
        HistoryOrderAdapter itemAdapter = new HistoryOrderAdapter(items);
        rcv.setAdapter(itemAdapter);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        rcv.setLayoutManager(layoutManager);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(this, layoutManager.getOrientation());
        rcv.addItemDecoration(dividerItemDecoration);
    }
}