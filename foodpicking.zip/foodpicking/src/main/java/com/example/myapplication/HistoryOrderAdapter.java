package com.example.myapplication;

import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.myapplication.struct.HistoryOrder;

import java.util.ArrayList;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

class HistoryOrderAdapter extends RecyclerView.Adapter<HistoryOrderAdapter.OrderViewHolder> {
    private final ArrayList<HistoryOrder> arraylist;

    public HistoryOrderAdapter(ArrayList<HistoryOrder> arraylist) {
        this.arraylist = arraylist;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.history_item, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        HistoryOrder order = arraylist.get(position);
        holder.idView.setText("#" + order.id);
        holder.dateView.setText(order.getFormattedTime());
        holder.orderLayout.setOnClickListener(view -> {
            Intent intent = new Intent(holder.dateView.getContext(), OrderActivity.class);
            intent.putExtra("orderId", order.id);
            holder.dateView.getContext().startActivity(intent);
        });
    }


    @Override
    public int getItemCount() {
        return arraylist == null ? 0 : arraylist.size();
    }

    static class OrderViewHolder extends RecyclerView.ViewHolder {
        private final
        TextView idView;
        TextView dateView;
        ConstraintLayout orderLayout;

        public OrderViewHolder(@NonNull View view) {
            super(view);
            idView = view.findViewById((R.id.orderId));
            dateView = view.findViewById((R.id.orderDate));
            orderLayout = view.findViewById(R.id.orderLayout);
        }
    }
}
