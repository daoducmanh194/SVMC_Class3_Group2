package com.example.myapplication;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.API.API;
import com.example.myapplication.struct.Item;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;

class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {
    private final ArrayList<Item> arraylist;
    private OnValueChangedListener mValueChangedListener;

    public ItemAdapter(ArrayList<Item> arraylist) {
        this.arraylist = arraylist;
    }

    public void setOnValueChangedListener(final OnValueChangedListener mValueChangedListener) {
        this.mValueChangedListener = mValueChangedListener;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item, parent, false);
        return new ItemViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    private void OnQuantityChanged(ItemViewHolder holder, Item item) {
        int visibility = View.VISIBLE;
        if (item.quantity == 0) visibility = View.GONE;
        holder.quantityView.setText(Integer.toString(item.quantity));
        holder.quantityView.setVisibility(visibility);
        holder.minusButtonView.setVisibility(visibility);
        mValueChangedListener.onValueChanged();
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        Item item = arraylist.get(position);
        Context ctx = holder.textView1.getContext();
        Visual.startAnimatedBackground(holder.quantityLayout);
        holder.textView1.setText(item.name);
        holder.textView2.setText(String.format(ctx.getString(R.string.price), item.price));
        holder.imageView.setClipToOutline(true);
        API.GetImage(item.id, holder.imageView::setImageBitmap);
        if (item.available) {
            holder.plusButtonView.setOnClickListener(view -> {
                item.quantity += 1;
                OnQuantityChanged(holder, item);
            });
            holder.minusButtonView.setOnClickListener(view -> {
                item.quantity -= 1;
                OnQuantityChanged(holder, item);
            });
            holder.quantityView.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                }

                @Override
                public void afterTextChanged(Editable editable) {
                    if (editable.toString().length() == 0) return;
                    int i = Integer.parseInt(editable.toString());
                    if (item.quantity != i) {
                        item.quantity = i;
                        OnQuantityChanged(holder, item);
                    }
                }
            });
        } else {
            holder.plusButtonView.setEnabled(false);
            holder.plusButtonView.setBackgroundColor(ctx.getColor(R.color.disabled));
        }
    }


    @Override
    public int getItemCount() {
        return arraylist == null ? 0 : arraylist.size();
    }

    public interface OnValueChangedListener {
        void onValueChanged();
    }

    static class ItemViewHolder extends RecyclerView.ViewHolder {
        private final
        TextView textView1;
        TextView textView2;
        ImageView imageView;
        MaterialButton plusButtonView;
        MaterialButton minusButtonView;
        EditText quantityView;
        ConstraintLayout quantityLayout;

        public ItemViewHolder(@NonNull View view) {
            super(view);
            textView1 = view.findViewById((R.id.textView4));
            textView2 = view.findViewById((R.id.textView6));
            imageView = view.findViewById(R.id.image);
            quantityView = view.findViewById(R.id.itemQuantity);
            minusButtonView = view.findViewById(R.id.minusButton);
            plusButtonView = view.findViewById(R.id.plusButton);
            quantityLayout = view.findViewById(R.id.quantityLayout);
        }
    }
}
