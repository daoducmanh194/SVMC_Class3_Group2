package com.example.myapplication;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Surface;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.AspectRatio;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.ViewModelProvider;

import com.example.myapplication.API.API;
import com.google.android.material.snackbar.Snackbar;
import com.google.mlkit.vision.barcode.BarcodeScanner;
import com.google.mlkit.vision.barcode.BarcodeScannerOptions;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.barcode.common.Barcode;
import com.google.mlkit.vision.common.InputImage;

import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private final
    String TAG = MainActivity.class.getName();
    public
    boolean isProcessing = false;
    String[] REQUIRED_PERMISSIONS = {Manifest.permission.CAMERA};
    int REQUEST_CODE_PERMISSIONS = 10;
    ProcessCameraProvider cameraProvider;
    CameraSelector cameraSelector;
    Preview previewUseCase;
    ImageAnalysis analysisUseCase;
    boolean isStarted = false;
    private
    PreviewView previewView;

    private boolean isAllPermissionsGranted() {
        return Arrays.stream(REQUIRED_PERMISSIONS)
                .noneMatch(p ->
                        ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED
                );
    }

    private void requestPermissions() {
        ActivityCompat.requestPermissions(this, REQUIRED_PERMISSIONS, REQUEST_CODE_PERMISSIONS);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE_PERMISSIONS) {
            if (isAllPermissionsGranted()) {
                startCamera();
            } else {
                PreviewView previewView = findViewById(R.id.preview_view);
                Snackbar.make(previewView, "Camera permission not granted.\nCannot scan QR Code.", Snackbar.LENGTH_LONG)
                        .setAction("Retry", view -> requestPermissions())
                        .show();
            }
        }
    }

    private void startCamera() {
        previewView = findViewById(R.id.preview_view);
        cameraSelector = new CameraSelector.Builder().requireLensFacing(CameraSelector.LENS_FACING_BACK).build();
        new ViewModelProvider(
                this, (ViewModelProvider.Factory) ViewModelProvider.AndroidViewModelFactory.getInstance(this.getApplication())
        ).get(CameraXViewModel.class)
                .getPCP()
                .observe(this, provider -> {
                    cameraProvider = provider;
                    bindCameraUseCases();
                });
    }

    private void bindCameraUseCases() {
        bindPreviewUseCase();
        bindAnalyseUseCase();

    }

    private void bindAnalyseUseCase() {
        if (cameraProvider == null) return;
        if (analysisUseCase != null) cameraProvider.unbind(analysisUseCase);

        BarcodeScannerOptions options =
                new BarcodeScannerOptions.Builder()
                        .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
                        .build();
        BarcodeScanner barcodeScanner = BarcodeScanning.getClient(options);


        analysisUseCase = new ImageAnalysis.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_16_9)
                .setTargetRotation(Surface.ROTATION_0)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_BLOCK_PRODUCER)
                .build();

        ExecutorService cameraExecutor = Executors.newSingleThreadExecutor();

        analysisUseCase.setAnalyzer(
                cameraExecutor,
                imageProxy -> processImageProxy(barcodeScanner, imageProxy)
        );

        cameraProvider.bindToLifecycle(this, cameraSelector, analysisUseCase);
    }

    @SuppressLint("UnsafeOptInUsageError")
    private void processImageProxy(BarcodeScanner barcodeScanner, ImageProxy imageProxy) {
        if (imageProxy.getImage() == null) return;
        InputImage inputImage = InputImage.fromMediaImage(imageProxy.getImage(), imageProxy.getImageInfo().getRotationDegrees());
        barcodeScanner.process(inputImage)
                .addOnSuccessListener(barcodes -> {
                    if (barcodes.size() == 0) return;
                    for (Barcode barcode : barcodes) {
                        String tableId = barcode.getRawValue();
                        Log.d(TAG, tableId);
                        if (tableId == null || tableId.length() != 36) return;
                        API.CheckTableExists(tableId, available -> {
                            if (available && !isStarted) {
                                isStarted = true;
                                Intent intent = new Intent(MainActivity.this, MenuActivity.class);
                                intent.putExtra("tableId", tableId);
                                startActivity(intent);
                            }
                        });
                    }
                })
                .addOnFailureListener(e -> Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT))
                .addOnCompleteListener(barcodes -> {
                    imageProxy.close();
                });
    }

    private void bindPreviewUseCase() {
        if (cameraProvider == null) return;
        if (previewUseCase != null) cameraProvider.unbind(previewUseCase);
        previewUseCase = new Preview.Builder()
                .setTargetAspectRatio(AspectRatio.RATIO_16_9)
                .setTargetRotation(Surface.ROTATION_0)
                .build();
        previewUseCase.setSurfaceProvider(previewView.getSurfaceProvider());
        cameraProvider.bindToLifecycle(this, cameraSelector, previewUseCase);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Visual.transparentStatusBar(getWindow());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Visual.startAnimatedBackground(findViewById(R.id.mainLayout));
        CharSequence name = "OrderNotification";
        String description = "Order Notification";
        int importance = NotificationManager.IMPORTANCE_HIGH;
        NotificationChannel channel = new NotificationChannel("1", name, importance);
        channel.setDescription(description);
        channel.setShowBadge(true);
        channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
        NotificationManager notificationManager = getSystemService(NotificationManager.class);
        notificationManager.createNotificationChannel(channel);
        findViewById(R.id.historyButton).setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, HistoryActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        isStarted = false;
        if (isAllPermissionsGranted()) startCamera();
        else requestPermissions();
    }
}
