package com.example.myapplication;


import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.ImageView;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.example.myapplication.API.API;
import com.example.myapplication.struct.Item;
import com.example.myapplication.struct.PartialOrder;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


public class MenuActivity extends AppCompatActivity {
    public boolean lastActionState = false;

    private int totalPrice(ArrayList<Item> items) {
        int sum = 0;
        for (Item i : items)
            sum += i.price * i.quantity;
        return sum;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Visual.transparentStatusBar(getWindow());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        String tableId = getIntent().getStringExtra("tableId");
        if (tableId == null) {
            Intent intent = new Intent(MenuActivity.this, MainActivity.class);
            startActivity(intent);
        } else {
            RecyclerView recyclerView = findViewById(R.id.itemRecyclerView);
            ConstraintLayout infoLayout = findViewById(R.id.infoLayout);
            ConstraintLayout actionLayout = findViewById(R.id.actionLayout);
            recyclerView.setVisibility(View.INVISIBLE);
            infoLayout.setVisibility(View.INVISIBLE);
            actionLayout.setVisibility(View.INVISIBLE);
            startAnimation();

            API.GetStoreInfo(tableId, store -> {
                // Store info
                TextView storeName = findViewById(R.id.storeName);
                TextView storeAddress = findViewById(R.id.storeAddress);
                ImageView storeImage = findViewById(R.id.imageView4);
                API.GetImage(store.id, storeImage::setImageBitmap);
                storeImage.setClipToOutline(true);
                storeName.setText(store.name);
                storeAddress.setText(String.format(getString(R.string.address), store.address));
                // Store menu
                ArrayList<Item> items = new ArrayList<>();
                store.items.forEach(item -> items.add(new Item(item)));
                ItemAdapter itemAdapter = new ItemAdapter(items);
                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
                recyclerView.setLayoutManager(linearLayoutManager);
                recyclerView.setAdapter(itemAdapter);
                // Order button
                MaterialButton button = findViewById(R.id.button);
                button.setOnClickListener(view -> {
                    button.setEnabled(false);
                    API.CreateOrder(new PartialOrder(tableId, store.tableName, items), orderId -> {
                        Intent intent = new Intent(MenuActivity.this, OrderActivity.class);
                        intent.putExtra("orderId", orderId);
                        SharedPreferences sp = getSharedPreferences("history", MODE_PRIVATE);
                        int size = sp.getInt("size", 0);
                        SharedPreferences.Editor editor = sp.edit();
                        editor.putString("id_" + size, orderId);
                        editor.putLong("time_" + size, System.currentTimeMillis());
                        editor.putInt("size", ++size);
                        editor.apply();
                        button.setEnabled(true);
                        startActivity(intent);
                    });
                });
                // Total price
                TextView totalPriceView = findViewById(R.id.totalPrice);
                String priceFormat = getString(R.string.price);
                totalPriceView.setText(String.format(priceFormat, totalPrice(items)));
                Animation fadeInUp = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade_in_up);
                Animation fadeOutDown = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade_out_down);
                fadeOutDown.setAnimationListener(Visual.onAnimationEnd(a -> actionLayout.setVisibility(View.INVISIBLE)));
                itemAdapter.setOnValueChangedListener(() -> {
                    totalPriceView.setText(String.format(priceFormat, totalPrice(items)));
                    if (items.stream().anyMatch(i -> i.quantity > 0)) {
                        if (!lastActionState) {
                            lastActionState = true;
                            button.setEnabled(true);
                            actionLayout.startAnimation(fadeInUp);
                            actionLayout.setVisibility(View.VISIBLE);
                        }
                    } else if (lastActionState) {
                        lastActionState = false;
                        button.setEnabled(false);
                        actionLayout.startAnimation(fadeOutDown);
                    }
                });
                // Finish loading
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    LayoutAnimationController layoutAnimation = AnimationUtils.loadLayoutAnimation(getApplicationContext(), R.anim.layout_animation);
                    new Handler(Looper.getMainLooper()).postDelayed(() -> {
                        recyclerView.setVisibility(View.VISIBLE);
                        recyclerView.setLayoutAnimation(layoutAnimation);
                        LottieAnimationView loadingView = findViewById(R.id.loading);
                        loadingView.animate().alpha(0f).setDuration(500).setListener(new AnimatorListenerAdapter() {
                            @Override
                            public void onAnimationEnd(Animator a) {
                                super.onAnimationEnd(a);
                                loadingView.setVisibility(View.GONE);
                                infoLayout.setBackground(ContextCompat.getDrawable(MenuActivity.this, R.drawable.rounded_transparent_bg));
                                findViewById(R.id.mLayout).setBackgroundColor(Color.TRANSPARENT);
                                int grayBg = getColor(R.color.gray_bg);
                                recyclerView.setBackgroundColor(grayBg);
                                findViewById(R.id.actionBackground).setBackgroundColor(grayBg);
                            }
                        });
                    }, 500);
                    infoLayout.startAnimation(AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade_in_down));
                    infoLayout.setVisibility(View.VISIBLE);
                }, 500);
            });
        }
    }

    private void startAnimation() {
        for (View view : new View[]{
                findViewById(R.id.menuLayout),
                findViewById(R.id.buttonBackground)
        }) {
            Visual.startAnimatedBackground(view);
        }
    }
}
