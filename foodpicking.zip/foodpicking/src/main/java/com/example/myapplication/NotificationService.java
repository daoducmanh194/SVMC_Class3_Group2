package com.example.myapplication;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

import com.example.myapplication.API.API;
import com.example.myapplication.API.ApiOrderUpdate;
import com.example.myapplication.API.Status;
import com.example.myapplication.struct.Item;
import com.google.gson.Gson;

import java.net.URISyntaxException;
import java.util.ArrayList;

import io.socket.client.IO;
import io.socket.client.Socket;

public class NotificationService extends Service {
    public final
    static String START = "Start";
    static String STOP = "Stop";
    static String ORDER_ID = "orderId";
    ArrayList<String> idList = new ArrayList<>();
    ArrayList<String> itemList = new ArrayList<>();
    PendingIntent notifyPendingIntent;
    Intent notifyIntent;

    private
    Thread thread;
    Socket socket;

    public NotificationService() {
        try {
            socket = IO.socket(API.BASE_URL);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent.getAction();
        if (action.equals(START)) {
            String orderId = intent.getStringExtra(ORDER_ID);
            if (orderId == null) return START_REDELIVER_INTENT;
            socket.connect();
            if (idList.contains(orderId)) return START_REDELIVER_INTENT;
            idList.add(orderId);
            socket.emit("order", orderId);
            thread = new Thread(() -> socket.on("updateOrder", args -> {
                ApiOrderUpdate order = new Gson().fromJson(args[0].toString(), ApiOrderUpdate.class);
                Status status = Status.values()[order.status];
                String statusString;
                switch (status) {
                    case Pending:
                        statusString = "đang được chuẩn bị";
                        break;
                    case Ready:
                        statusString = "đã sẵn sàng";
                        break;
                    case Denied:
                        statusString = "đã bị từ chối";
                        break;
                    default:
                        statusString = "gặp lỗi";
                        break;
                }
                String text = order.itemName + " " + statusString + ".";
                API.GetImage(order.itemId, image -> {
                    // Update item view
                    if (OrderActivity.isShowing && orderId.equals(OrderActivity.orderId)) {
                        for (Item i : OrderActivity.items) {
                            if (i.id.equals(order.itemId)) {
                                i.status = status;
                                OrderActivity.orderItemAdapter.notifyItemChanged(OrderActivity.items.indexOf(i));
                            }
                        }
                    }
                    // Notification
                    notifyIntent = new Intent(NotificationService.this, OrderActivity.class);
                    notifyIntent.putExtra("orderId", orderId);
                    notifyIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                    notifyPendingIntent = PendingIntent.getActivity(
                            this, 0, notifyIntent,
                            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
                    );
                    String itemId = orderId + "-" + order.itemId;
                    if (!itemList.contains(itemId)) itemList.add(itemId);
                    NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "1")
                            .setSmallIcon(R.drawable.ic_launcher_foreground)
                            .setLargeIcon(image)
                            .setContentTitle(getString(R.string.app_name))
                            .setContentText(text)
                            .setDefaults(Notification.DEFAULT_ALL)
                            .setPriority(NotificationCompat.PRIORITY_MAX)
                            .setContentIntent(notifyPendingIntent)
                            .setAutoCancel(true);
                    getSystemService(NotificationManager.class).notify(itemList.indexOf(itemId), builder.build());
                });
            }));
            thread.start();
        }
        if (action.equals(STOP)) {
            socket.close();
        }
        return START_REDELIVER_INTENT;
    }
}
