package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.airbnb.lottie.LottieAnimationView;
import com.example.myapplication.API.API;
import com.example.myapplication.struct.Item;
import com.example.myapplication.struct.Order;
import com.google.android.material.button.MaterialButton;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class OrderActivity extends AppCompatActivity {
    public static boolean isShowing = false;
    public static String orderId;
    public static ArrayList<Item> items;
    public static OrderItemAdapter orderItemAdapter;

    private int totalPrice() {
        int sum = 0;
        for (Item i : items)
            sum += i.price * i.quantity;
        return sum;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Visual.transparentStatusBar(getWindow());
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        orderId = getIntent().getStringExtra("orderId");
        if (orderId == null) {
            Intent intent = new Intent(OrderActivity.this, MainActivity.class);
            startActivity(intent);
        } else {
            ConstraintLayout innerLayout = findViewById(R.id.innerOrderLayout);
            innerLayout.setVisibility(View.INVISIBLE);
            Intent startServer = new Intent(this, NotificationService.class);
            startServer.setAction(NotificationService.START);
            startServer.putExtra(NotificationService.ORDER_ID, orderId);
            startService(startServer);
            findViewById(R.id.historyButton).setOnClickListener(view -> {
                Intent intent = new Intent(OrderActivity.this, HistoryActivity.class);
                startActivity(intent);
            });
            API.GetOrderInfo(orderId, apiOrder -> {
                Order order = new Order(apiOrder);
                items = order.items;
                // Total price
                TextView totalPriceView = findViewById(R.id.textView2);
                String priceFormat = getString(R.string.price);
                totalPriceView.setText(String.format(priceFormat, totalPrice()));
                // Table info
                TextView tableInfo = findViewById(R.id.textView3);
                DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("hh:mm:ss dd/MM/yyyy");
                String tableInfoFormat = getString(R.string.table_info);
                tableInfo.setText(String.format(tableInfoFormat, order.tableName, dateFormat.format(order.createdTime)));
                // Order list
                orderItemAdapter = new OrderItemAdapter(items);
                RecyclerView recyclerView = findViewById(R.id.orderList);
                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
                recyclerView.setLayoutManager(linearLayoutManager);
                recyclerView.setAdapter(orderItemAdapter);
                // Button
                MaterialButton button = findViewById(R.id.button);
                button.setOnClickListener(view -> {
                    Intent intent = new Intent(OrderActivity.this, MenuActivity.class);
                    intent.putExtra("tableId", order.tableId);
                    startActivity(intent);
                });
                // Finish loading
                new Handler(Looper.getMainLooper()).postDelayed(() -> {
                    Animation fadeIn = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fade_in_down_long);
                    fadeIn.setAnimationListener(Visual.onAnimationEnd(a -> {
                        LottieAnimationView animationView = findViewById(R.id.checkView);
                        animationView.playAnimation();
                        findViewById(R.id.loading).setVisibility(View.INVISIBLE);
                    }));
                    innerLayout.startAnimation(fadeIn);
                    innerLayout.setVisibility(View.VISIBLE);
                }, 1000);
            });
        }

    }

    @Override
    protected void onResume() {
        super.onResume();
        startAnimation();
        isShowing = true;
    }

    @Override
    protected void onPause() {
        super.onPause();
        isShowing = false;
    }

    private void startAnimation() {
        for (View view : new View[]{
                findViewById(R.id.orderLayout),
                findViewById(R.id.actionLayout)
        }) {
            Visual.startAnimatedBackground(view);
        }
    }
}
