package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.API.API;
import com.example.myapplication.struct.Item;

import java.util.ArrayList;

class OrderItemAdapter extends RecyclerView.Adapter<OrderItemAdapter.OrderItemHolder> {
    private final ArrayList<Item> items;

    public OrderItemAdapter(ArrayList<Item> arraylist) {
        this.items = arraylist;
    }

    @NonNull
    @Override
    public OrderItemAdapter.OrderItemHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.order_item, parent, false);
        return new OrderItemAdapter.OrderItemHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderItemAdapter.OrderItemHolder holder, int position) {
        Item item = items.get(position);
        Context context = holder.priceView.getContext();
        holder.nameView.setText(item.name);
        holder.priceView.setText(String.format(context.getString(R.string.price), item.price));
        holder.quantityView.setText(String.format(context.getString(R.string.quantity), item.quantity));
        String status;
        switch (item.status) {
            case Pending:
                status = "Đang chuẩn bị...";
                break;
            case Ready:
                status = "Sẵn sàng";
                break;
            case Denied:
                status = "Đã bị từ chối";
                break;
            default:
                status = "Lỗi";
                break;
        }
        holder.statusView.setText(status);
        holder.imageView.setClipToOutline(true);
        API.GetImage(item.id, holder.imageView::setImageBitmap);
    }


    @Override
    public int getItemCount() {
        return items == null ? 0 : items.size();
    }

    class OrderItemHolder extends RecyclerView.ViewHolder {
        private final
        TextView nameView;
        TextView priceView;
        TextView quantityView;
        TextView statusView;
        ImageView imageView;

        public OrderItemHolder(@NonNull View convertView) {
            super(convertView);
            nameView = convertView.findViewById((R.id.itemName));
            priceView = convertView.findViewById((R.id.itemPrice));
            imageView = convertView.findViewById(R.id.itemImage);
            statusView = convertView.findViewById(R.id.itemStatus);
            quantityView = convertView.findViewById(R.id.itemQuantity);
        }
    }
}
