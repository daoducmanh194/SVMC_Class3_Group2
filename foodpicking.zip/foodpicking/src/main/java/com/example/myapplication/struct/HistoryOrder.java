package com.example.myapplication.struct;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class HistoryOrder {
   public
   String id;
   long createdTime;

   public HistoryOrder(String id, long time) {
      this.id = id;
      if (id.length() > 10) this.id = id.substring(0, 9);
      createdTime = time;
   }

   public String getFormattedTime() {
      Timestamp timestamp = (new Timestamp(createdTime));
      LocalDateTime date = timestamp.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
      DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("hh:mm dd/MM/yyyy");
      return dateFormat.format(date);
   }
}
