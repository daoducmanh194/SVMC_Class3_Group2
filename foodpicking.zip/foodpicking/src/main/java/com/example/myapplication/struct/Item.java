package com.example.myapplication.struct;

import com.example.myapplication.API.ApiItem;
import com.example.myapplication.API.Status;

public class Item {
    public final String id;
    public final String name;
    public final String description;
    public final boolean available;
    public final int price;
    public int quantity;
    public Status status;

    public Item(ApiItem item) {
        this.id = item.id;
        this.name = item.name;
        this.description = item.description;
        this.quantity = item.quantity;
        this.status = Status.values()[item.status];
        this.available = item.available;
        this.price = item.price;
    }
}
