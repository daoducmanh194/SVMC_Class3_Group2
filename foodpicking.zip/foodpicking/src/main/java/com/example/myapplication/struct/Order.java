package com.example.myapplication.struct;

import com.example.myapplication.API.ApiOrder;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;

public class Order {
    public final String id;
    public final String tableId;
    public final String tableName;
    public final ArrayList<Item> items = new ArrayList<>();
    public final LocalDateTime createdTime;

    public Order(ApiOrder order) {
        id = order.id;
        tableId = order.tableId;
        tableName = order.tableName;
        Timestamp timestamp = (new Timestamp(order.createdTime));
        createdTime = timestamp.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        order.items.forEach(i -> items.add(new Item(i)));
    }
}