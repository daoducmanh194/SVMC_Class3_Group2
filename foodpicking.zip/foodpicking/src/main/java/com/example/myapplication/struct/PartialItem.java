package com.example.myapplication.struct;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PartialItem {
    @SerializedName("id")
    @Expose
    public String id;
    @SerializedName("quantity")
    @Expose
    public int quantity;

    public PartialItem(String id, int quantity) {
        this.id = id;
        this.quantity = quantity;
    }
}
