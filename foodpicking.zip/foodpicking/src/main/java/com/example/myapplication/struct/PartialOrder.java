package com.example.myapplication.struct;

import java.util.ArrayList;

public class PartialOrder {
    public final String tableId;
    public final String tableName;
    public final ArrayList<Item> items;

    public PartialOrder(String tId, String tName, ArrayList<Item> i) {
        tableId = tId;
        tableName = tName;
        items = i;
    }
}
