package com.example.miniproject.API;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.util.Base64;
import android.util.Log;

import androidx.annotation.NonNull;

import com.example.miniproject.ui.ConvertImage;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.function.Consumer;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;
import okhttp3.ResponseBody;

public class API {
    private
    static String token = "";
    static final OkHttpClient client = new OkHttpClient();
    static final MediaType JSON = MediaType.get("application/json; charset=utf-8");
    static final Handler mHandler = new Handler(Looper.getMainLooper());
    public static final String BASE_URL = "http://107.113.195.88/";

    private static void setToken(String newToken) {
        token = (newToken != null) ? newToken : token;
    }

    private static void makeGetRequest(String endpoint, Consumer<String> consumer) {
        Log.d("GET", "/" + endpoint);
        Request request = new Request.Builder()
                .url(BASE_URL + endpoint)
                .addHeader("Authorization", token)
                .get()
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) {
                try {
                    setToken(response.headers().get("token"));
                    ResponseBody res = response.body();
                    if (res == null) {
                        Log.e("API/" + endpoint, " Response body is null");
                        return;
                    }
                    String data = res.string();
                    res.close();
                    mHandler.post(() -> consumer.accept(data));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private static void makeDeleteRequest(String endpoint, Consumer<String> consumer) {
        Log.d("DELETE", "/" + endpoint);
        Request request = new Request.Builder()
                .url(BASE_URL + endpoint)
                .addHeader("Authorization", token)
                .delete()
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) {
                try {
                    setToken(response.headers().get("token"));
                    ResponseBody res = response.body();
                    if (res == null) {
                        Log.e("API/" + endpoint, " Response body is null");
                        return;
                    }
                    String data = res.string();
                    res.close();
                    mHandler.post(() -> consumer.accept(data));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private static void makePostRequest(String endpoint, JSONObject json, Consumer<String> consumer, Consumer<String> error) {
        Log.d("POST/" + endpoint, json.toString());
        RequestBody body = RequestBody.create(json.toString(), JSON);
        Request request = new Request.Builder()
                .url(BASE_URL + endpoint)
                .addHeader("Authorization", token)
                .post(body)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                error.accept(e.toString());
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) {
                try {
                    setToken(response.headers().get("token"));
                    ResponseBody res = response.body();
                    if (res == null) {
                        Log.e("API/" + endpoint, " Response body is null");
                        return;
                    }
                    String data = res.string();
                    res.close();
                    mHandler.post(() -> consumer.accept(data));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private static void makePutRequest(String endpoint, JSONObject json, Consumer<String> consumer) {
        Log.d("PUT/" + endpoint, json.toString());
        RequestBody body = RequestBody.create(json.toString(), JSON);
        Request request = new Request.Builder()
                .url(BASE_URL + endpoint)
                .addHeader("Authorization", token)
                .put(body)
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) {
                try {
                    setToken(response.headers().get("token"));
                    Log.d("NewToken", response.headers().get("token"));
                    ResponseBody res = response.body();
                    if (res == null) {
                        Log.e("API/" + endpoint, " Response body is null");
                        return;
                    }
                    String data = res.string();
                    res.close();
                    mHandler.post(() -> consumer.accept(data));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public static void login(String username, String password, Runnable success, Consumer<String> onError) {
        JSONObject body = new JSONObject();
        try {
            body.put("username", username);
            body.put("password", password);
            makePostRequest("login", body, response -> {
                try {
                    JSONObject json = new JSONObject(response);
                    if (json.has("token")) {
                        token = json.get("token").toString();
                        success.run();
                    } else {
                        onError.accept(json.get("error").toString());
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }, onError);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static void register(String username, String password, Runnable success, Consumer<String> onError) {
        JSONObject body = new JSONObject();
        try {
            body.put("username", username);
            body.put("password", password);
            makePostRequest("register", body, response -> {
                try {
                    JSONObject json = new JSONObject(response);
                    if (json.has("token")) {
                        token = json.get("token").toString();
                        success.run();
                    } else {
                        onError.accept(json.get("error").toString());
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }, onError);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static void getStoreInfo(Consumer<ApiStore> consumer) {
        makeGetRequest("info", response -> {
            Log.d("StoreInfo", response);
            ApiStore store = new Gson().fromJson(response, ApiStore.class);
            consumer.accept(store);
        });
    }

    public static void editStoreInfo(ApiStore store, Consumer<ApiStore> consumer) {
        JSONObject body = new JSONObject();
        try {
            body.put("name", store.name);
            body.put("address", store.address);
            body.put("items", new JSONArray(new Gson().toJson(store.items)));
            body.put("tables", new JSONArray(new Gson().toJson(store.tables)));
            makePutRequest("info", body, response -> {
                ApiStore apiStore = new Gson().fromJson(response, ApiStore.class);
                consumer.accept(apiStore);
            });
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static void createStoreInfo(String name, Consumer<ApiStore> consumer, Consumer<String> onError) {
        JSONObject body = new JSONObject();
        try {
            body.put("name", name);
            makePostRequest("info", body, response -> {
                ApiStore apiStore = new Gson().fromJson(response, ApiStore.class);
                consumer.accept(apiStore);
            }, onError);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static void getOrderList(Consumer<ArrayList<ApiOrder>> consumer) {
        makeGetRequest("orderList", response -> {
            ApiOrderList apiOrderList = new Gson().fromJson(response, ApiOrderList.class);
            consumer.accept(apiOrderList.orders);
        });
    }

    public static void GetImage(String itemId, Consumer<Bitmap> consumer) {
        makeGetRequest("image/" + itemId, response -> {
            try {
                JSONObject json = new JSONObject(response);
                if (json.has("image")) {
                    String i = json.get("image").toString();
                    byte[] decodedString = Base64.decode(i, Base64.DEFAULT);
                    Bitmap image = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);
                    mHandler.post(() -> consumer.accept(image));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        });
    }

    public static void PostImage(String itemId, Bitmap bitmap, Runnable runnable) {
        JSONObject body = new JSONObject();
        try {
            body.put("itemId", itemId);
            body.put("image", ConvertImage.imageToBase64(bitmap));
            makePostRequest("image", body, response -> runnable.run(), e -> Log.d("PostImageFailed", e));
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static void editOrderStatus(String orderId, String itemId, int status, Runnable runnable) {
        JSONObject body = new JSONObject();
        try {
            body.put("orderId", orderId);
            body.put("itemId", itemId);
            body.put("status", status);
            makePutRequest("order", body, response -> runnable.run());
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public static void deleteOrder(String orderId, Runnable runnable) {
        makeDeleteRequest("order/" + orderId, response -> runnable.run());
    }
}
