package com.example.miniproject.API;

import com.example.miniproject.Item;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ApiItem {
    @SerializedName("name")
    @Expose
    public String name;
    @SerializedName("description")
    @Expose
    public String description;
    @SerializedName("available")
    @Expose
    public boolean available;
    @SerializedName("price")
    @Expose
    public int price;
    @SerializedName("id")
    @Expose
    public String id;
    @SerializedName("quantity")
    @Expose
    public int quantity;
    @SerializedName("status")
    @Expose
    public int status;

    public ApiItem(Item item) {
        id = item.getId();
        name = item.getName();
        description = item.getDescription();
        available = item.isAvailable();
        price = item.getPrice();
    }

    public ApiItem(String name, String description, int price, boolean available) {
        this.name = name;
        this.description = description;
        this.price = price;
        this.available = available;
    }
}
