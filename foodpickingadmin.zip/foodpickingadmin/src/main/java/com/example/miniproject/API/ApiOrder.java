package com.example.miniproject.API;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

public class ApiOrder {
    @SerializedName("id")
    @Expose
    public String id;
    @SerializedName("tableId")
    @Expose
    public String tableId;
    @SerializedName("createdTime")
    @Expose
    public long createdTime;
    @SerializedName("items")
    @Expose
    public ArrayList<ApiItem> items = null;
    @SerializedName("tableName")
    @Expose
    public String tableName;

    public String getFormattedTime() {
        Timestamp timestamp = new Timestamp(createdTime);
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("hh:mm dd/MM");
        LocalDateTime localDateTime = timestamp.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
        return dateFormat.format(localDateTime);
    }
}
