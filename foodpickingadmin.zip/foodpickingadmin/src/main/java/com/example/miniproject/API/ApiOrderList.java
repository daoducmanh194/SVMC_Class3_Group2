package com.example.miniproject.API;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

class ApiOrderList {
    @SerializedName("orders")
    @Expose
    public ArrayList<ApiOrder> orders = null;
}
