package com.example.miniproject.API;

import android.graphics.Bitmap;

import com.example.miniproject.Table;
import com.example.miniproject.Util;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class ApiTable {
    @SerializedName("name")
    @Expose
    public String name;
    @SerializedName("id")
    @Expose
    public String id;

    public ApiTable(Table table) {
        id = table.getId();
        name = table.getName();
    }

    public Bitmap getQRImage() {
        return Util.createQrCode(id);
    }
}

