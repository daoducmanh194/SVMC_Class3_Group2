package com.example.miniproject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miniproject.API.API;
import com.example.miniproject.API.ApiItem;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ViewHolder> {
    public static List<ApiItem> itemList;

    public ItemAdapter(List<ApiItem> itemList) {
        ItemAdapter.itemList = itemList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View itemView = inflater.inflate(R.layout.item_item_rcv, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ApiItem item = itemList.get(position);
        EditText itemName = holder.itemNameTxt;
        itemName.setText(item.name);
        EditText price = holder.priceTxt;
        price.setText(String.valueOf(item.price));
        SwitchMaterial available = holder.availableSw;
        available.setChecked(item.available);
        ImageButton itemImg = holder.itemImg;
        itemImg.setBackgroundResource(R.drawable.ic_baseline_format_list_bulleted_24);
        if (item.id != null && item.id.length() > 0)
            API.GetImage(item.id, itemImg::setImageBitmap);
        itemImg.setOnClickListener(view -> {
            Intent i = new Intent();
            i.setType("image/*");
            i.setAction(Intent.ACTION_GET_CONTENT);
            Context context = itemImg.getContext();
            ((Activity) context).startActivityForResult(Intent.createChooser(i, "Select Picture"), position);
        });
        Button delBtn = holder.delBtn;
        delBtn.setOnClickListener(view -> {
            itemList.remove(position);
            notifyItemRemoved(position);
        });
        itemName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                item.name = editable.toString();
            }
        });
        price.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void afterTextChanged(Editable editable) {
                String s = editable.toString();
                if (s.length() == 0) {
                    item.price = 0;
                } else if (s.length() <= 9) {
                    item.price = Integer.parseInt(s);
                } else {
                    price.setText("999999999");
                }
            }
        });
        available.setOnCheckedChangeListener((compoundButton, b) -> item.available = b);
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }


    public static class ViewHolder extends RecyclerView.ViewHolder {
        public EditText itemNameTxt;
        public EditText priceTxt;
        public SwitchMaterial availableSw;
        public Button delBtn;
        public ImageButton itemImg;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemNameTxt = itemView.findViewById(R.id.itemNameTxt);
            priceTxt = itemView.findViewById(R.id.priceTxt);
            availableSw = itemView.findViewById(R.id.availableSw);
            delBtn = itemView.findViewById(R.id.delItemBtn);
            itemImg = itemView.findViewById(R.id.itemImg);
        }
    }
}
