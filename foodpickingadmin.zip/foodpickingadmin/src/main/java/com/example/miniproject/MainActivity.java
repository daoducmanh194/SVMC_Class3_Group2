package com.example.miniproject;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Toast;

import com.example.miniproject.API.API;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Objects;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextInputEditText username = findViewById(R.id.username);
        TextInputEditText password = findViewById(R.id.password);
        SharedPreferences sp = getSharedPreferences("login", MODE_PRIVATE);
        username.setText(sp.getString("username", ""));
        password.setText(sp.getString("password", ""));

        MaterialButton logBtn = findViewById(R.id.logBtn);
        MaterialButton regBtn = findViewById(R.id.regBtn);
        logBtn.setOnClickListener(view -> {
            String user = Objects.requireNonNull(username.getText()).toString();
            String pass = Objects.requireNonNull(password.getText()).toString();
            if (user.length() == 0 || pass.length() == 0) {
                showToast(getString(R.string.missing_login_fields));
                return;
            }
            logBtn.setEnabled(false);
            regBtn.setEnabled(false);
            API.login(user, pass, () -> {
                SharedPreferences.Editor editor = sp.edit();
                editor.putString("username", username.getText().toString());
                editor.putString("password", password.getText().toString());
                editor.apply();
                Intent intent = new Intent(MainActivity.this, InfoActivity.class);
                startActivity(intent);
                runOnUiThread(() -> {
                    logBtn.setEnabled(true);
                    regBtn.setEnabled(true);
                });
            }, error -> runOnUiThread(() -> {
                logBtn.setEnabled(true);
                regBtn.setEnabled(true);
                Toast.makeText(this, "Không thể đăng nhập: " + error, Toast.LENGTH_SHORT).show();
            }));
        });
        regBtn.setOnClickListener(view -> {
            String user = Objects.requireNonNull(username.getText()).toString();
            String pass = Objects.requireNonNull(password.getText()).toString();
            if (user.length() == 0 || pass.length() == 0) {
                showToast(getString(R.string.missing_login_fields));
                return;
            }
            logBtn.setEnabled(false);
            regBtn.setEnabled(false);
            API.register(user, pass,
                    () -> API.createStoreInfo("New Store", apiStore -> {
                        SharedPreferences.Editor editor = sp.edit();
                        editor.putString("username", username.getText().toString());
                        editor.putString("password", password.getText().toString());
                        editor.apply();
                        Intent intent = new Intent(MainActivity.this, InfoActivity.class);
                        startActivity(intent);
                        runOnUiThread(() -> {
                            logBtn.setEnabled(true);
                            regBtn.setEnabled(true);
                        });
                    }, error -> runOnUiThread(() -> {
                        showToast("Không thể tạo cửa hàng: " + error);
                        logBtn.setEnabled(true);
                        regBtn.setEnabled(true);
                    })),
                    error -> runOnUiThread(() -> {
                        showToast("Không thể đăng ký: " + error);
                        logBtn.setEnabled(true);
                        regBtn.setEnabled(true);
                    })
            );
        });
    }
}
