package com.example.miniproject;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miniproject.API.API;
import com.example.miniproject.API.ApiItem;
import com.example.miniproject.API.ApiOrder;

import java.util.ArrayList;
import java.util.Collections;

public class OrderTableAdapter extends RecyclerView.Adapter<OrderTableAdapter.ViewHolder> {
    public static ArrayList<ApiOrder> orderList;

    public OrderTableAdapter(ArrayList<ApiOrder> _orderList) {
        orderList = _orderList;
        orderList.sort((o1, o2) -> (int) (o2.createdTime - o1.createdTime));
    }

    @NonNull
    @Override
    public OrderTableAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View itemView = inflater.inflate(R.layout.order_table, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderTableAdapter.ViewHolder holder, int position) {
        ApiOrder order = orderList.get(position);
        TextView tableName = holder.tableName;
        tableName.setText(order.tableName);
        Context ctx = tableName.getContext();
        holder.time.setText(order.getFormattedTime());
        int sum = 0;
        for (ApiItem item : order.items) {
            sum += item.price * item.quantity;
        }
        holder.total.setText(String.format(ctx.getString(R.string.price), sum));
        holder.id.setText(String.format(ctx.getString(R.string.id), order.id));
        RecyclerView rcv = holder.rcv;
        OrderedItemAdapter orderedItemAdapter = new OrderedItemAdapter(order.id, order.items);
        rcv.setAdapter(orderedItemAdapter);
        rcv.setLayoutManager(new LinearLayoutManager(rcv.getContext()));
        ConstraintLayout constraintLayout = holder.titleCsl;
        constraintLayout.setOnClickListener(view -> rcv.setVisibility(rcv.isShown() ? View.GONE : View.VISIBLE));
        holder.deleteBtn.setOnClickListener(view -> {
            API.deleteOrder(order.id, () -> {
                int i = orderList.indexOf(order);
                orderList.remove(order);
                notifyItemRemoved(i);
            });
        });
    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tableName;
        TextView time;
        TextView total;
        TextView id;
        RecyclerView rcv;
        ConstraintLayout titleCsl;
        ImageButton deleteBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            tableName = itemView.findViewById(R.id.Table);
            time = itemView.findViewById(R.id.Time);
            id = itemView.findViewById(R.id.id);
            total = itemView.findViewById(R.id.Total);
            rcv = itemView.findViewById(R.id.orderedItemsRcv);
            titleCsl = itemView.findViewById(R.id.info_order);
            deleteBtn = itemView.findViewById(R.id.deleteBtn);
        }
    }
}
