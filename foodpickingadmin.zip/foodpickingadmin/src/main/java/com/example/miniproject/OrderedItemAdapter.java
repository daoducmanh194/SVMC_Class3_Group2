package com.example.miniproject;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miniproject.API.API;
import com.example.miniproject.API.ApiItem;
import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;

public class OrderedItemAdapter extends RecyclerView.Adapter<OrderedItemAdapter.ViewHolder> {
    private final
    ArrayList<ApiItem> items;
    String orderId;

    public OrderedItemAdapter(String orderId, ArrayList<ApiItem> i) {
        this.orderId = orderId;
        items = i;
    }

    @NonNull
    @Override
    public OrderedItemAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View itemView = inflater.inflate(R.layout.ordered_item, parent, false);
        return new ViewHolder(itemView);
    }

    private View.OnClickListener onStatusClick(Context ctx, TextView view, ApiItem item, int status) {
        return v -> API.editOrderStatus(orderId, item.id, status, () -> {
            item.status = status;
            Util.setStatusText(ctx, view, status);
        });
    }

    @Override
    public void onBindViewHolder(@NonNull OrderedItemAdapter.ViewHolder holder, int position) {
        ApiItem item = items.get(position);
        Context ctx = holder.itemName.getContext();
        TextView itemName = holder.itemName;
        itemName.setText(item.name);
        TextView number = holder.number;
        number.setText(String.format(ctx.getString(R.string.quantity), item.quantity));
        TextView stt = holder.status;
        Util.setStatusText(ctx, stt, item.status);
        holder.prepareBtn.setOnClickListener(onStatusClick(ctx, stt, item, 0));
        holder.readyBtn.setOnClickListener(onStatusClick(ctx, stt, item, 1));
        holder.deniedBtn.setOnClickListener(onStatusClick(ctx, stt, item, 2));
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView itemName;
        TextView number;
        TextView status;
        MaterialButton prepareBtn;
        MaterialButton readyBtn;
        MaterialButton deniedBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            itemName = itemView.findViewById(R.id.itemName2);
            number = itemView.findViewById(R.id.number);
            status = itemView.findViewById(R.id.status);
            prepareBtn = itemView.findViewById(R.id.prepareButton);
            readyBtn = itemView.findViewById(R.id.readyButton);
            deniedBtn = itemView.findViewById(R.id.deniedButton);
        }
    }
}
