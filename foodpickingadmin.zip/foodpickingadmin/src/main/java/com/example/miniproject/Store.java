package com.example.miniproject;

import java.util.ArrayList;

public class Store {
    String id;
    String name;
    String address;
    ArrayList<Item> items;
    ArrayList<Table> tables;

    public Store() {
    }

    public Store(String name, String address) {
        this.name = name;
        this.address = address;
    }

    public Store(String name, String address, ArrayList<Item> items, ArrayList<Table> table) {
        this.name = name;
        this.address = address;
        this.items = items;
        this.tables = table;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public ArrayList<Item> getItems() {
        return items;
    }

    public void setItems(ArrayList<Item> items) {
        this.items = items;
    }

    public ArrayList<Table> getTable() {
        return tables;
    }

    public void setTable(ArrayList<Table> table) {
        this.tables = table;
    }
}
