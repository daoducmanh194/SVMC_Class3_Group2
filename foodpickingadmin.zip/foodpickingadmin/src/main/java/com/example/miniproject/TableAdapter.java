package com.example.miniproject;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miniproject.API.ApiTable;

import java.util.List;

public class TableAdapter extends RecyclerView.Adapter<TableAdapter.ViewHolder> {
    public static List<ApiTable> tableList;

    public TableAdapter(List<ApiTable> tables) {
        tableList = tables;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);
        View itemView = inflater.inflate(R.layout.table_item_rcv, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        ApiTable table = tableList.get(position);
        EditText nameEdt = holder.nameEdt;
        nameEdt.setText(table.name);
        Button delBtn = holder.delBtn;
        delBtn.setOnClickListener(view -> {
            tableList.remove(position);
            notifyItemRemoved(position);
        });
        ImageButton qrImg = holder.qrImg;
        try {
            if (table.id != null && table.id.length() > 0) {
                qrImg.setImageBitmap(table.getQRImage());
                qrImg.setOnClickListener(view -> {
                    Intent intent = new Intent(qrImg.getContext(), ViewQrActivity.class);
                    intent.putExtra(ViewQrActivity.TABLE_NAME, table.name);
                    intent.putExtra(ViewQrActivity.TABLE_ID, table.id);
                    qrImg.getContext().startActivity(intent);
                });
            }
        } catch (Exception e) {
            Log.e("ERROR!", e.getMessage());
        }
        nameEdt.setOnFocusChangeListener((view, b) -> {
            if (!b) {
                table.name = nameEdt.getText().toString();
                nameEdt.clearFocus();
            }
        });
        nameEdt.setOnKeyListener((view, i, keyEvent) -> {
            if ((keyEvent.getAction() == KeyEvent.ACTION_DOWN) &&
                    (i == KeyEvent.KEYCODE_ENTER)) {
                table.name = nameEdt.getText().toString();
                nameEdt.clearFocus();
                return true;
            }
            return false;
        });
    }

    @Override
    public int getItemCount() {
        return tableList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public EditText nameEdt;
        public ImageButton qrImg;
        public Button delBtn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            nameEdt = itemView.findViewById(R.id.tableNameEdt);
            delBtn = itemView.findViewById(R.id.delTableBtn);
            qrImg = itemView.findViewById(R.id.qrImg);
        }
    }
}
