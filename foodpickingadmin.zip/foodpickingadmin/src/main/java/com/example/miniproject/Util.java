package com.example.miniproject;

import android.content.Context;
import android.graphics.Bitmap;
import android.os.Environment;
import android.widget.TextView;

import net.glxn.qrgen.android.QRCode;

import java.io.File;
import java.io.FileOutputStream;

public class Util {
    public static Bitmap createQrCode(String str) {
        return QRCode.from(str).withSize(512, 512).bitmap();
    }

    public static void saveBitmap(Bitmap bm, String name) {
        try {
            File file, f;
            file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "QR");
            if (!file.exists() && !file.mkdir()) return;
            f = new File(file.getAbsolutePath() + "/" + name + ".jpg");
            FileOutputStream ostream = new FileOutputStream(f);
            bm.compress(Bitmap.CompressFormat.JPEG, 70, ostream);
            ostream.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Bitmap resizeBitmap(Bitmap image, int maxWidth, int maxHeight) {
        if (maxHeight > 0 && maxWidth > 0) {
            int width = image.getWidth();
            int height = image.getHeight();
            float ratioBitmap = (float) width / (float) height;
            float ratioMax = (float) maxWidth / (float) maxHeight;
            int finalWidth = maxWidth;
            int finalHeight = maxHeight;
            if (ratioMax > ratioBitmap) {
                finalWidth = (int) ((float) maxHeight * ratioBitmap);
            } else {
                finalHeight = (int) ((float) maxWidth / ratioBitmap);
            }
            image = Bitmap.createScaledBitmap(image, finalWidth, finalHeight, true);
        }
        return image;
    }

    public static void setStatusText(Context ctx, TextView view, int status) {
        String str = "Đang chuẩn bị";
        if (status == 1) str = "Sẵn sàng";
        if (status == 2) str = "Đã từ chối";
        view.setText(String.format(ctx.getString(R.string.status), str));
    }
}
