package com.example.miniproject;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.example.miniproject.ui.InformationFragment;
import com.google.android.material.button.MaterialButton;

public class ViewQrActivity extends AppCompatActivity {
    public static final String TABLE_ID = "tableId";
    public static final String TABLE_NAME = "tableName";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_qr);
        Intent intent = getIntent();
        String tableName = intent.getStringExtra(TABLE_NAME);
        String tableId = intent.getStringExtra(TABLE_ID);
        if (tableName == null || tableId == null) {
            finishAffinity();
            return;
        }
        ConstraintLayout qrLayout = findViewById(R.id.qrLayout);
        TextView storeNameView = findViewById(R.id.storeName);
        TextView tableNameView = findViewById(R.id.tableName);
        ImageView qrView = findViewById(R.id.qrImg);
        storeNameView.setText(InformationFragment.sName);
        tableNameView.setText(tableName);
        qrView.setImageBitmap(Util.createQrCode(tableId));

        MaterialButton btn = findViewById(R.id.button);
        btn.setOnClickListener(view -> {
            Bitmap bitmap = Bitmap.createBitmap(qrLayout.getWidth(), qrLayout.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            qrLayout.draw(canvas);
            Util.saveBitmap(bitmap, tableName + "_" + tableId);
            Toast.makeText(this, "Đã lưu mã QR vào thư mục 'Pictures/QR'", Toast.LENGTH_SHORT).show();
        });
    }
}
