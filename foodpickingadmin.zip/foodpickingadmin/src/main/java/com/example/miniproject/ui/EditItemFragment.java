package com.example.miniproject.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miniproject.API.ApiItem;
import com.example.miniproject.ItemAdapter;
import com.example.miniproject.R;
import com.example.miniproject.databinding.FragmentEditItemBinding;

import java.util.ArrayList;

public class EditItemFragment extends Fragment {
    FragmentEditItemBinding binding;
    ArrayList<ApiItem> items;
    RecyclerView rcv;
    Button addBtn;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentEditItemBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        rcv = binding.itemRcv;
        items = InformationFragment.items;
        ItemAdapter itemAdapter = new ItemAdapter(items);
        rcv.setAdapter(itemAdapter);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        rcv.setLayoutManager(layoutManager);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(getContext(), layoutManager.getOrientation());
        rcv.addItemDecoration(dividerItemDecoration);
        addBtn = getActivity().findViewById(R.id.addBtn);
        addBtn.setOnClickListener(view -> {
            items.add(new ApiItem("", "", 0, false));
            rcv.getAdapter().notifyItemInserted(items.size() - 1);
        });
        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        addBtn = getActivity().findViewById(R.id.addBtn);
        addBtn.setOnClickListener(view -> {
            items.add(new ApiItem("", "", 0, false));
            rcv.getAdapter().notifyItemInserted(items.size() - 1);
        });
    }

}
