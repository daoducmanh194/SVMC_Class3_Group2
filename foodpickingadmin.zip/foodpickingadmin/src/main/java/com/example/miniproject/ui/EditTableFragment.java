package com.example.miniproject.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miniproject.API.ApiTable;
import com.example.miniproject.R;
import com.example.miniproject.Table;
import com.example.miniproject.TableAdapter;
import com.example.miniproject.databinding.FragmentEditTableBinding;

import java.util.ArrayList;
import java.util.Objects;

public class EditTableFragment extends Fragment {
    FragmentEditTableBinding binding;
    ArrayList<ApiTable> tables;
    Button addBtn;
    RecyclerView rcv;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentEditTableBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        rcv = binding.tableRcv;
        tables = InformationFragment.tables;
        TableAdapter tableAdapter = new TableAdapter(tables);
        rcv.setAdapter(tableAdapter);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        rcv.setLayoutManager(layoutManager);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(getContext(), layoutManager.getOrientation());
        rcv.addItemDecoration(dividerItemDecoration);
        addBtn = getActivity().findViewById(R.id.addBtn);
        addBtn.setOnClickListener(view -> {
            tables.add(new ApiTable(new Table("Bàn " + tables.size())));
            Objects.requireNonNull(rcv.getAdapter()).notifyItemInserted(tables.size() - 1);
        });
        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        addBtn = getActivity().findViewById(R.id.addBtn);
        addBtn.setOnClickListener(view -> {
            tables.add(new ApiTable(new Table("Bàn " + tables.size())));
            Objects.requireNonNull(rcv.getAdapter()).notifyItemInserted(tables.size() - 1);
        });
    }
}
