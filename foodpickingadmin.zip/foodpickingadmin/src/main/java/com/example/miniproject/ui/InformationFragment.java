package com.example.miniproject.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.example.miniproject.API.API;
import com.example.miniproject.API.ApiItem;
import com.example.miniproject.API.ApiStore;
import com.example.miniproject.API.ApiTable;
import com.example.miniproject.InfoActivity;
import com.example.miniproject.ViewPageAdapter;
import com.example.miniproject.databinding.FragmentInformationBinding;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

import java.util.ArrayList;

public class InformationFragment extends Fragment {
    private final String[] tabTitles = {"Món ăn", "Bàn"};
    public static ArrayList<ApiTable> tables = new ArrayList<>();
    public static ArrayList<ApiItem> items = new ArrayList<>();
    public static String sName = "";
    public static String sId = "";

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        FragmentInformationBinding binding = FragmentInformationBinding.inflate(inflater, container, false);
        View root = binding.getRoot();
        binding.progressLoader.setVisibility(View.VISIBLE);
        API.getStoreInfo(apiStore -> {
            items = apiStore.items;
            tables = apiStore.tables;
            sName = apiStore.name;
            sId = apiStore.id;
            ViewPageAdapter viewPageAdapter = new ViewPageAdapter(getActivity());
            ViewPager2 viewPager = binding.viewPager2;
            viewPager.setAdapter(viewPageAdapter);
            TabLayout tabLayout = binding.tabLayout;
            EditText storeName = binding.nameEdt;
            EditText address = binding.addressEdt;
            Button saveBtn = binding.saveBtn;
            storeName.setText(apiStore.name);
            address.setText(apiStore.address);
            new TabLayoutMediator(tabLayout, viewPager, (tab, position) -> tab.setText(tabTitles[position])).attach();
            saveBtn.setOnClickListener(view -> {
                ApiStore store = new ApiStore();
                store.name = storeName.getText().toString();
                sName = store.name;
                store.address = address.getText().toString();
                store.items = items;
                store.tables = tables;
                API.editStoreInfo(store, newStore -> {
                    Intent refresh = new Intent(getActivity(), InfoActivity.class);
                    startActivity(refresh);
                });
            });
            binding.progressLoader.setVisibility(View.GONE);
        });
        return root;
    }
}
