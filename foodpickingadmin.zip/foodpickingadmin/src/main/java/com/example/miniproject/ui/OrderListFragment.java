package com.example.miniproject.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.miniproject.API.API;
import com.example.miniproject.API.ApiOrder;
import com.example.miniproject.OrderTableAdapter;
import com.example.miniproject.databinding.FragmentOrderListBinding;
import com.google.gson.Gson;

import java.net.URISyntaxException;
import java.util.Objects;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import io.socket.client.IO;
import io.socket.client.Socket;

public class OrderListFragment extends Fragment {
    private FragmentOrderListBinding binding;
    Socket socket;
    Thread thread;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentOrderListBinding.inflate(inflater, container, false);
        try {
            socket = IO.socket(API.BASE_URL);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
        View root = binding.getRoot();
        API.getOrderList(orderList -> {
            RecyclerView tableRcv = binding.orderTableRcv;
            OrderTableAdapter orderTableAdapter = new OrderTableAdapter(orderList);
            tableRcv.setAdapter(orderTableAdapter);
            LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
            tableRcv.setLayoutManager(layoutManager);
            socket.connect();
            socket.emit("store", InformationFragment.sId);
            thread = new Thread(() -> socket.on("newOrder", args -> {
                ApiOrder order = new Gson().fromJson(args[0].toString(), ApiOrder.class);
                requireActivity().runOnUiThread(() -> {
                    layoutManager.scrollToPositionWithOffset(0, 0);
                    orderList.add(0, order);
                    orderTableAdapter.notifyItemInserted(0);
                });
            }));
            thread.start();
        });
        return root;
    }
}
