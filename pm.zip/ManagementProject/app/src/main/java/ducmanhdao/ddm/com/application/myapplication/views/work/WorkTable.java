package ducmanhdao.ddm.com.application.myapplication.views.work;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;

import ducmanhdao.ddm.com.application.myapplication.R;
import ducmanhdao.ddm.com.application.myapplication.entity.CongViec;

public class WorkTable extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private static final String TAG = "WorkTableActivity";
    private Spinner spinnerStatus;
    private String status[] = {"Done","Processing","Cancelled"};
    Button createCV;
    EditText findWork;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_table);

        spinnerStatus = findViewById(R.id.btn_dropdown_loc_cv);
        spinnerStatus.setOnItemSelectedListener(this);

        ArrayAdapter ad = new ArrayAdapter(this, android.R.layout.simple_spinner_item, status);
        ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerStatus.setAdapter(ad);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        recyclerView.setLayoutManager(linearLayoutManager);

        WorkAdapter workAdapter = new WorkAdapter();
        recyclerView.setAdapter(workAdapter);

        ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                if (direction == ItemTouchHelper.RIGHT) {
                    int position = viewHolder.getAdapterPosition();
                    CongViec dataWork = workAdapter.getDataAt(position);
                    workAdapter.removeItem(position);
                    Snackbar.make(recyclerView, "Deleted" + dataWork.getMaCV(), Snackbar.LENGTH_LONG).setAction("Undo", view -> workAdapter.add(position, dataWork)).show();
                }
            }
        };
//        createCV = findViewById(R.id.btn_addWork);
//        createCV.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = new Intent(getBaseContext(), WorkAdd.class);
//                startActivity(intent);
//            }
//        });

        findWork = findViewById(R.id.text_input_find_name);
//        public boolean checkFindSearch(){
//
//        }

        ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
        Toast.makeText(getApplicationContext(), status[position], Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }
}
