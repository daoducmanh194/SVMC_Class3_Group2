import * as jwt from "jsonwebtoken";
import * as bcryptjs from "bcryptjs";
import { read, write } from "./index.js";
import { Request, Response, NextFunction } from "express";

const { verify, sign } = jwt.default;
const { compareSync, hashSync } = bcryptjs.default;
const JWT_SECRET = "Skick@JWT+Secret:>";

export const checkJwt = (req: Request, res: Response, next: NextFunction) => {
    const token = <string>req.headers["authorization"];
    if (!token) return res.status(401).send({ error: "Unauthorized" });
    let payload: any;

    try {
        payload = verify(token, JWT_SECRET);
        res.locals.payload = payload;
    } catch (error) {
        res.status(401).send({ error: "Token is invalid." });
        return;
    }
    const { username, storeId } = payload;
    const newToken = sign({ username, storeId }, JWT_SECRET, { expiresIn: "1d" });
    res.setHeader("token", newToken);

    next();
};

export const login = async (req: Request, res: Response) => {
    const { username, password } = req.body;
    if (!(username && password)) return res.status(400).json({ error: "Username & password is required." });

    const data = await read();
    const user = data.users[username];
    if (!user?.password) return res.status(401).json({ error: "Username not found." });

    if (!compareSync(password, user.password)) {
        return res.status(401).json({ error: "Wrong password." });
    }
    const token = sign({ username, storeId: user.storeId }, JWT_SECRET, { expiresIn: "1d" });
    res.json({ token });
};

export const register = async (req: Request, res: Response) => {
    const { username, password } = req.body;
    if (!(username && password)) return res.status(400).json({ error: "Username & password is required." });
    const data = await read();
    if (data.users[username]) return res.status(400).json({ error: "Username exists." });
    data.users[username] = {
        password: hashSync(password),
    };
    write();
    const token = sign({ username }, JWT_SECRET, { expiresIn: "1d" });
    return res.status(200).json({ token });
};
