import { createServer } from "http";
import { Low, JSONFile } from "lowdb";
import { fileURLToPath } from "node:url";
import { join, dirname } from "node:path";
import { Server, type Socket } from "socket.io";
import { readFileSync, writeFileSync, existsSync } from "fs";
import express, { type Request, type Response } from "express";
import {
    ApiCheckTable,
    ApiCreateOrder,
    ApiError,
    ApiImage,
    ApiOrder,
    ApiOrderList,
    ApiStoreAdmin,
    ApiStoreClient,
    DB,
    Id,
    Item,
    Order,
    STATUS,
    Table,
} from "./types.js";

const __dirname = dirname(fileURLToPath(import.meta.url));
const file = join(__dirname, "db.json");
const adapter = new JSONFile<DB>(file);
const db = new Low(adapter);
export const read = async (): Promise<DB> => {
    await db.read();
    db.data ||= { users: {}, stores: {}, tables: {}, orders: {} };
    return db.data;
};
let writeRunning = false;
export const write = () => {
    if (writeRunning) return;
    writeRunning = true;
    db.write().then(() => (writeRunning = false));
};
await read();
write();

import { checkJwt, login, register } from "./auth.js";

const app = express();
const port = 80;

const server = createServer(app);
const io = new Server(server);
io.on("connection", socket => {
    console.log("New connection:", socket.id);
    socket.on("order", orderId => socket.join(orderId));
});

const guidGen = () => {
    const s4 = () => {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    };
    //return id of format 'aaaaaaaa'-'aaaa'-'aaaa'-'aaaa'-'aaaaaaaaaaaa'
    return `${s4()}${s4()}-${s4()}-${s4()}-${s4()}-${s4()}${s4()}${s4()}`;
};
const getItems = (items: Record<string, Item>) =>
    Object.keys(items).map(id => {
        return { ...items[id], id, quantity: 0 };
    });

const getTables = (data: DB, tables: string[]) => tables.map(id => ({ ...data.tables[id], id }));

app.use(express.json());

app.get("/", (req: Request, res: Response) => {
    res.json({ greeting: "Hello world!" });
});

// Client

app.get("/checkTable/:id", async (req: Request, res: Response<ApiCheckTable>) => {
    const tableId = req.params.id;
    if (!tableId) return res.json({ available: false });
    const data = await read();
    const table = data.tables[tableId];
    if (!table) return res.json({ available: false });
    const id = table.store;
    const store = data.stores[id];
    if (!store) return res.json({ available: false });
    return res.json({ available: true });
});
app.get("/table/:id", async (req: Request, res: Response<ApiStoreClient | ApiError>) => {
    const tableId = req.params.id;
    if (!tableId) return res.status(401).json({ error: "Table id is required." });
    const data = await read();
    const table = data.tables[tableId];
    if (!table) return res.status(400).json({ error: "Table not found." });
    const id = table.store;
    const store = data.stores[id];
    if (!store) return res.status(400).json({ error: "Store not found." });
    return res.json({
        name: store.name,
        address: store.address,
        id,
        tableId,
        tableName: table.name,
        items: getItems(store.items),
    });
})
    .get("/order/:id", async (req: Request, res: Response<ApiOrder | ApiError>) => {
        const orderId = req.params.id;
        if (!orderId) return res.status(400).json({ error: "Order id is required." });
        const data = await read();
        const order = data.orders[orderId];
        if (!order) return res.status(404).json({ error: "Order not found." });
        return res.json({
            ...order,
            id: orderId,
            tableName: data.tables[order.tableId].name,
        });
    })
    .post("/order", async (req: Request, res: Response<ApiCreateOrder | ApiError>) => {
        for (const field of ["tableId", "tableName", "items"])
            if (!req.body[field]) return res.status(400).json({ error: `Field '${field}' is required.` });
        const { tableId, tableName, items } = req.body;
        const data = await read();
        let orderId;
        do {
            orderId = guidGen();
        } while (data.orders[orderId]);
        const createdTime = Date.now();
        const table = data.tables[tableId];
        if (!table) return res.status(404).json({ error: "Table not found." });
        const store = data.stores[table.store];
        if (!store) return res.status(404).json({ error: "Store not found." });
        for (const item of <(Item & Id & { status: STATUS; quantity: number })[]>items) {
            const i = store.items[item.id];
            if (!i) return res.status(400).json({ error: "Item id is not valid." });
            if (!i.available) return res.status(400).json({ error: "Item is not available." });
            if (item.quantity == 0) return res.status(400).json({ error: "Item quantity is not valid" });
            item.name = i.name;
            item.description = i.description;
            item.price = i.price;
            item.status = STATUS.Pending;
        }
        data.orders[orderId] = {
            storeId: table.store,
            tableId,
            items,
            createdTime,
        };
        write();
        return res.json({
            storeId: table.store,
            id: orderId,
            createdTime,
            tableId,
            tableName,
        });
    })
    .get("/image/:id", async (req: Request, res: Response<ApiImage | ApiError>) => {
        const id = req.params.id;
        const filePath = join(__dirname, "images", id);
        if (!existsSync(filePath)) return res.status(404).json({ error: "image not found." });
        res.json({ image: readFileSync(filePath, "utf8") });
    });

// Admin

app.post("/register", register)
    .post("/login", login)
    .get("/info", checkJwt, async (req: Request, res: Response<ApiStoreAdmin | ApiError>) => {
        const { storeId } = res.locals.payload;
        const data = await read();
        const store = data.stores[storeId];
        if (store.owner !== res.locals.payload.username)
            return res.status(400).json({ error: "You are not the owner of this store." });
        return res.json({
            id: storeId,
            name: store.name,
            address: store.address,
            items: getItems(store.items),
            tables: getTables(data, store.tables),
        });
    })
    .post("/info", checkJwt, async (req: Request, res: Response) => {
        const data = await read();
        const { username } = res.locals.payload;
        if (data.users[username]?.storeId) return res.status(400).json({ error: "You are created a store before." });
        if (!req.body.name) return res.status(400).json({ error: "Field 'name' is required." });
        let storeId;
        do {
            storeId = guidGen();
        } while (data.stores[storeId] || existsSync(join(__dirname, "images", storeId)));
        data.users[username].storeId = storeId;
        data.stores[storeId] = {
            name: req.body.name,
            tables: [],
            items: {},
            owner: username,
        };
        write();
        return res.json({
            name: data.stores[storeId].name,
            id: storeId,
            items: [],
            tables: [],
        });
    })
    .put("/info", checkJwt, async (req: Request, res: Response<ApiStoreAdmin | ApiError>) => {
        const { storeId } = res.locals.payload;
        const data = await read();
        const store = data.stores[storeId];
        if (!store) return res.status(404).json({ error: "Store not found." });
        const owner = res.locals.payload.username;
        if (store.owner !== owner) return res.status(401).json({ error: "You are not the owner of this store." });
        const { name, address, tables, items } = <
            { name: string; address?: string; tables: (Table & Id)[]; items: (Item & Id)[] }
        >req.body;
        if (typeof name === "string" && !name) return res.status(400).json({ error: "Missing 'name' field." });
        if (tables && !Array.isArray(tables))
            return res.status(400).json({ error: "'tables' field must be an array." });
        if (items && !Array.isArray(items)) return res.status(400).json({ error: "'items' field must be an array." });
        if (name) store.name = name;
        if (address) store.address = address;
        if (items)
            store.items = items.reduce((acc, item) => {
                if (!item.id)
                    do {
                        item.id = guidGen();
                    } while (data.stores[storeId] || existsSync(join(__dirname, "images", storeId)));
                acc[item.id] = {
                    name: item.name,
                    description: item.description,
                    available: item.available,
                    price: item.price,
                    quantity: 0,
                };
                return acc;
            }, <Record<string, Item>>{});
        if (tables) {
            const newTables = [];
            for (const table of tables) {
                if (!table.id)
                    do {
                        table.id = guidGen();
                    } while (store.items[table.id]);
                newTables.push(table.id);
                data.tables[table.id] = {
                    name: table.name,
                    store: storeId,
                };
            }
            store.tables = newTables;
        }
        write();
        return res.json({
            id: storeId,
            name: store.name,
            address: store.address,
            items: getItems(store.items),
            tables: getTables(data, store.tables),
        });
    })
    .get("/orderList", checkJwt, async (req: Request, res: Response<ApiOrderList>) => {
        const { storeId } = res.locals.payload;
        const data = await read();
        res.json({
            orders: Object.keys(data.orders)
                .filter(id => data.orders[id].storeId == storeId)
                .map(id => {
                    const order = data.orders[id];
                    return {
                        ...order,
                        id,
                        tableName: data.tables[order.tableId].name,
                    };
                }),
        });
    })
    .put("/order", checkJwt, async (req: Request, res: Response<ApiStoreAdmin | ApiError>) => {
        for (const field of ["orderId", "itemId", "status"])
            if (typeof !req.body[field] == "undefined")
                return res.status(400).json({ error: `Field '${field}' is required.` });
        const { orderId, itemId, status } = req.body;
        const data = await read();
        const order = data.orders[orderId];
        if (!order) return res.status(404).json({ error: "Order not found." });
        const item = order.items.find(i => i.id === itemId);
        if (!item) return res.status(404).json({ error: "Item not found." });
        item.status = status;
        write();
        const socketData = {
            orderId,
            itemId,
            itemName: item.name,
            status,
        };
        io.to(orderId).emit("updateOrder", socketData);
        return res.status(200).send();
    })
    .post("/image", checkJwt, async (req: Request, res: Response<ApiCheckTable | ApiError>) => {
        for (const field of ["itemId", "image"])
            if (!req.body[field]) return res.status(400).json({ error: `Field '${field}' is required.` });
        const { image, itemId } = req.body;
        const data = await read();
        const store = data.stores[res.locals.payload.storeId];
        if (!store) return res.status(404).json({ error: "Store not found." });
        const item = store.items[itemId];
        if (!item) return res.status(404).json({ error: "Item not found." });
        writeFileSync(join(__dirname, "images", itemId), image);
        return res.status(200).send({ available: true });
    });

server.listen(port, () => {
    console.log(`Server started at http://localhost:${port}`);
});
