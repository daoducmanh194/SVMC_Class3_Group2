export enum STATUS {
    Pending,
    Ready,
    Denied,
}

export type Id = { id: string };

export type User = {
    password: string;
    storeId?: string;
};

export type Table = {
    name: string;
    store: string;
};

export type Order = {
    storeId: string;
    tableId: string;
    createdTime: number;
    items: (Item & Id & { status: STATUS })[];
};

export type Item = {
    name: string;
    description: string;
    available: boolean;
    price: string;
    quantity: number;
};

export type Store = {
    name: string;
    address?: string;
    tables: string[];
    items: Record<string, Item>;
    owner: string;
};

export type DB = {
    users: Record<string, User>;
    stores: Record<string, Store>;
    tables: Record<string, Table>;
    orders: Record<string, Order>;
};

export interface ApiError {
    error: string;
}

export interface ApiStoreClient {
    id: string;
    name: string;
    address?: string;
    items: (Item & Id)[];
    tableName: string;
    tableId: string;
}

export interface ApiStoreAdmin {
    id: string;
    name: string;
    address?: string;
    items: (Item & Id)[];
    tables: (Table & Id)[];
}

export interface ApiCheckTable {
    available: boolean;
}

export interface ApiImage {
    image: string;
}

export interface ApiOrderList {
    orders: ApiOrder[];
}

export type ApiOrder = Order & Id & { tableName: string };
export type ApiCreateOrder = Omit<ApiOrder, "items">;
