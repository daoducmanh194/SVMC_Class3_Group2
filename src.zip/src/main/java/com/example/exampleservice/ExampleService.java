package com.example.exampleservice;


import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.IBinder;
import android.os.IInterface;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;

public class ExampleService extends Service {
    private static final String CHANEL_ID = "";
    private String TAG = "MyServiceTag";
    private MediaPlayer mediaPlayer;
    public   static  final String ACTION_START = "ACTION_START";
    public   static  final String ACTION_STOP = "ACTION_STOP";

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onCreate(){
        super.onCreate();
        mediaPlayer = MediaPlayer.create(getBaseContext(),R.raw.edsheeranshapeofyou);
        mediaPlayer.start();
        foregroundService("edsheeranshapeofyou","dfgf");
        Log.d(TAG,"On Create");
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId){
        Log.d(TAG,"On start Commmand");
        if(intent != null){
            String data = intent.getStringExtra("key");
            Log.d(TAG,"data" + data);
        }
        String action = intent.getAction();
        if(action != null && action == ACTION_STOP){
            mediaPlayer.stop();
            stopForeground(true);
            stopSelf();
        }else if(action != null && action == ACTION_START){
            mediaPlayer.start();
            foregroundService("edsheeranshapeofyou","afsd");
        }
        return super.onStartCommand(intent,flags,startId);
    }

    @Override
    public void onDestroy(){
        super.onDestroy();
        Log.d(TAG, "onDestroy: ");
    }
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        Log.d(TAG, "onBind: ");
        return null;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void foregroundService(String name, String artist){
        Intent intent = new Intent(getApplicationContext(),ExampleService.class);
        intent.setAction(ExampleService.ACTION_STOP);
        PendingIntent pendingIntent = PendingIntent.getForegroundService(getApplicationContext(),0,intent,0);
        createNotificationChannel(CHANEL_ID,"chanelName");
        Notification.Builder mBuilder = new Notification.Builder(this, CHANEL_ID)
                .setContentTitle(name)
                .setContentText(artist)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentIntent(pendingIntent);
        Notification mNotification = mBuilder.build();
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q){
            startForeground(221294,mNotification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        }else {
            startForeground(221294,mNotification);
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    private void createNotificationChannel(String channelId, String chanelName){
        NotificationChannel chanel = new NotificationChannel(
                channelId,
                chanelName, NotificationManager.IMPORTANCE_NONE);
        chanel.setLightColor(Color.BLUE);
        chanel.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.createNotificationChannel(chanel);
    }
}
