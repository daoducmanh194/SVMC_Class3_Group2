package ducmanhdao.ddm.com.application.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import ducmanhdao.ddm.com.application.myapplication.db.NhanVienDAO;
import ducmanhdao.ddm.com.application.myapplication.entity.NhanVien;
import ducmanhdao.ddm.com.application.myapplication.views.home.Home;
import ducmanhdao.ddm.com.application.myapplication.views.login.DangKy;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = "Login Activity";
    private EditText msgTen, msgMail, msgPass;
    private Button btnDangNhap;
    private TextView msgResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        msgTen = findViewById(R.id.name_dang_nhap);
        msgMail = findViewById(R.id.mail_dang_nhap);
        msgPass = findViewById(R.id.pass_dang_nhap);
        btnDangNhap = findViewById(R.id.button_dang_nhap);
        msgResult = findViewById(R.id.thongbao_dangnhap);

        btnDangNhap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = msgTen.getText().toString();
                String mail = msgMail.getText().toString();
                String pass = msgPass.getText().toString();

                if(name.isEmpty()) {
                    msgResult.setText("Loi thieu ten dang nhap!");
                }
                if (mail.isEmpty()) {
                    msgResult.setText("Loi thieu mail dang nhap!");
                }
                if(pass.isEmpty()) {
                    msgResult.setText("Loi thieu password dang nhap!");
                }
                if(!name.isEmpty() && !pass.isEmpty() && !mail.isEmpty()) {
                    NhanVien nhanVien = NhanVienDAO.checkAccout(MainActivity.this, name, pass, mail);
                    Log.d(TAG, "" + nhanVien.getTenNV());
                    // Toast.makeText(MainActivity.this, "" + nhanVien.getTaiKhoan() + nhanVien.getMatKhau(), Toast.LENGTH_LONG).show();
//                    if(NhanVienDAO.checkAccout(MainActivity.this, name, pass, mail)) {
//                        Log.d(TAG, "To Home Activity");
//                        Intent intent = new Intent(MainActivity.this, Home.class);
//                        startActivity(intent);
//                    } else {
//                        msgResult.setText("Loi dang nhap");
//                    }
                    if(nhanVien.getTenNV() != null) {
                        Log.d(TAG, "To Home Activity");
                        Intent intent = new Intent(MainActivity.this, Home.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(MainActivity.this, "Dang nhap thanh cong", Toast.LENGTH_LONG).show();
                        msgResult.setText("Loi dang nhap");
                    }
                }
            }
        });
    }
}