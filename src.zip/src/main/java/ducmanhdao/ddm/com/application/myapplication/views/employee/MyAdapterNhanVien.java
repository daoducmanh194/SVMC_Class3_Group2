package ducmanhdao.ddm.com.application.myapplication.views.employee;

import android.annotation.SuppressLint;
import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

import ducmanhdao.ddm.com.application.myapplication.R;
import ducmanhdao.ddm.com.application.myapplication.db.NhanVienDAO;
import ducmanhdao.ddm.com.application.myapplication.entity.NhanVien;

public class MyAdapterNhanVien extends RecyclerView.Adapter<MyViewHolderNhanVien> {
    private static final String TAG = "MyAdapter";
    private ArrayList<NhanVien> danhSachNv = new ArrayList<NhanVien>();

    //private static ClickListener clickListener;
    public MyAdapterNhanVien(Context context,String ten,String phongBan){
        if(ten == null && phongBan == null){
            danhSachNv=NhanVienDAO.getAllNhanVien(context);}
        else if (ten != null && phongBan == null){
            danhSachNv=NhanVienDAO.getNhanVienTheoTen(context,ten);
        }if (ten == null && phongBan != null){
            danhSachNv=NhanVienDAO.getNhanVienTheoPhongBan(context,phongBan);
        }
    }

    public MyAdapterNhanVien(Context context){

    }

    @Override
    public MyViewHolderNhanVien onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item_bao,parent,false);
        return new MyViewHolderNhanVien(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolderNhanVien holder, @SuppressLint("RecyclerView") int position){
        holder.bindView(danhSachNv.get(position));
    }

    @Override
    public int getItemCount(){return danhSachNv.size();}

    public void removeItem(int position){
        Log.d(TAG,"removeItem" + position);
        notifyItemRemoved(position);
        danhSachNv.remove(position);
    }

    public  NhanVien getDataAt(int position){return danhSachNv.get(position);}

    public void add(int position, NhanVien nhanVien){
        danhSachNv.add(position,nhanVien);
        notifyItemInserted(position);
    }
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_my_adapter);
//    }

//    public void setOnItemClickListener(ClickListener clickListener) {
//        MyAdapterNhanVien.clickListener = clickListener;
//    }
//
//    public interface ClickListener {
//        void onItemClick(int position, View v);
//        void onItemLongClick(int position, View v);
//    }
}
