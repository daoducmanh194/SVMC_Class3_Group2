package ducmanhdao.ddm.com.application.myapplication.views.employee;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Random;

import ducmanhdao.ddm.com.application.myapplication.R;
import ducmanhdao.ddm.com.application.myapplication.db.CongViecDAO;
import ducmanhdao.ddm.com.application.myapplication.db.NhanVienDAO;
import ducmanhdao.ddm.com.application.myapplication.entity.CongViec;
import ducmanhdao.ddm.com.application.myapplication.entity.NhanVien;

public class NhanVienActivity extends AppCompatActivity {
    private static final String alpha = "abcdefghijklmnopqrstuvwxyz"; // a-z
    private static final String alphaUpperCase = alpha.toUpperCase(); // A-Z
    private static final String digits = "0123456789"; // 0-9
    private static final String specials = "~=+%^*/()[]{}/!@#$?|";
    private static final String ALL = alpha + alphaUpperCase + digits + specials;
    private static final String TAG = "VI_TRI_XOA";

    private static Random generator = new Random();

    TextView txtDsNV;
    //EditText editSearchTen;
    Button btnSearchTen, btnThemNhanVien;
    ListView lvNhanVien;
    Spinner spinner;
    ArrayList<NhanVien> dsNv = new ArrayList<>();
    ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nhan_vien);

        txtDsNV = findViewById(R.id.txtDsNV);
        //lvNhanVien=findViewById(R.id.lvNhanVien);
        //editSearchTen=findViewById(R.id.editSearchTheoTen);
        btnSearchTen = findViewById(R.id.btnTimKiemTheoTen);
        btnThemNhanVien = findViewById(R.id.btnThemNhanVien);
        spinner = findViewById(R.id.spinnerSearchTheoPhong);
        EditText editText = findViewById(R.id.editSearchTheoTen);
        //TextInputLayout usernameWrapper = findViewById(R.id.usernameWrapper);
        //Lấy toàn bộ nhân viên
        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        txtDsNV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Sử dụng ListView
//                dsNv=NhanVienDAO.getAllNhanVien(NhanVienActivity.this);
//                adapter= new ArrayAdapter(NhanVienActivity.this, android.R.layout.simple_list_item_1,dsNv);
//                lvNhanVien.setAdapter(adapter);

                //Sủ dụng RecyleView
                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(NhanVienActivity.this);
                linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                recyclerView.setLayoutManager(linearLayoutManager);

                //display like GridView

                MyAdapterNhanVien myAdapter = new MyAdapterNhanVien(NhanVienActivity.this, null, null);
                recyclerView.setAdapter(myAdapter);
                //xử lý xóa khi vuốt sang phải
                ItemTouchHelper.SimpleCallback simpleCallback = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.RIGHT) {
                    @Override
                    public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                        return false;
                    }

                    @Override
                    public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                        if (direction == ItemTouchHelper.RIGHT) {
                            int positon = viewHolder.getAdapterPosition();
                            NhanVien dataItem = myAdapter.getDataAt(positon);
                            myAdapter.removeItem(positon);
                            //Snackbar.make(recyclerView,"Deleted" + dataItem.getTenNV(),Snackbar.LENGTH_LONG).setAction("Undo", view -> myAdapter.add(positon,dataItem)).show();
                            // khởi tạo AlertDialog từ đối tượng Builder. tham số truyền vào ở đây là context.
                            AlertDialog.Builder builder = new AlertDialog.Builder(NhanVienActivity.this);

                            // set Message là phương thức thiết lập câu thông báo
                            builder.setMessage("Xác nhận xóa nhân viên !")
                                    // positiveButton là nút thuận : đặt là OK
                                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            Log.d(TAG, "Vị trị xoá: " + dataItem.getMaNV());
                                            NhanVienDAO.deleteNhanVien(NhanVienActivity.this, dataItem.getMaNV());
                                            CongViecDAO.deleteCongViecTheoNhanVien(NhanVienActivity.this, String.valueOf(dataItem.getMaNV()));
                                            myAdapter.notifyItemChanged(positon);
                                            //myAdapter.removeItem(positon);
                                        }
                                    })
                                    // ngược lại negative là nút nghịch : đặt là cancel
                                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            // User cancelled the dialog
                                            myAdapter.add(positon, dataItem);
                                            recyclerView.setAdapter(myAdapter);
                                        }
                                    });
                            // tạo dialog và hiển thị
                            builder.create().show();
                        }
                    }
                };

                //xử lý xem chi tiết khi vuốt sang trái
                ItemTouchHelper.SimpleCallback simpleCallback1 = new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT) {
                    @Override
                    public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
                        return false;
                    }

                    @Override
                    public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                        if (direction == ItemTouchHelper.LEFT) {
                            int positon = viewHolder.getAdapterPosition();
                            NhanVien dataItem1 = myAdapter.getDataAt(positon);
                            //Toast.makeText(NhanVienActivity.this,"Vị trí: " + positon,Toast.LENGTH_SHORT).show();
                            //myAdapter.removeItem(positon);
                            //Snackbar.make(recyclerView,"Deleted" + dataItem.getTenNV(),Snackbar.LENGTH_LONG).setAction("Undo", view -> myAdapter.add(positon,dataItem)).show();
                            // khởi tạo AlertDialog từ đối tượng Builder. tham số truyền vào ở đây là context.
                            //myAdapter.add(positon,dataItem);
                            myAdapter.notifyItemChanged(dataItem1.getMaNV());
                            //myAdapter.notifyItemChanged(positon);
                            //recyclerView.setAdapter(myAdapter);
                            Intent intent = new Intent(NhanVienActivity.this, NhanVienChiTietActivity.class);
                            intent.putExtra("manv", String.valueOf(dataItem1.getMaNV()));
                            intent.putExtra("tennv", String.valueOf(dataItem1.getTenNV()));
                            intent.putExtra("diachi", String.valueOf(dataItem1.getDiaChi()));
                            intent.putExtra("sdt", String.valueOf(dataItem1.getSdt()));
                            intent.putExtra("email", String.valueOf(dataItem1.getEmail()));
                            intent.putExtra("chucvu", String.valueOf(dataItem1.getChucVu()));
                            intent.putExtra("phongban", String.valueOf(dataItem1.getPhongBan()));
                            intent.putExtra("kinhnghiem", String.valueOf(dataItem1.getKinhNghiem()));
                            startActivity(intent);

                        }
                    }
                };
                ItemTouchHelper itemTouchHelper = new ItemTouchHelper(simpleCallback);
                itemTouchHelper.attachToRecyclerView(recyclerView);
                ItemTouchHelper itemTouchHelper1 = new ItemTouchHelper(simpleCallback1);
                itemTouchHelper1.attachToRecyclerView(recyclerView);

            }
        });


        //Tìm kiếm nhân viên theo tên
        btnSearchTen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String ten = editText.getText().toString();
                if (editText.isEnabled() && ten.isEmpty()) {
                    editText.setError("Bạn cần nhập từ khoá!");
                } else {
                    editText.setError(null);
                    MyAdapterNhanVien myAdapter = new MyAdapterNhanVien(NhanVienActivity.this, ten, null);
                    recyclerView.setAdapter(myAdapter);
                    editText.setText("");
                }

                //sử dụng listview
//                dsNv=NhanVienDAO.getNhanVienTheoTen(NhanVienActivity.this,ten);
//                adapter= new ArrayAdapter(NhanVienActivity.this, android.R.layout.simple_list_item_1,dsNv);
//                lvNhanVien.setAdapter(adapter);

            }
        });

        //Tìm kiếm nhân viên theo phòng ban
        //xử lý spinner
        String phongBan[] = {"--Chọn phòng ban--", "Phòng kế toán", "Phòng nhân sự", "Phòng kỹ thuật"};

        ArrayAdapter<String> adapter1 = new ArrayAdapter<>(NhanVienActivity.this, android.R.layout.simple_list_item_1, phongBan);
        adapter1.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spinner.setAdapter(adapter1);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                //Sủ dụng RecyleView
                String phongBan1 = phongBan[i];
                LinearLayoutManager linearLayoutManager = new LinearLayoutManager(NhanVienActivity.this);
                linearLayoutManager.setOrientation(LinearLayoutManager.VERTICAL);
                recyclerView.setLayoutManager(linearLayoutManager);

                //display like GridView

                MyAdapterNhanVien myAdapter = new MyAdapterNhanVien(NhanVienActivity.this, null, phongBan1);
                recyclerView.setAdapter(myAdapter);
                //editText.setText("");
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        //Xử lý khi ấn vào nút Thêm nhân viên
        btnThemNhanVien.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showDiglog();
            }

            private void showDiglog() {
                AlertDialog.Builder builder = new AlertDialog.Builder(NhanVienActivity.this);
                LayoutInflater inflater = getLayoutInflater();
                View view = inflater.inflate(R.layout.activity_them_nhanvien, null);
                builder.setView(view);
                Dialog dialog = builder.create();
                dialog.show();

                EditText editTenNv = view.findViewById(R.id.txtTenNvThemNhanVien);
                EditText editdiachi = view.findViewById(R.id.txtDiaChiThemNhanVien);
                EditText editsdt = view.findViewById(R.id.txtSdtThemNhanVien);
                EditText editemail = view.findViewById(R.id.txtEmailThemNhanVien);
                EditText editchucvu = view.findViewById(R.id.txtChucVuThemNhanVien);
                Spinner spinner1 = view.findViewById(R.id.spinnerThemNhanVien);
                EditText editkinhnghiem = view.findViewById(R.id.txtKinhnghiemThemNhanVien);
                EditText edittaikhoan = view.findViewById(R.id.txtTaiKhoanThemNhanVien);
                EditText editmatkhau = view.findViewById(R.id.txtMatkhauThemNhanVien);
                Button btnLuuThemNhanVien = view.findViewById(R.id.btnLuuThemnhanVien);

                edittaikhoan.setText(randomAlphaNumeric(8));

                //Toast.makeText(NhanVienActivity.this,"Tài khoản: "+ edittaikhoan.getText().toString(),Toast.LENGTH_LONG).show();
                editmatkhau.setText(randomAlphaNumeric(8));
                //Toast.makeText(NhanVienActivity.this,"Mật khẩu: "+ editmatkhau.getText().toString(),Toast.LENGTH_LONG).show();

                String phongBan1[] = {"--Chọn phòng ban--", "Phòng kế toán", "Phòng nhân sự", "Phòng kỹ thuật"};
                ArrayAdapter<String> adapter1 = new ArrayAdapter<>(NhanVienActivity.this, android.R.layout.simple_list_item_1, phongBan1);
                adapter1.setDropDownViewResource(android.R.layout.simple_list_item_1);
                spinner1.setAdapter(adapter1);

                spinner1.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {

                    @Override
                    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                        String s = phongBan1[i];
                        btnLuuThemNhanVien.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                String ten = editTenNv.getText().toString();
                                String diachi = editdiachi.getText().toString();
                                String sdt = editsdt.getText().toString();
                                String email = editemail.getText().toString();
                                String chucvu = editchucvu.getText().toString();
                                String phongban = s;
                                String kinhnghiem = editkinhnghiem.getText().toString();
                                String taikhoan = edittaikhoan.getText().toString();
                                String matkhau = editmatkhau.getText().toString();
                                if (editTenNv.isEnabled() && ten.isEmpty()) {
                                    editTenNv.setError("Bạn cần nhập tên nhân viên!");
                                }else if (editdiachi.isEnabled() && diachi.isEmpty()) {
                                    editdiachi.setError("Bạn cần nhập địa chỉ!");
                                } else if (editsdt.isEnabled() && sdt.isEmpty()) {
                                    editsdt.setError("Bạn cần nhập số điện thoại!");
                                } else if (editemail.isEnabled() && email.isEmpty()) {
                                    editemail.setError("Bạn cần nhập email!");
                                } else if (editchucvu.isEnabled() && chucvu.isEmpty()) {
                                    editchucvu.setError("Bạn cần nhập chức vụ!");
                                } else if (editkinhnghiem.isEnabled() && kinhnghiem.isEmpty()) {
                                    editkinhnghiem.setError("Bạn cần nhập kinh nghiệm!");
                                } else {
                                    if (NhanVienDAO.insert(NhanVienActivity.this, ten, diachi, sdt, email, chucvu, phongban, kinhnghiem, taikhoan, matkhau)) {
                                        Toast.makeText(NhanVienActivity.this, "Thêm thành công !", Toast.LENGTH_SHORT).show();
                                        dsNv.clear();
                                        //Update RecyclerView
                                        MyAdapterNhanVien myAdapter = new MyAdapterNhanVien(NhanVienActivity.this, null, null);
                                        recyclerView.setAdapter(myAdapter);
                                        dialog.dismiss();

                                    } else {
                                        Toast.makeText(NhanVienActivity.this, "Thất bại . .. .. .", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            }
                        });
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {

                    }
                });


            }

            private String randomAlphaNumeric(int numberOfCharactor) {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < numberOfCharactor; i++) {
                    int number = randomNumber(0, ALL.length() - 1);
                    char ch = ALL.charAt(number);
                    sb.append(ch);
                }
                return sb.toString();
            }

            private int randomNumber(int min, int max) {
                return generator.nextInt((max - min) + 1) + min;
            }
        });


    }
}