package ducmanhdao.ddm.com.application.myapplication.views.employee;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import ducmanhdao.ddm.com.application.myapplication.R;
import ducmanhdao.ddm.com.application.myapplication.db.NhanVienDAO;
import ducmanhdao.ddm.com.application.myapplication.entity.NhanVien;

public class NhanVienChiTietActivity extends AppCompatActivity {
    EditText editTextMaNV, editTextTenNV, editTextDiaChi, editTextSDT, editTextEmail, editTextChucVu, editTextPhongBan, editTextKinhNghiem;
    CheckBox checkBox;
    Button btnSuaThongTin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nhanvien_chitiet);
        editTextMaNV = findViewById(R.id.txtMaNVTTCT);
        editTextTenNV = findViewById(R.id.txtTenNvTTCT);
        editTextDiaChi = findViewById(R.id.txtDiaChiTTCT);
        editTextSDT = findViewById(R.id.txtSdtTTCT);
        editTextEmail = findViewById(R.id.txtEmailTTCT);
        editTextChucVu = findViewById(R.id.txtChucVuTTCT);
        editTextPhongBan = findViewById(R.id.txtPhongbanTTCT);
        editTextKinhNghiem = findViewById(R.id.txtKinhnghiemTTCT);

        checkBox = findViewById(R.id.checkbox);
        btnSuaThongTin = findViewById(R.id.btnSuaThongTin);

        editTextMaNV.setText(getIntent().getExtras().getString("manv"));
        editTextTenNV.setText(getIntent().getExtras().getString("tennv"));
        editTextDiaChi.setText(getIntent().getExtras().getString("diachi"));
        editTextSDT.setText(getIntent().getExtras().getString("sdt"));
        editTextEmail.setText(getIntent().getExtras().getString("email"));
        editTextChucVu.setText(getIntent().getExtras().getString("chucvu"));
        editTextPhongBan.setText(getIntent().getExtras().getString("phongban"));
        editTextKinhNghiem.setText(getIntent().getExtras().getString("kinhnghiem"));

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {
                if (isChecked == false) {
                    editTextMaNV.setFocusable(false);
                    editTextTenNV.setFocusable(false);
                    editTextDiaChi.setFocusable(false);
                    editTextSDT.setFocusable(false);
                    editTextEmail.setFocusable(false);
                    editTextChucVu.setFocusable(false);
                    editTextPhongBan.setFocusable(false);
                    editTextKinhNghiem.setFocusable(false);
                    btnSuaThongTin.setSoundEffectsEnabled(false);
                } else { // ischecked == true
                    editTextTenNV.setFocusableInTouchMode(true);
                    editTextDiaChi.setFocusableInTouchMode(true);
                    editTextSDT.setFocusableInTouchMode(true);
                    editTextEmail.setFocusableInTouchMode(true);
                    editTextChucVu.setFocusableInTouchMode(true);
                    editTextPhongBan.setFocusableInTouchMode(true);
                    editTextKinhNghiem.setFocusableInTouchMode(true);
                    btnSuaThongTin.setSoundEffectsEnabled(true);

                    btnSuaThongTin.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            String ten = editTextTenNV.getText().toString();
                            String diachi = editTextDiaChi.getText().toString();
                            String sdt = editTextSDT.getText().toString();
                            String email = editTextEmail.getText().toString();
                            String chucvu = editTextChucVu.getText().toString();
                            //String phongban = s;
                            String kinhnghiem = editTextKinhNghiem.getText().toString();
                            if (editTextTenNV.isEnabled() && ten.isEmpty()) {
                                editTextTenNV.setError("Bạn cần nhập tên nhân viên!");
                            } else if (editTextDiaChi.isEnabled() && diachi.isEmpty()) {
                                editTextDiaChi.setError("Bạn cần nhập địa chỉ!");
                            } else if (editTextSDT.isEnabled() && sdt.isEmpty()) {
                                editTextSDT.setError("Bạn cần nhập số điện thoại!");
                            } else if (editTextEmail.isEnabled() && email.isEmpty()) {
                                editTextEmail.setError("Bạn cần nhập email!");
                            } else if (editTextChucVu.isEnabled() && chucvu.isEmpty()) {
                                editTextChucVu.setError("Bạn cần nhập chức vụ!");
                            } else if (editTextKinhNghiem.isEnabled() && kinhnghiem.isEmpty()) {
                                editTextKinhNghiem.setError("Bạn cần nhập kinh nghiệm!");
                            } else {
                                if (NhanVienDAO.update(NhanVienChiTietActivity.this, editTextMaNV.getText().toString(),
                                        ten, diachi, sdt, email, chucvu, editTextPhongBan.getText().toString(), kinhnghiem)) {
                                    Intent intent = new Intent(NhanVienChiTietActivity.this, NhanVienActivity.class);
                                    //intent.setAction("quaylai");
                                    startActivity(intent);
                                }
                            }

                        }
                    });
                }
            }
        });
    }
}
