package ducmanhdao.ddm.com.application.myapplication.views.work;

import android.content.Intent;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import ducmanhdao.ddm.com.application.myapplication.R;
import ducmanhdao.ddm.com.application.myapplication.entity.CongViec;
import ducmanhdao.ddm.com.application.myapplication.views.employee.NhanVienChiTietActivity;

public class WorkHolder extends RecyclerView.ViewHolder {

    private TextView idWork;
    private TextView nameWork;
    private TextView statusWork;
    private TextView descriptionWork;

    public WorkHolder(@NonNull View itemView) {
        super(itemView);
        idWork = itemView.findViewById(R.id.id_text_view);
        nameWork = itemView.findViewById(R.id.nameWork_text);
        statusWork = itemView.findViewById(R.id.statusWork_text);
        descriptionWork = itemView.findViewById(R.id.descriptionWork_text);
    }

    @SuppressWarnings("UseCompatLoadingForDrawbles")
    public void bindView(CongViec dataWork) {
        idWork.setText(String.valueOf(dataWork.getMaCV()));
        nameWork.setText(dataWork.getTenCV());
        statusWork.setText(dataWork.getTrangThai());
        if(dataWork.getMoTa().length() > 7) {
            String[] tmp= (dataWork.getMoTa()).split(" ");
            descriptionWork.setText(tmp[0] +" "+ tmp[1] + "...");
        }else{
            descriptionWork.setText(dataWork.getMoTa());
        }
        itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(itemView.getContext(), WorkWatch.class);
                intent.putExtra("msg", idWork.getText().toString());
                itemView.getContext().startActivity(intent);
            }
        });
    }
}
