package ducmanhdao.ddm.com.application.myapplication.views.work;

import static java.lang.Integer.getInteger;
import static java.lang.Integer.parseInt;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;
import android.widget.Toast;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

import ducmanhdao.ddm.com.application.myapplication.BuildConfig;
import ducmanhdao.ddm.com.application.myapplication.R;
import ducmanhdao.ddm.com.application.myapplication.db.CongViecDAO;
import ducmanhdao.ddm.com.application.myapplication.db.NhanVienDAO;
import ducmanhdao.ddm.com.application.myapplication.entity.CongViec;
import ducmanhdao.ddm.com.application.myapplication.entity.NhanVien;

public class WorkWatch extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private static final String TAG = "WatchWorkDetails";
    private EditText mTextMaCV, mTextTenCV, mTextThucHien, mTextChiTiet;
    private ImageButton btnBack;
    private Button btnHuy, btn;
    private Spinner spinnerTrangThai, spinnerThucHien;
    private String state[] = {"-Chọn trạng thái-", "Done","Processing","Cancelled"};
    private String trangthai;
    private TextView mTextTrangThai;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work);
        Log.d(TAG, "onCreate Watch Work Activity");

        mTextMaCV = findViewById(R.id.text_ma_cong_viec);
        mTextTenCV = findViewById(R.id.text_ten_cong_viec);
        mTextThucHien = findViewById(R.id.text_thuc_hien);
        mTextChiTiet = findViewById(R.id.text_chi_tiet_cong_viec);
        mTextTrangThai = findViewById(R.id.text_trang_thai);
        spinnerTrangThai = findViewById(R.id.spinner_trang_thai);
        spinnerTrangThai.setOnItemSelectedListener(this);
        spinnerThucHien = findViewById(R.id.spinner_thuc_hien);
        spinnerThucHien.setOnItemSelectedListener(this);
        btnBack = findViewById(R.id.imageButtonBack);
        btnHuy = findViewById(R.id.button_huy);
        btn = findViewById(R.id.button_work_dao);

        // hien cong viec chi tiet neu da chon click
        String tencv = getIntent().getStringExtra("msg");
        ArrayList<CongViec> listCongViec = CongViecDAO.getCongViecByMa(WorkWatch.this, Integer.parseInt(tencv));
        CongViec congViec = listCongViec.get(0);
        mTextMaCV.setText(String.valueOf(congViec.getMaCV()));
        mTextMaCV.setFocusable(false);
        mTextTenCV.setText(congViec.getTenCV());
        mTextTenCV.setFocusable(false);
        NhanVien nhanVien = NhanVienDAO.getNhanVienTheoMa(WorkWatch.this, congViec.getMaNV());
        spinnerThucHien.setVisibility(View.INVISIBLE);
        mTextThucHien.setText(nhanVien.getTenNV());
        mTextThucHien.setFocusable(false);
        mTextChiTiet.setText(congViec.getMoTa());
        mTextChiTiet.setFocusable(false);
        mTextTrangThai.setText(congViec.getTrangThai());
        mTextTrangThai.setFocusable(false);
        spinnerTrangThai.setVisibility(View.INVISIBLE);

        ArrayAdapter<String> ad = new ArrayAdapter(WorkWatch.this, android.R.layout.simple_list_item_1, state);
        ad.setDropDownViewResource(android.R.layout.simple_list_item_1);
        spinnerTrangThai.setAdapter(ad);

        // button work
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "Return to table work page");
                Intent intent = new Intent(WorkWatch.this, WorkTable.class);
                startActivity(intent);
            }
        });
        btnHuy.setVisibility(View.INVISIBLE);
        btn.setText("Sua");
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d(TAG, "To Edit Work");
                Intent intent = new Intent(WorkWatch.this, WorkEdit.class);
                intent.putExtra("msgEdit", mTextTenCV.getText().toString());
                startActivity(intent);
            }
        });

    }
    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
        // Toast.makeText(getApplicationContext(), state[position], Toast.LENGTH_LONG).show();
        trangthai = state[position];
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {
        //
    }

}
