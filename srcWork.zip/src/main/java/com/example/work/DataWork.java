package com.example.work;

public class DataWork {
    String idWork;
    String nameWork;
    String statusWork;
    String descriptionWork;

    public DataWork(String idWork, String nameWork, String statusWork, String descriptionWork) {
        this.idWork = idWork;
        this.nameWork = nameWork;
        this.statusWork = statusWork;
        this.descriptionWork = descriptionWork;
    }

    public String getIdWork() {
        return idWork;
    }

    public String getNameWork() {
        return nameWork;
    }

    public String getStatusWork() {
        return statusWork;
    }

    public String getDescriptionWork() {
        return descriptionWork;
    }

    public void setIdWork(String idWork) {
        this.idWork = idWork;
    }

    public void setNameWork(String nameWork) {
        this.nameWork = nameWork;
    }

    public void setStatusWork(String statusWork) {
        this.statusWork = statusWork;
    }

    public void setDescriptionWork(String descriptionWork) {
        this.descriptionWork = descriptionWork;
    }
}
