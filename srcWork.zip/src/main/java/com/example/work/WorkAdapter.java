package com.example.work;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class WorkAdapter extends RecyclerView.Adapter<WorkHolder> {
    private static final String TAG = "WorkAdapter";
    private ArrayList<DataWork> dataWorkArrayList = new ArrayList<>();

    public WorkAdapter() {
        dataWorkArrayList.add(new DataWork("1", "abcxyz", "done", "xem"));
        dataWorkArrayList.add(new DataWork("2", "dsafg", "done", "xem"));
        dataWorkArrayList.add(new DataWork("3", "fhngfbcvb", "done", "xem"));
        dataWorkArrayList.add(new DataWork("4", "dfg", "done", "xem"));
        dataWorkArrayList.add(new DataWork("5", "ryhfgh", "done", "xem"));
        dataWorkArrayList.add(new DataWork("6", "fjh", "done", "xem"));
        dataWorkArrayList.add(new DataWork("7", "hmnb", "done", "xem"));
        dataWorkArrayList.add(new DataWork("8", "gfhrt", "done", "xem"));
        dataWorkArrayList.add(new DataWork("9", "ykgm", "done", "xem"));
    }

    @NonNull
    @Override
    public WorkHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item, parent, false);
        return new WorkHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WorkHolder holder, int position) {
        holder.bindView(dataWorkArrayList.get(position));
    }

    @Override
    public int getItemCount() {
        return dataWorkArrayList.size();
    }

    public DataWork getDataAt(int position) {
        return dataWorkArrayList.get(position);
    }

    public void add(int position, DataWork dataWork) {
        dataWorkArrayList.add(position, dataWork);
        notifyItemInserted(position);
    }

    public void removeItem(int position) {
        Log.d(TAG,"removeItem" + position);
        notifyItemRemoved(position);
        dataWorkArrayList.remove(position);
    }
}
