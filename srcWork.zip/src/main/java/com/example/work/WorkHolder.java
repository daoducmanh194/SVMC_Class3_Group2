package com.example.work;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class WorkHolder extends RecyclerView.ViewHolder {

    private TextView idWork;
    private TextView nameWork;
    private TextView statusWork;
    private TextView descriptionWork;

    public WorkHolder(@NonNull View itemView) {
        super(itemView);
        idWork = itemView.findViewById(R.id.id_text_view);
        nameWork = itemView.findViewById(R.id.nameWork_text);
        statusWork = itemView.findViewById(R.id.statusWork_text);
        descriptionWork = itemView.findViewById(R.id.descriptionWork_text);
    }

    @SuppressWarnings("UseCompatLoadingForDrawbles")
    public void bindView(DataWork dataWork) {
        idWork.setText(dataWork.getIdWork());
        nameWork.setText(dataWork.getNameWork());
        statusWork.setText(dataWork.getStatusWork());
        descriptionWork.setText(dataWork.getDescriptionWork());
    }
}
